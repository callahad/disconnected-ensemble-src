(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
/*!
 * The buffer module from node.js, for the browser.
 *
 * @author   Feross Aboukhadijeh <feross@feross.org> <http://feross.org>
 * @license  MIT
 */

var base64 = require('base64-js')
var ieee754 = require('ieee754')

exports.Buffer = Buffer
exports.SlowBuffer = Buffer
exports.INSPECT_MAX_BYTES = 50
Buffer.poolSize = 8192

/**
 * If `Buffer._useTypedArrays`:
 *   === true    Use Uint8Array implementation (fastest)
 *   === false   Use Object implementation (compatible down to IE6)
 */
Buffer._useTypedArrays = (function () {
  // Detect if browser supports Typed Arrays. Supported browsers are IE 10+, Firefox 4+,
  // Chrome 7+, Safari 5.1+, Opera 11.6+, iOS 4.2+. If the browser does not support adding
  // properties to `Uint8Array` instances, then that's the same as no `Uint8Array` support
  // because we need to be able to add all the node Buffer API methods. This is an issue
  // in Firefox 4-29. Now fixed: https://bugzilla.mozilla.org/show_bug.cgi?id=695438
  try {
    var buf = new ArrayBuffer(0)
    var arr = new Uint8Array(buf)
    arr.foo = function () { return 42 }
    return 42 === arr.foo() &&
        typeof arr.subarray === 'function' // Chrome 9-10 lack `subarray`
  } catch (e) {
    return false
  }
})()

/**
 * Class: Buffer
 * =============
 *
 * The Buffer constructor returns instances of `Uint8Array` that are augmented
 * with function properties for all the node `Buffer` API functions. We use
 * `Uint8Array` so that square bracket notation works as expected -- it returns
 * a single octet.
 *
 * By augmenting the instances, we can avoid modifying the `Uint8Array`
 * prototype.
 */
function Buffer (subject, encoding, noZero) {
  if (!(this instanceof Buffer))
    return new Buffer(subject, encoding, noZero)

  var type = typeof subject

  // Workaround: node's base64 implementation allows for non-padded strings
  // while base64-js does not.
  if (encoding === 'base64' && type === 'string') {
    subject = stringtrim(subject)
    while (subject.length % 4 !== 0) {
      subject = subject + '='
    }
  }

  // Find the length
  var length
  if (type === 'number')
    length = coerce(subject)
  else if (type === 'string')
    length = Buffer.byteLength(subject, encoding)
  else if (type === 'object')
    length = coerce(subject.length) // assume that object is array-like
  else
    throw new Error('First argument needs to be a number, array or string.')

  var buf
  if (Buffer._useTypedArrays) {
    // Preferred: Return an augmented `Uint8Array` instance for best performance
    buf = Buffer._augment(new Uint8Array(length))
  } else {
    // Fallback: Return THIS instance of Buffer (created by `new`)
    buf = this
    buf.length = length
    buf._isBuffer = true
  }

  var i
  if (Buffer._useTypedArrays && typeof subject.byteLength === 'number') {
    // Speed optimization -- use set if we're copying from a typed array
    buf._set(subject)
  } else if (isArrayish(subject)) {
    // Treat array-ish objects as a byte array
    for (i = 0; i < length; i++) {
      if (Buffer.isBuffer(subject))
        buf[i] = subject.readUInt8(i)
      else
        buf[i] = subject[i]
    }
  } else if (type === 'string') {
    buf.write(subject, 0, encoding)
  } else if (type === 'number' && !Buffer._useTypedArrays && !noZero) {
    for (i = 0; i < length; i++) {
      buf[i] = 0
    }
  }

  return buf
}

// STATIC METHODS
// ==============

Buffer.isEncoding = function (encoding) {
  switch (String(encoding).toLowerCase()) {
    case 'hex':
    case 'utf8':
    case 'utf-8':
    case 'ascii':
    case 'binary':
    case 'base64':
    case 'raw':
    case 'ucs2':
    case 'ucs-2':
    case 'utf16le':
    case 'utf-16le':
      return true
    default:
      return false
  }
}

Buffer.isBuffer = function (b) {
  return !!(b !== null && b !== undefined && b._isBuffer)
}

Buffer.byteLength = function (str, encoding) {
  var ret
  str = str + ''
  switch (encoding || 'utf8') {
    case 'hex':
      ret = str.length / 2
      break
    case 'utf8':
    case 'utf-8':
      ret = utf8ToBytes(str).length
      break
    case 'ascii':
    case 'binary':
    case 'raw':
      ret = str.length
      break
    case 'base64':
      ret = base64ToBytes(str).length
      break
    case 'ucs2':
    case 'ucs-2':
    case 'utf16le':
    case 'utf-16le':
      ret = str.length * 2
      break
    default:
      throw new Error('Unknown encoding')
  }
  return ret
}

Buffer.concat = function (list, totalLength) {
  assert(isArray(list), 'Usage: Buffer.concat(list, [totalLength])\n' +
      'list should be an Array.')

  if (list.length === 0) {
    return new Buffer(0)
  } else if (list.length === 1) {
    return list[0]
  }

  var i
  if (typeof totalLength !== 'number') {
    totalLength = 0
    for (i = 0; i < list.length; i++) {
      totalLength += list[i].length
    }
  }

  var buf = new Buffer(totalLength)
  var pos = 0
  for (i = 0; i < list.length; i++) {
    var item = list[i]
    item.copy(buf, pos)
    pos += item.length
  }
  return buf
}

// BUFFER INSTANCE METHODS
// =======================

function _hexWrite (buf, string, offset, length) {
  offset = Number(offset) || 0
  var remaining = buf.length - offset
  if (!length) {
    length = remaining
  } else {
    length = Number(length)
    if (length > remaining) {
      length = remaining
    }
  }

  // must be an even number of digits
  var strLen = string.length
  assert(strLen % 2 === 0, 'Invalid hex string')

  if (length > strLen / 2) {
    length = strLen / 2
  }
  for (var i = 0; i < length; i++) {
    var byte = parseInt(string.substr(i * 2, 2), 16)
    assert(!isNaN(byte), 'Invalid hex string')
    buf[offset + i] = byte
  }
  Buffer._charsWritten = i * 2
  return i
}

function _utf8Write (buf, string, offset, length) {
  var charsWritten = Buffer._charsWritten =
    blitBuffer(utf8ToBytes(string), buf, offset, length)
  return charsWritten
}

function _asciiWrite (buf, string, offset, length) {
  var charsWritten = Buffer._charsWritten =
    blitBuffer(asciiToBytes(string), buf, offset, length)
  return charsWritten
}

function _binaryWrite (buf, string, offset, length) {
  return _asciiWrite(buf, string, offset, length)
}

function _base64Write (buf, string, offset, length) {
  var charsWritten = Buffer._charsWritten =
    blitBuffer(base64ToBytes(string), buf, offset, length)
  return charsWritten
}

function _utf16leWrite (buf, string, offset, length) {
  var charsWritten = Buffer._charsWritten =
    blitBuffer(utf16leToBytes(string), buf, offset, length)
  return charsWritten
}

Buffer.prototype.write = function (string, offset, length, encoding) {
  // Support both (string, offset, length, encoding)
  // and the legacy (string, encoding, offset, length)
  if (isFinite(offset)) {
    if (!isFinite(length)) {
      encoding = length
      length = undefined
    }
  } else {  // legacy
    var swap = encoding
    encoding = offset
    offset = length
    length = swap
  }

  offset = Number(offset) || 0
  var remaining = this.length - offset
  if (!length) {
    length = remaining
  } else {
    length = Number(length)
    if (length > remaining) {
      length = remaining
    }
  }
  encoding = String(encoding || 'utf8').toLowerCase()

  var ret
  switch (encoding) {
    case 'hex':
      ret = _hexWrite(this, string, offset, length)
      break
    case 'utf8':
    case 'utf-8':
      ret = _utf8Write(this, string, offset, length)
      break
    case 'ascii':
      ret = _asciiWrite(this, string, offset, length)
      break
    case 'binary':
      ret = _binaryWrite(this, string, offset, length)
      break
    case 'base64':
      ret = _base64Write(this, string, offset, length)
      break
    case 'ucs2':
    case 'ucs-2':
    case 'utf16le':
    case 'utf-16le':
      ret = _utf16leWrite(this, string, offset, length)
      break
    default:
      throw new Error('Unknown encoding')
  }
  return ret
}

Buffer.prototype.toString = function (encoding, start, end) {
  var self = this

  encoding = String(encoding || 'utf8').toLowerCase()
  start = Number(start) || 0
  end = (end !== undefined)
    ? Number(end)
    : end = self.length

  // Fastpath empty strings
  if (end === start)
    return ''

  var ret
  switch (encoding) {
    case 'hex':
      ret = _hexSlice(self, start, end)
      break
    case 'utf8':
    case 'utf-8':
      ret = _utf8Slice(self, start, end)
      break
    case 'ascii':
      ret = _asciiSlice(self, start, end)
      break
    case 'binary':
      ret = _binarySlice(self, start, end)
      break
    case 'base64':
      ret = _base64Slice(self, start, end)
      break
    case 'ucs2':
    case 'ucs-2':
    case 'utf16le':
    case 'utf-16le':
      ret = _utf16leSlice(self, start, end)
      break
    default:
      throw new Error('Unknown encoding')
  }
  return ret
}

Buffer.prototype.toJSON = function () {
  return {
    type: 'Buffer',
    data: Array.prototype.slice.call(this._arr || this, 0)
  }
}

// copy(targetBuffer, targetStart=0, sourceStart=0, sourceEnd=buffer.length)
Buffer.prototype.copy = function (target, target_start, start, end) {
  var source = this

  if (!start) start = 0
  if (!end && end !== 0) end = this.length
  if (!target_start) target_start = 0

  // Copy 0 bytes; we're done
  if (end === start) return
  if (target.length === 0 || source.length === 0) return

  // Fatal error conditions
  assert(end >= start, 'sourceEnd < sourceStart')
  assert(target_start >= 0 && target_start < target.length,
      'targetStart out of bounds')
  assert(start >= 0 && start < source.length, 'sourceStart out of bounds')
  assert(end >= 0 && end <= source.length, 'sourceEnd out of bounds')

  // Are we oob?
  if (end > this.length)
    end = this.length
  if (target.length - target_start < end - start)
    end = target.length - target_start + start

  var len = end - start

  if (len < 100 || !Buffer._useTypedArrays) {
    for (var i = 0; i < len; i++)
      target[i + target_start] = this[i + start]
  } else {
    target._set(this.subarray(start, start + len), target_start)
  }
}

function _base64Slice (buf, start, end) {
  if (start === 0 && end === buf.length) {
    return base64.fromByteArray(buf)
  } else {
    return base64.fromByteArray(buf.slice(start, end))
  }
}

function _utf8Slice (buf, start, end) {
  var res = ''
  var tmp = ''
  end = Math.min(buf.length, end)

  for (var i = start; i < end; i++) {
    if (buf[i] <= 0x7F) {
      res += decodeUtf8Char(tmp) + String.fromCharCode(buf[i])
      tmp = ''
    } else {
      tmp += '%' + buf[i].toString(16)
    }
  }

  return res + decodeUtf8Char(tmp)
}

function _asciiSlice (buf, start, end) {
  var ret = ''
  end = Math.min(buf.length, end)

  for (var i = start; i < end; i++)
    ret += String.fromCharCode(buf[i])
  return ret
}

function _binarySlice (buf, start, end) {
  return _asciiSlice(buf, start, end)
}

function _hexSlice (buf, start, end) {
  var len = buf.length

  if (!start || start < 0) start = 0
  if (!end || end < 0 || end > len) end = len

  var out = ''
  for (var i = start; i < end; i++) {
    out += toHex(buf[i])
  }
  return out
}

function _utf16leSlice (buf, start, end) {
  var bytes = buf.slice(start, end)
  var res = ''
  for (var i = 0; i < bytes.length; i += 2) {
    res += String.fromCharCode(bytes[i] + bytes[i+1] * 256)
  }
  return res
}

Buffer.prototype.slice = function (start, end) {
  var len = this.length
  start = clamp(start, len, 0)
  end = clamp(end, len, len)

  if (Buffer._useTypedArrays) {
    return Buffer._augment(this.subarray(start, end))
  } else {
    var sliceLen = end - start
    var newBuf = new Buffer(sliceLen, undefined, true)
    for (var i = 0; i < sliceLen; i++) {
      newBuf[i] = this[i + start]
    }
    return newBuf
  }
}

// `get` will be removed in Node 0.13+
Buffer.prototype.get = function (offset) {
  console.log('.get() is deprecated. Access using array indexes instead.')
  return this.readUInt8(offset)
}

// `set` will be removed in Node 0.13+
Buffer.prototype.set = function (v, offset) {
  console.log('.set() is deprecated. Access using array indexes instead.')
  return this.writeUInt8(v, offset)
}

Buffer.prototype.readUInt8 = function (offset, noAssert) {
  if (!noAssert) {
    assert(offset !== undefined && offset !== null, 'missing offset')
    assert(offset < this.length, 'Trying to read beyond buffer length')
  }

  if (offset >= this.length)
    return

  return this[offset]
}

function _readUInt16 (buf, offset, littleEndian, noAssert) {
  if (!noAssert) {
    assert(typeof littleEndian === 'boolean', 'missing or invalid endian')
    assert(offset !== undefined && offset !== null, 'missing offset')
    assert(offset + 1 < buf.length, 'Trying to read beyond buffer length')
  }

  var len = buf.length
  if (offset >= len)
    return

  var val
  if (littleEndian) {
    val = buf[offset]
    if (offset + 1 < len)
      val |= buf[offset + 1] << 8
  } else {
    val = buf[offset] << 8
    if (offset + 1 < len)
      val |= buf[offset + 1]
  }
  return val
}

Buffer.prototype.readUInt16LE = function (offset, noAssert) {
  return _readUInt16(this, offset, true, noAssert)
}

Buffer.prototype.readUInt16BE = function (offset, noAssert) {
  return _readUInt16(this, offset, false, noAssert)
}

function _readUInt32 (buf, offset, littleEndian, noAssert) {
  if (!noAssert) {
    assert(typeof littleEndian === 'boolean', 'missing or invalid endian')
    assert(offset !== undefined && offset !== null, 'missing offset')
    assert(offset + 3 < buf.length, 'Trying to read beyond buffer length')
  }

  var len = buf.length
  if (offset >= len)
    return

  var val
  if (littleEndian) {
    if (offset + 2 < len)
      val = buf[offset + 2] << 16
    if (offset + 1 < len)
      val |= buf[offset + 1] << 8
    val |= buf[offset]
    if (offset + 3 < len)
      val = val + (buf[offset + 3] << 24 >>> 0)
  } else {
    if (offset + 1 < len)
      val = buf[offset + 1] << 16
    if (offset + 2 < len)
      val |= buf[offset + 2] << 8
    if (offset + 3 < len)
      val |= buf[offset + 3]
    val = val + (buf[offset] << 24 >>> 0)
  }
  return val
}

Buffer.prototype.readUInt32LE = function (offset, noAssert) {
  return _readUInt32(this, offset, true, noAssert)
}

Buffer.prototype.readUInt32BE = function (offset, noAssert) {
  return _readUInt32(this, offset, false, noAssert)
}

Buffer.prototype.readInt8 = function (offset, noAssert) {
  if (!noAssert) {
    assert(offset !== undefined && offset !== null,
        'missing offset')
    assert(offset < this.length, 'Trying to read beyond buffer length')
  }

  if (offset >= this.length)
    return

  var neg = this[offset] & 0x80
  if (neg)
    return (0xff - this[offset] + 1) * -1
  else
    return this[offset]
}

function _readInt16 (buf, offset, littleEndian, noAssert) {
  if (!noAssert) {
    assert(typeof littleEndian === 'boolean', 'missing or invalid endian')
    assert(offset !== undefined && offset !== null, 'missing offset')
    assert(offset + 1 < buf.length, 'Trying to read beyond buffer length')
  }

  var len = buf.length
  if (offset >= len)
    return

  var val = _readUInt16(buf, offset, littleEndian, true)
  var neg = val & 0x8000
  if (neg)
    return (0xffff - val + 1) * -1
  else
    return val
}

Buffer.prototype.readInt16LE = function (offset, noAssert) {
  return _readInt16(this, offset, true, noAssert)
}

Buffer.prototype.readInt16BE = function (offset, noAssert) {
  return _readInt16(this, offset, false, noAssert)
}

function _readInt32 (buf, offset, littleEndian, noAssert) {
  if (!noAssert) {
    assert(typeof littleEndian === 'boolean', 'missing or invalid endian')
    assert(offset !== undefined && offset !== null, 'missing offset')
    assert(offset + 3 < buf.length, 'Trying to read beyond buffer length')
  }

  var len = buf.length
  if (offset >= len)
    return

  var val = _readUInt32(buf, offset, littleEndian, true)
  var neg = val & 0x80000000
  if (neg)
    return (0xffffffff - val + 1) * -1
  else
    return val
}

Buffer.prototype.readInt32LE = function (offset, noAssert) {
  return _readInt32(this, offset, true, noAssert)
}

Buffer.prototype.readInt32BE = function (offset, noAssert) {
  return _readInt32(this, offset, false, noAssert)
}

function _readFloat (buf, offset, littleEndian, noAssert) {
  if (!noAssert) {
    assert(typeof littleEndian === 'boolean', 'missing or invalid endian')
    assert(offset + 3 < buf.length, 'Trying to read beyond buffer length')
  }

  return ieee754.read(buf, offset, littleEndian, 23, 4)
}

Buffer.prototype.readFloatLE = function (offset, noAssert) {
  return _readFloat(this, offset, true, noAssert)
}

Buffer.prototype.readFloatBE = function (offset, noAssert) {
  return _readFloat(this, offset, false, noAssert)
}

function _readDouble (buf, offset, littleEndian, noAssert) {
  if (!noAssert) {
    assert(typeof littleEndian === 'boolean', 'missing or invalid endian')
    assert(offset + 7 < buf.length, 'Trying to read beyond buffer length')
  }

  return ieee754.read(buf, offset, littleEndian, 52, 8)
}

Buffer.prototype.readDoubleLE = function (offset, noAssert) {
  return _readDouble(this, offset, true, noAssert)
}

Buffer.prototype.readDoubleBE = function (offset, noAssert) {
  return _readDouble(this, offset, false, noAssert)
}

Buffer.prototype.writeUInt8 = function (value, offset, noAssert) {
  if (!noAssert) {
    assert(value !== undefined && value !== null, 'missing value')
    assert(offset !== undefined && offset !== null, 'missing offset')
    assert(offset < this.length, 'trying to write beyond buffer length')
    verifuint(value, 0xff)
  }

  if (offset >= this.length) return

  this[offset] = value
}

function _writeUInt16 (buf, value, offset, littleEndian, noAssert) {
  if (!noAssert) {
    assert(value !== undefined && value !== null, 'missing value')
    assert(typeof littleEndian === 'boolean', 'missing or invalid endian')
    assert(offset !== undefined && offset !== null, 'missing offset')
    assert(offset + 1 < buf.length, 'trying to write beyond buffer length')
    verifuint(value, 0xffff)
  }

  var len = buf.length
  if (offset >= len)
    return

  for (var i = 0, j = Math.min(len - offset, 2); i < j; i++) {
    buf[offset + i] =
        (value & (0xff << (8 * (littleEndian ? i : 1 - i)))) >>>
            (littleEndian ? i : 1 - i) * 8
  }
}

Buffer.prototype.writeUInt16LE = function (value, offset, noAssert) {
  _writeUInt16(this, value, offset, true, noAssert)
}

Buffer.prototype.writeUInt16BE = function (value, offset, noAssert) {
  _writeUInt16(this, value, offset, false, noAssert)
}

function _writeUInt32 (buf, value, offset, littleEndian, noAssert) {
  if (!noAssert) {
    assert(value !== undefined && value !== null, 'missing value')
    assert(typeof littleEndian === 'boolean', 'missing or invalid endian')
    assert(offset !== undefined && offset !== null, 'missing offset')
    assert(offset + 3 < buf.length, 'trying to write beyond buffer length')
    verifuint(value, 0xffffffff)
  }

  var len = buf.length
  if (offset >= len)
    return

  for (var i = 0, j = Math.min(len - offset, 4); i < j; i++) {
    buf[offset + i] =
        (value >>> (littleEndian ? i : 3 - i) * 8) & 0xff
  }
}

Buffer.prototype.writeUInt32LE = function (value, offset, noAssert) {
  _writeUInt32(this, value, offset, true, noAssert)
}

Buffer.prototype.writeUInt32BE = function (value, offset, noAssert) {
  _writeUInt32(this, value, offset, false, noAssert)
}

Buffer.prototype.writeInt8 = function (value, offset, noAssert) {
  if (!noAssert) {
    assert(value !== undefined && value !== null, 'missing value')
    assert(offset !== undefined && offset !== null, 'missing offset')
    assert(offset < this.length, 'Trying to write beyond buffer length')
    verifsint(value, 0x7f, -0x80)
  }

  if (offset >= this.length)
    return

  if (value >= 0)
    this.writeUInt8(value, offset, noAssert)
  else
    this.writeUInt8(0xff + value + 1, offset, noAssert)
}

function _writeInt16 (buf, value, offset, littleEndian, noAssert) {
  if (!noAssert) {
    assert(value !== undefined && value !== null, 'missing value')
    assert(typeof littleEndian === 'boolean', 'missing or invalid endian')
    assert(offset !== undefined && offset !== null, 'missing offset')
    assert(offset + 1 < buf.length, 'Trying to write beyond buffer length')
    verifsint(value, 0x7fff, -0x8000)
  }

  var len = buf.length
  if (offset >= len)
    return

  if (value >= 0)
    _writeUInt16(buf, value, offset, littleEndian, noAssert)
  else
    _writeUInt16(buf, 0xffff + value + 1, offset, littleEndian, noAssert)
}

Buffer.prototype.writeInt16LE = function (value, offset, noAssert) {
  _writeInt16(this, value, offset, true, noAssert)
}

Buffer.prototype.writeInt16BE = function (value, offset, noAssert) {
  _writeInt16(this, value, offset, false, noAssert)
}

function _writeInt32 (buf, value, offset, littleEndian, noAssert) {
  if (!noAssert) {
    assert(value !== undefined && value !== null, 'missing value')
    assert(typeof littleEndian === 'boolean', 'missing or invalid endian')
    assert(offset !== undefined && offset !== null, 'missing offset')
    assert(offset + 3 < buf.length, 'Trying to write beyond buffer length')
    verifsint(value, 0x7fffffff, -0x80000000)
  }

  var len = buf.length
  if (offset >= len)
    return

  if (value >= 0)
    _writeUInt32(buf, value, offset, littleEndian, noAssert)
  else
    _writeUInt32(buf, 0xffffffff + value + 1, offset, littleEndian, noAssert)
}

Buffer.prototype.writeInt32LE = function (value, offset, noAssert) {
  _writeInt32(this, value, offset, true, noAssert)
}

Buffer.prototype.writeInt32BE = function (value, offset, noAssert) {
  _writeInt32(this, value, offset, false, noAssert)
}

function _writeFloat (buf, value, offset, littleEndian, noAssert) {
  if (!noAssert) {
    assert(value !== undefined && value !== null, 'missing value')
    assert(typeof littleEndian === 'boolean', 'missing or invalid endian')
    assert(offset !== undefined && offset !== null, 'missing offset')
    assert(offset + 3 < buf.length, 'Trying to write beyond buffer length')
    verifIEEE754(value, 3.4028234663852886e+38, -3.4028234663852886e+38)
  }

  var len = buf.length
  if (offset >= len)
    return

  ieee754.write(buf, value, offset, littleEndian, 23, 4)
}

Buffer.prototype.writeFloatLE = function (value, offset, noAssert) {
  _writeFloat(this, value, offset, true, noAssert)
}

Buffer.prototype.writeFloatBE = function (value, offset, noAssert) {
  _writeFloat(this, value, offset, false, noAssert)
}

function _writeDouble (buf, value, offset, littleEndian, noAssert) {
  if (!noAssert) {
    assert(value !== undefined && value !== null, 'missing value')
    assert(typeof littleEndian === 'boolean', 'missing or invalid endian')
    assert(offset !== undefined && offset !== null, 'missing offset')
    assert(offset + 7 < buf.length,
        'Trying to write beyond buffer length')
    verifIEEE754(value, 1.7976931348623157E+308, -1.7976931348623157E+308)
  }

  var len = buf.length
  if (offset >= len)
    return

  ieee754.write(buf, value, offset, littleEndian, 52, 8)
}

Buffer.prototype.writeDoubleLE = function (value, offset, noAssert) {
  _writeDouble(this, value, offset, true, noAssert)
}

Buffer.prototype.writeDoubleBE = function (value, offset, noAssert) {
  _writeDouble(this, value, offset, false, noAssert)
}

// fill(value, start=0, end=buffer.length)
Buffer.prototype.fill = function (value, start, end) {
  if (!value) value = 0
  if (!start) start = 0
  if (!end) end = this.length

  if (typeof value === 'string') {
    value = value.charCodeAt(0)
  }

  assert(typeof value === 'number' && !isNaN(value), 'value is not a number')
  assert(end >= start, 'end < start')

  // Fill 0 bytes; we're done
  if (end === start) return
  if (this.length === 0) return

  assert(start >= 0 && start < this.length, 'start out of bounds')
  assert(end >= 0 && end <= this.length, 'end out of bounds')

  for (var i = start; i < end; i++) {
    this[i] = value
  }
}

Buffer.prototype.inspect = function () {
  var out = []
  var len = this.length
  for (var i = 0; i < len; i++) {
    out[i] = toHex(this[i])
    if (i === exports.INSPECT_MAX_BYTES) {
      out[i + 1] = '...'
      break
    }
  }
  return '<Buffer ' + out.join(' ') + '>'
}

/**
 * Creates a new `ArrayBuffer` with the *copied* memory of the buffer instance.
 * Added in Node 0.12. Only available in browsers that support ArrayBuffer.
 */
Buffer.prototype.toArrayBuffer = function () {
  if (typeof Uint8Array !== 'undefined') {
    if (Buffer._useTypedArrays) {
      return (new Buffer(this)).buffer
    } else {
      var buf = new Uint8Array(this.length)
      for (var i = 0, len = buf.length; i < len; i += 1)
        buf[i] = this[i]
      return buf.buffer
    }
  } else {
    throw new Error('Buffer.toArrayBuffer not supported in this browser')
  }
}

// HELPER FUNCTIONS
// ================

function stringtrim (str) {
  if (str.trim) return str.trim()
  return str.replace(/^\s+|\s+$/g, '')
}

var BP = Buffer.prototype

/**
 * Augment a Uint8Array *instance* (not the Uint8Array class!) with Buffer methods
 */
Buffer._augment = function (arr) {
  arr._isBuffer = true

  // save reference to original Uint8Array get/set methods before overwriting
  arr._get = arr.get
  arr._set = arr.set

  // deprecated, will be removed in node 0.13+
  arr.get = BP.get
  arr.set = BP.set

  arr.write = BP.write
  arr.toString = BP.toString
  arr.toLocaleString = BP.toString
  arr.toJSON = BP.toJSON
  arr.copy = BP.copy
  arr.slice = BP.slice
  arr.readUInt8 = BP.readUInt8
  arr.readUInt16LE = BP.readUInt16LE
  arr.readUInt16BE = BP.readUInt16BE
  arr.readUInt32LE = BP.readUInt32LE
  arr.readUInt32BE = BP.readUInt32BE
  arr.readInt8 = BP.readInt8
  arr.readInt16LE = BP.readInt16LE
  arr.readInt16BE = BP.readInt16BE
  arr.readInt32LE = BP.readInt32LE
  arr.readInt32BE = BP.readInt32BE
  arr.readFloatLE = BP.readFloatLE
  arr.readFloatBE = BP.readFloatBE
  arr.readDoubleLE = BP.readDoubleLE
  arr.readDoubleBE = BP.readDoubleBE
  arr.writeUInt8 = BP.writeUInt8
  arr.writeUInt16LE = BP.writeUInt16LE
  arr.writeUInt16BE = BP.writeUInt16BE
  arr.writeUInt32LE = BP.writeUInt32LE
  arr.writeUInt32BE = BP.writeUInt32BE
  arr.writeInt8 = BP.writeInt8
  arr.writeInt16LE = BP.writeInt16LE
  arr.writeInt16BE = BP.writeInt16BE
  arr.writeInt32LE = BP.writeInt32LE
  arr.writeInt32BE = BP.writeInt32BE
  arr.writeFloatLE = BP.writeFloatLE
  arr.writeFloatBE = BP.writeFloatBE
  arr.writeDoubleLE = BP.writeDoubleLE
  arr.writeDoubleBE = BP.writeDoubleBE
  arr.fill = BP.fill
  arr.inspect = BP.inspect
  arr.toArrayBuffer = BP.toArrayBuffer

  return arr
}

// slice(start, end)
function clamp (index, len, defaultValue) {
  if (typeof index !== 'number') return defaultValue
  index = ~~index;  // Coerce to integer.
  if (index >= len) return len
  if (index >= 0) return index
  index += len
  if (index >= 0) return index
  return 0
}

function coerce (length) {
  // Coerce length to a number (possibly NaN), round up
  // in case it's fractional (e.g. 123.456) then do a
  // double negate to coerce a NaN to 0. Easy, right?
  length = ~~Math.ceil(+length)
  return length < 0 ? 0 : length
}

function isArray (subject) {
  return (Array.isArray || function (subject) {
    return Object.prototype.toString.call(subject) === '[object Array]'
  })(subject)
}

function isArrayish (subject) {
  return isArray(subject) || Buffer.isBuffer(subject) ||
      subject && typeof subject === 'object' &&
      typeof subject.length === 'number'
}

function toHex (n) {
  if (n < 16) return '0' + n.toString(16)
  return n.toString(16)
}

function utf8ToBytes (str) {
  var byteArray = []
  for (var i = 0; i < str.length; i++) {
    var b = str.charCodeAt(i)
    if (b <= 0x7F)
      byteArray.push(str.charCodeAt(i))
    else {
      var start = i
      if (b >= 0xD800 && b <= 0xDFFF) i++
      var h = encodeURIComponent(str.slice(start, i+1)).substr(1).split('%')
      for (var j = 0; j < h.length; j++)
        byteArray.push(parseInt(h[j], 16))
    }
  }
  return byteArray
}

function asciiToBytes (str) {
  var byteArray = []
  for (var i = 0; i < str.length; i++) {
    // Node's code seems to be doing this and not & 0x7F..
    byteArray.push(str.charCodeAt(i) & 0xFF)
  }
  return byteArray
}

function utf16leToBytes (str) {
  var c, hi, lo
  var byteArray = []
  for (var i = 0; i < str.length; i++) {
    c = str.charCodeAt(i)
    hi = c >> 8
    lo = c % 256
    byteArray.push(lo)
    byteArray.push(hi)
  }

  return byteArray
}

function base64ToBytes (str) {
  return base64.toByteArray(str)
}

function blitBuffer (src, dst, offset, length) {
  var pos
  for (var i = 0; i < length; i++) {
    if ((i + offset >= dst.length) || (i >= src.length))
      break
    dst[i + offset] = src[i]
  }
  return i
}

function decodeUtf8Char (str) {
  try {
    return decodeURIComponent(str)
  } catch (err) {
    return String.fromCharCode(0xFFFD) // UTF 8 invalid char
  }
}

/*
 * We have to make sure that the value is a valid integer. This means that it
 * is non-negative. It has no fractional component and that it does not
 * exceed the maximum allowed value.
 */
function verifuint (value, max) {
  assert(typeof value === 'number', 'cannot write a non-number as a number')
  assert(value >= 0, 'specified a negative value for writing an unsigned value')
  assert(value <= max, 'value is larger than maximum value for type')
  assert(Math.floor(value) === value, 'value has a fractional component')
}

function verifsint (value, max, min) {
  assert(typeof value === 'number', 'cannot write a non-number as a number')
  assert(value <= max, 'value larger than maximum allowed value')
  assert(value >= min, 'value smaller than minimum allowed value')
  assert(Math.floor(value) === value, 'value has a fractional component')
}

function verifIEEE754 (value, max, min) {
  assert(typeof value === 'number', 'cannot write a non-number as a number')
  assert(value <= max, 'value larger than maximum allowed value')
  assert(value >= min, 'value smaller than minimum allowed value')
}

function assert (test, message) {
  if (!test) throw new Error(message || 'Failed assertion')
}

},{"base64-js":2,"ieee754":3}],2:[function(require,module,exports){
var lookup = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

;(function (exports) {
	'use strict';

  var Arr = (typeof Uint8Array !== 'undefined')
    ? Uint8Array
    : Array

	var PLUS   = '+'.charCodeAt(0)
	var SLASH  = '/'.charCodeAt(0)
	var NUMBER = '0'.charCodeAt(0)
	var LOWER  = 'a'.charCodeAt(0)
	var UPPER  = 'A'.charCodeAt(0)
	var PLUS_URL_SAFE = '-'.charCodeAt(0)
	var SLASH_URL_SAFE = '_'.charCodeAt(0)

	function decode (elt) {
		var code = elt.charCodeAt(0)
		if (code === PLUS ||
		    code === PLUS_URL_SAFE)
			return 62 // '+'
		if (code === SLASH ||
		    code === SLASH_URL_SAFE)
			return 63 // '/'
		if (code < NUMBER)
			return -1 //no match
		if (code < NUMBER + 10)
			return code - NUMBER + 26 + 26
		if (code < UPPER + 26)
			return code - UPPER
		if (code < LOWER + 26)
			return code - LOWER + 26
	}

	function b64ToByteArray (b64) {
		var i, j, l, tmp, placeHolders, arr

		if (b64.length % 4 > 0) {
			throw new Error('Invalid string. Length must be a multiple of 4')
		}

		// the number of equal signs (place holders)
		// if there are two placeholders, than the two characters before it
		// represent one byte
		// if there is only one, then the three characters before it represent 2 bytes
		// this is just a cheap hack to not do indexOf twice
		var len = b64.length
		placeHolders = '=' === b64.charAt(len - 2) ? 2 : '=' === b64.charAt(len - 1) ? 1 : 0

		// base64 is 4/3 + up to two characters of the original data
		arr = new Arr(b64.length * 3 / 4 - placeHolders)

		// if there are placeholders, only get up to the last complete 4 chars
		l = placeHolders > 0 ? b64.length - 4 : b64.length

		var L = 0

		function push (v) {
			arr[L++] = v
		}

		for (i = 0, j = 0; i < l; i += 4, j += 3) {
			tmp = (decode(b64.charAt(i)) << 18) | (decode(b64.charAt(i + 1)) << 12) | (decode(b64.charAt(i + 2)) << 6) | decode(b64.charAt(i + 3))
			push((tmp & 0xFF0000) >> 16)
			push((tmp & 0xFF00) >> 8)
			push(tmp & 0xFF)
		}

		if (placeHolders === 2) {
			tmp = (decode(b64.charAt(i)) << 2) | (decode(b64.charAt(i + 1)) >> 4)
			push(tmp & 0xFF)
		} else if (placeHolders === 1) {
			tmp = (decode(b64.charAt(i)) << 10) | (decode(b64.charAt(i + 1)) << 4) | (decode(b64.charAt(i + 2)) >> 2)
			push((tmp >> 8) & 0xFF)
			push(tmp & 0xFF)
		}

		return arr
	}

	function uint8ToBase64 (uint8) {
		var i,
			extraBytes = uint8.length % 3, // if we have 1 byte left, pad 2 bytes
			output = "",
			temp, length

		function encode (num) {
			return lookup.charAt(num)
		}

		function tripletToBase64 (num) {
			return encode(num >> 18 & 0x3F) + encode(num >> 12 & 0x3F) + encode(num >> 6 & 0x3F) + encode(num & 0x3F)
		}

		// go through the array every three bytes, we'll deal with trailing stuff later
		for (i = 0, length = uint8.length - extraBytes; i < length; i += 3) {
			temp = (uint8[i] << 16) + (uint8[i + 1] << 8) + (uint8[i + 2])
			output += tripletToBase64(temp)
		}

		// pad the end with zeros, but make sure to not forget the extra bytes
		switch (extraBytes) {
			case 1:
				temp = uint8[uint8.length - 1]
				output += encode(temp >> 2)
				output += encode((temp << 4) & 0x3F)
				output += '=='
				break
			case 2:
				temp = (uint8[uint8.length - 2] << 8) + (uint8[uint8.length - 1])
				output += encode(temp >> 10)
				output += encode((temp >> 4) & 0x3F)
				output += encode((temp << 2) & 0x3F)
				output += '='
				break
		}

		return output
	}

	exports.toByteArray = b64ToByteArray
	exports.fromByteArray = uint8ToBase64
}(typeof exports === 'undefined' ? (this.base64js = {}) : exports))

},{}],3:[function(require,module,exports){
exports.read = function (buffer, offset, isLE, mLen, nBytes) {
  var e, m
  var eLen = nBytes * 8 - mLen - 1
  var eMax = (1 << eLen) - 1
  var eBias = eMax >> 1
  var nBits = -7
  var i = isLE ? (nBytes - 1) : 0
  var d = isLE ? -1 : 1
  var s = buffer[offset + i]

  i += d

  e = s & ((1 << (-nBits)) - 1)
  s >>= (-nBits)
  nBits += eLen
  for (; nBits > 0; e = e * 256 + buffer[offset + i], i += d, nBits -= 8) {}

  m = e & ((1 << (-nBits)) - 1)
  e >>= (-nBits)
  nBits += mLen
  for (; nBits > 0; m = m * 256 + buffer[offset + i], i += d, nBits -= 8) {}

  if (e === 0) {
    e = 1 - eBias
  } else if (e === eMax) {
    return m ? NaN : ((s ? -1 : 1) * Infinity)
  } else {
    m = m + Math.pow(2, mLen)
    e = e - eBias
  }
  return (s ? -1 : 1) * m * Math.pow(2, e - mLen)
}

exports.write = function (buffer, value, offset, isLE, mLen, nBytes) {
  var e, m, c
  var eLen = nBytes * 8 - mLen - 1
  var eMax = (1 << eLen) - 1
  var eBias = eMax >> 1
  var rt = (mLen === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0)
  var i = isLE ? 0 : (nBytes - 1)
  var d = isLE ? 1 : -1
  var s = value < 0 || (value === 0 && 1 / value < 0) ? 1 : 0

  value = Math.abs(value)

  if (isNaN(value) || value === Infinity) {
    m = isNaN(value) ? 1 : 0
    e = eMax
  } else {
    e = Math.floor(Math.log(value) / Math.LN2)
    if (value * (c = Math.pow(2, -e)) < 1) {
      e--
      c *= 2
    }
    if (e + eBias >= 1) {
      value += rt / c
    } else {
      value += rt * Math.pow(2, 1 - eBias)
    }
    if (value * c >= 2) {
      e++
      c /= 2
    }

    if (e + eBias >= eMax) {
      m = 0
      e = eMax
    } else if (e + eBias >= 1) {
      m = (value * c - 1) * Math.pow(2, mLen)
      e = e + eBias
    } else {
      m = value * Math.pow(2, eBias - 1) * Math.pow(2, mLen)
      e = 0
    }
  }

  for (; mLen >= 8; buffer[offset + i] = m & 0xff, i += d, m /= 256, mLen -= 8) {}

  e = (e << mLen) | m
  eLen += mLen
  for (; eLen > 0; buffer[offset + i] = e & 0xff, i += d, e /= 256, eLen -= 8) {}

  buffer[offset + i - d] |= s * 128
}

},{}],4:[function(require,module,exports){
// shim for using process in browser

var process = module.exports = {};

process.nextTick = (function () {
    var canSetImmediate = typeof window !== 'undefined'
    && window.setImmediate;
    var canPost = typeof window !== 'undefined'
    && window.postMessage && window.addEventListener
    ;

    if (canSetImmediate) {
        return function (f) { return window.setImmediate(f) };
    }

    if (canPost) {
        var queue = [];
        window.addEventListener('message', function (ev) {
            var source = ev.source;
            if ((source === window || source === null) && ev.data === 'process-tick') {
                ev.stopPropagation();
                if (queue.length > 0) {
                    var fn = queue.shift();
                    fn();
                }
            }
        }, true);

        return function nextTick(fn) {
            queue.push(fn);
            window.postMessage('process-tick', '*');
        };
    }

    return function nextTick(fn) {
        setTimeout(fn, 0);
    };
})();

process.title = 'browser';
process.browser = true;
process.env = {};
process.argv = [];

function noop() {}

process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;

process.binding = function (name) {
    throw new Error('process.binding is not supported');
}

// TODO(shtylman)
process.cwd = function () { return '/' };
process.chdir = function (dir) {
    throw new Error('process.chdir is not supported');
};

},{}],5:[function(require,module,exports){
(function() {
	var proto = Object.create(HTMLElement.prototype);
	
	proto.createdCallback = function() {
		
		this.values = {};
		this.attachedNode = null;

		// making web components MWC framework proof.
		this.innerHTML = '';

		var div = document.createElement('div');
		// Current pattern [ 001 ] < > [ + ] [ - ] // <-- Not for this iteration
		// Pattern
		// Drum       x o
		// Snare      x o
		// Closed Hat x o ...
		// step       . O . ....
		div.innerHTML = 'Drum Machine';
		this.appendChild(div);
		
		this.readAttributes();
		
	};

	
	proto.attachedCallback = function() {
		// Setup input listeners, perhaps start requestAnimationFrame here
	};


	proto.detachedCallback = function() {
	};


	proto.readAttributes = function() {
		var that = this;
		[].forEach(function(attr) {
			that.setValue(attr, that.getAttribute(attr));		
		});
	};

	
	proto.setValue = function(name, value) {

		if(value !== undefined && value !== null) {
			this.values[name] = value;
		}

		// TODO: Potential re-draw or DOM update in reaction to these values
	};


	proto.getValue = function(name) {
		return this.values[name];
	};

	
	proto.attributeChangedCallback = function(attr, oldValue, newValue, namespace) {
		
		this.setValue(attr, newValue);
		
		// var e = new CustomEvent('change', { detail: this.values } });
		// this.dispatchEvent(e);
		
	};


	proto.attachTo = function(audioNode) {

		var that = this;

		audioNode.addEventListener('step', function(e) {
			var step = e.detail.value;
			that._highlightStep(step);
		});

		this.attachedNode = audioNode;

		this.setupDOM();
		
	};

	proto.setupDOM = function() {
		var dm = this.attachedNode;
		
		if(dm === null) {
			return;
		}

		var numSteps = dm.steps;
		var numTracks = dm.tracks;
		
		if(numTracks === 0) {
			console.error('No tracks in the machine-perhaps you did not use ready()?');
		}

		this.innerHTML = '';

		var matrix = this._makeMatrix(numSteps, numTracks);
		this._matrixTable = matrix.table;
		this._matrixInputs = matrix.inputs;
		this.appendChild(matrix.table);

		this._readCurrentPattern();

	};


	proto._makeMatrix = function(numSteps, numTracks) {
		var inputs = [];
		var table = document.createElement('table');
		var onInput = onPatternCellInput.bind(this);
		for(var i = 0; i < numTracks; i++) {
			var row = table.insertRow();
			var inputRow = [];
			for(var j = 0; j < numSteps; j++) {
				var cell = row.insertCell();
				cell.classList.add('step' + j);
				var checkbox = document.createElement('input');
				checkbox.type = 'checkbox';
				checkbox.dataset.track = i;
				checkbox.dataset.step = j;
				checkbox.addEventListener('change', onInput);
				cell.appendChild(checkbox);
				inputRow.push(checkbox);
			}
			inputs.push(inputRow);
		}
		return { table: table, inputs: inputs };
	};


	function onPatternCellInput(ev) {
		var target = ev.target;
		var track = target.dataset.track;
		var step = target.dataset.step;
		var trigger = target.checked ? 1 : 0;
		
		this._setPatternStep(track, step, trigger);
	}


	proto._highlightStep = function(step) {
		var classToHighlight = 'step' + step;
		var highlightClass = 'highlight';
		var existingHighlight = this.querySelectorAll('[class*=' + highlightClass + ']');
		for(var i = 0; i < existingHighlight.length; i++) {
			var el = existingHighlight[i];
			el.classList.remove(highlightClass);
		}

		var toHighlight = this.querySelectorAll('[class=' + classToHighlight + ']');
		for(var j = 0; j < toHighlight.length; j++) {
			var el2 = toHighlight[j];
			el2.classList.add(highlightClass);
		}
	};


	proto._readCurrentPattern = function() {
		
		var inputs = this._matrixInputs;
		var pattern = this.attachedNode.currentPattern;
		pattern.forEach(function(track, i) {
			var trackInputs = inputs[i];
			for(var j = 0; j < track.length; j++) {
				var trigger = track[j];
				var input = trackInputs[j];
				input.checked = (trigger === 1);
			}
		});
		
	};


	proto._setPatternStep = function(track, step, trigger) {
		this.attachedNode.setStep(track, step, trigger);
		this._readCurrentPattern();
	};


	//


	var component = {};
	component.prototype = proto;
	component.register = function(name) {
		document.registerElement(name, {
			prototype: proto
		});
	};

	if(typeof define === 'function' && define.amd) {
		define(function() { return component; });
	} else if(typeof module !== 'undefined' && module.exports) {
		module.exports = component;
	} else {
		component.register('openmusic-drum-machine-ui'); // automatic registration
	}

}).call(this);


},{}],6:[function(require,module,exports){
(function (Buffer){

var setterGetterify = require('setter-getterify');
var SamplePlayer = require('openmusic-sample-player');
var Promise = require('es6-promise').Promise;

module.exports = function(context) {

	var node = context.createGain();
	var nodeProperties = {
		tracks: 0,
		steps: 16,
		resolution: 16, // although it's actually the inverse 1/16
		bpm: 125,
		currentPattern: []
	};

	setterGetterify(node, nodeProperties);

	var patterns = [
		[
			[ 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0 ],
			[ 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0 ],
			[ 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1 ]
		]
	];
	var currentPatternIndex = 0; // TODO not used yet
	var currentStep = 0;
	var stepTime;
	var startTime;
	
	var scheduleTimeout = null;

	var samplePlayers = [];


	// Sigh that we need to do it this way but it's the best we can do with
	// browserify brfs transforms
	var bassDrum = Buffer("UklGRnCdAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YUydAAAAAAAAAAAAAAAAAAC///kAPhL1J4U3bUKlSIpMaE6DT+pPKVA5UExQXVB3UJhQvlDrUBxRTlGBUbFR31EHUixSSlJiUnNSgFKDUoNSdlJoUkxSLlIFUtdRolFfUSVRw1CRUCRNz0bCQDE7mzbEMp4v3ixjKgsoyyWdI30hah9iHWQbcBmDF54VwBPnERQQRQ57DLYK9Ag2B3kFwQMMAlgAqv78/FL7qvkE+GH2v/Qh84Xx7O9V7sHsL+uh6RbojeYI5YXjBuKK4BLfnd0t3L/aVtnw147WMNXX04LSMdHlz57OW80dzOPKsMmByFjHNMYVxfvD58LZwdDAzb/Qvtm96Lz9uxm7OrpiuZC4xbcAt0K2irXatC+0jbPvslqyy7FDscGwSLDVr2qvBK+orlKuA668rXutQq0QreWsw6ymrJKshayArICsiayZrLCszqz1rCKtV62SrdWtH65xrsmuKa+Pr/2vcLDssG6x97GHsh6zu7NftAm1urVxti+387e+uI65ZLpBuyS8DL37ve6+6L/nwOzB9sIFxBnFM8ZSx3bInsnMyv7LNM1vzq7P8tA70obT19Qs1oXX4thC2qfbD9173uvfX+HW4lDkz+VR59boYerv64HtGO+x8FHy9POc9Ur3+/iz+nD8Mv75/8QBjQMrBYkGsgexCJIJXwodC9ELfQwlDcgNaQ4ID6YPQhDcEHURDRKkEjsT0RNkFPgUixUdFq0WPhfMF1oY5xhzGf4ZiRoSG5obIhyoHCwdsR00HrYeNx+3HzcgtiAzIbAhKiKlIh4jliMNJIQk+SRuJeAlUybEJjQnpCcSKH8o6yhVKcApKSqRKvcqXSvCKyYsiCzqLEotqS0HLmUuwS4dL3cv0S8oMH8w1DApMXwx0DEhMnEywTIPM1wzqDPzMz00hTTONBQ1WjWeNeI1JDZmNqY25TYiN183mzfWNw84SDh/OLY46zgfOVI5hTm1OeU5EzpBOm06mDrCOuw6FDs7O2E7hjupO8w77jsOPC08TDxpPIU8oDy6PNI86jwBPRc9Kz0/PVE9Yz1zPYM9kT2ePao9tT2+PcY9zT3VPdo93z3iPeY96D3pPec95T3iPd892j3UPc09xT27PbE9pj2aPY09gD1wPWA9Tz09PSo9Fj0APeo80zy8PKM8iTxuPFI8NDwXPPc72Du3O5U7cjtOOyk7BDveOrg6jzpmOjw6EDrkObc5iTlaOSo5+jjIOJU4YTgtOPg3wjeLN1Q3GzfiNqc2bDYvNvI1tDV2NTU19TSzNHE0LjTqM6QzXjMWM84yhDI6Mu4xojFUMQYxtjBmMBQwwC9sLxYvvi5mLgwusS1VLfgsmSw5LNgrdSsRK6wqRCrcKXMpCCmcKDAowCdRJ94maib2JYAlCCWRJBcknCMgI6IiIyKjISEhnyAbIJUfDh+HHv4ddR3qHF4c0BtCG7IaIRqPGfwYZxjSFzwXphYNFnQV2hQ/FKITBRNoEskRKRGIEOcPRQ+iDv4NWQ20DA4MZwu/ChcKbQnDCBgIbQfCBhcGagW9BA8EYQOyAgMCVAGkAPT/RP+S/uH9L/19/Mr7F/tk+rH5/fhJ+Jb34fYt9nn1xPQQ9Fzzp/Ly8T7xifDV7yDva+637QPtT+yb6+fqM+qA6c3oGuhn57bmBOZS5aDk8OM/44/i3+Ev4YDg0t8k33beyt0f3XPcyNsd23Tay9kj2XvY1Ncu14nW49VA1ZzU+tNZ07jSGdJ60d3QQNCkzwnPb87WzT7Np8wRzHzL6MpVysPJM8mkyBbIiMf9xnLG6cVgxdrEVMTQw0zDy8JKwsvBTcHRwFXA3L9jv+2+d74EvpK9Ir2yvES817ttuwK7m7o0us+5a7kKuam4S7jtt5K3N7fgtom2NbbhtY+1P7XytKW0W7QRtMuzhLNBs/6yv7KAskOyCLLPsZixY7Eusfuwy7CcsG+wRLAbsPSvzq+rr4ivaa9Kry6vE6/6ruKuzq66rqmuma6Mrn+udq5trmeuYq5grl6uYK5irmeuba51rn+ui66Yrqiuua7MruGu+K4QryqvRq9kr4Ovpa/Hr+yvErA7sGSwkLC9sOywHbFPsYOxubHwsSqyZLKhst6yHbNes6Kz5rMrtHK0urQFtVG1nrXttTy2jrbftjO3iLfftza4kLjpuEW5obn/uV66v7ogu4K75btJvK28FL16veC9SL6wvhm/hL/vv1vAxsAywZ/BDcJ6wunCV8PGwzXEpsQXxYjF+MVqxtzGT8fCxzXIqcgdyZHJB8p7yvHKZ8vey1XMzMxDzbvNMs6qziLPm88U0I7QB9GB0fvRddLw0mvT59Nj1N7UWtXW1VPW0NZN18rXSNjF2ETZwdlA2r7aPNu72zvcu9w63brdOd653jnfud864LrgO+G84T3ivuI/48DjQuTE5Eblx+VK5szmTufQ51Lo1OhX6dnpW+rd6l/r4etj7ObsaO3r7W7u8O5z7/XvePD68H3x//GB8gTzhvMI9Ir0DPWP9RD2kvYU95b3GPiZ+Bv5nPkd+p76H/ug+yH8ofwi/aL9Iv6i/iL/ov8hAKAAIAGfAR0CnAIaA5gDFgSTBBAFjQUKBoYGAwd/B/sHdgjyCG0J6AliCtwKVgvQC0kMwww7DbMNKw6jDhoPkQ8IEH8Q9RBsEeERVhLKEj4TsxMmFJgUChV8Fe4VXxbQFkEXsRcgGJAY/xhsGdoZSBq0GiEbjRv5G2Qczhw4HaIdCx50HtweRB+rHxIgdyDdIEIhpyELIm4i0SIzI5Uj9iNXJLckFiV2JdQlMiaPJuwmSCejJ/4nWSiyKAspYym7KRIqaSq/KhUraSu+KxEsYyy1LAgtWC2oLfgtRi6VLuIuLy97L8YvETBbMKQw7DA1MXwxwzEJMk4ykzLXMhozXTOeM+AzIDRgNJ003DQZNVY1kTXMNQc2QTZ6NrI26TYgN1U3ize/N/I3JThYOIk4uTjoOBg5Rjl0OaE5zTn4OSI6TDp1Op06xDrrOhE7NjtbO307oDvCO+M7AzwiPEA8Xjx7PJc8sjzNPOc8AD0YPTA9Rz1dPXI9hz2bPa49vz3QPeA97z39PQs+Fz4jPi4+OT5CPks+Uz5aPmE+Zz5rPm8+cj51PnY+eD54Png+dj50PnA+bD5nPmE+Wz5UPks+Qj44Pi8+Iz4YPgo+/T3vPeA90D3APa49nD2JPXc9Yj1NPTc9ID0IPfA81jy9PKI8hzxqPE48MDwSPPI70juxO5A7bTtKOyY7AjvdOrc6kDppOkA6GDruOcQ5mTltOUA5EznlOLc4iDhYOCc49jfDN5E3XTcpN/Q2vzaINlI2GjbiNak1cDU1Nfs0vzSDNEc0CjTLM40zTTMOM80yjDJKMggyxTGCMT4x+TC0MG4wJjDfL5gvUC8GL70ucy4pLt0tki1GLfksqyxdLA8swCtxKyEr0Cp/Ki0q2ymIKTUp4SiOKDgo4yeNJzYn4CaIJjAm1yV8JSIlxyRrJA8ksiNVI/cilyI4ItchdiEUIbEgTiDpH4QfHh+2Hk8e5h19HRMdqBw8HM8bYhvzGoQaFBqjGTEZvhhLGNcXYhfrFnUW/RWFFQwVkhQXFJwTHxOiEiQSpREnEacQJxCmDyQPog4eDpoNFQ2QDAsMhQv+CncK8AlnCd4IVQjLB0EHtgYqBp4FEgWFBPgDbAPfAlACwgEzAaQAFQCG//f+Z/7W/Ub9tvwk/JP7Aftw+t75Tfm7+Cn4l/cF93L23/VN9bv0KPSW8wTzcfLf8U7xu/Aq8JjvB+917uTtVO3D7DPso+sT64Pq9Oll6dboSei65y3noOYT5obl++Rv5OTjWePP4kXivOE04azgJeCe3xffkt4N3ondBd2C3ADcf9v/2n7a/tl/2QHZhdgI2IzXEdeX1h3WpdUu1bjUQtTN01rT5tJ00gPSk9Ek0bbQSdDdz3PPCM+fzjfO0M1qzQXNocw/zN7Lfcsey8DKY8oIyq3JVcn8yKbIUMj8x6nHV8cFx7bGZ8Yaxs7FhMU7xfTErcRoxCTE4cOgw2DDIcPkwqjCbsI0wv3BxsGSwV7BLMH7wMzAnsBywEbAHcD0v86/p7+Ev2G/Qb8hvwO/5r7Kvq++l75/vmq+Vb5DvjG+Ir4Tvge++73yvem94r3dvdm91r3VvdS91b3Yvd294r3pvfK9/L0HvhS+Ir4yvkK+Vb5ovn6+lb6tvsa+4b78vhq/OL9Yv3m/nL+/v+S/CsAywFrAhMCvwNvACME3wWbBl8HJwfzBL8JkwpnC0cIJw0LDfMO2w/LDLsRrxKnE58QnxWfFqMXpxSzGb8azxvfGPMeBx8fHDMhUyJvI5MgsyXXJvskJylPKnsrpyjXLgcvPyxzMa8y5zAfNVs2mzffNR86XzunOO8+Nz9/PM9CF0NnQLtGD0djRLtKE0trSMNOH097TNtSO1OfUP9WZ1fLVTNam1gHXXNe31xPYb9jL2CjZhNni2T/andr72lrbudsY3Hjc2Nw33Zfd991Y3rneGt97393fQOCh4AThZ+HK4S3ikOL14lnjveMh5Ibk6uRP5bTlGeZ/5uXmSuew5xfofejj6ErpsekX6n7q5upN67XrHOyE7OzsVO287STuje717l7vx+8w8JnwAfFq8dLxO/Kk8g7zdvPg80n0svQb9YT17fVW9r/2KPeS9/v3ZPjN+Db5n/kJ+nL62/pE+637Fvx//Of8UP25/SH+if7y/lv/w/8qAJEA+QBgAccBLgKVAvwCZAPLAzIEmAT+BGQFygUxBpcG/QZjB8gHLgiTCPcIXAm/CSMKhwrqCk0LsAsTDHYM2Aw6DZwN/g1fDsEOIQ+CD+IPQhCiEAERYBG/ER4SfBLbEjkTlhPzE1AUrBQIFWQVvxUaFnQWzxYoF4IX2hc0GIwY5Bg8GZMZ6hlAGpYa7RpCG5cb7BtAHJMc5xw5HYwd3R0vHoAe0R4hH3EfwB8PIF0gqyD4IEUhkSHeISoidSK/IgojVCOdI+YjLiR1JLwkAiVIJY0l0iUXJlsmnibhJiMnZSemJ+cnJyhmKKUo5CgiKWApnCnYKRQqTyqKKsQq/So2K24rpivdKxQsSSx/LLMs6CwbLU4tgS2yLeMtEy5DLnMuoS7PLvwuKi9WL4IvrC/XLwAwKTBRMHkwoDDGMOwwEjE2MVoxfTGgMcIx5DEEMiQyQzJiMoAynjK7Mtcy8jINMyczQTNaM3IziTOgM7YzzDPhM/UzCDQbNC00PzRPNGA0bzR+NIw0mTSmNLM0vjTJNNM03TTmNO409TT8NAI1CDUMNRA1FDUXNRg1GjUaNRs1GjUZNRc1FDURNQ41CTUENf409zTwNOg03zTWNMw0wjS3NKs0njSSNIM0dTRmNFY0RTQ0NCI0DzT8M+kz1TPAM6ozlDN8M2QzTDM0MxszATPmMssyrzKTMnUyVzI5Mhoy+jHaMbgxlzF0MVMxLzEMMecwwjCbMHUwTjAnMP4v1S+sL4MvWS8uLwMv1y6qLn0uTy4gLvEtwS2QLWAtLy39LMosmCxkLDAs/CvIK5IrXCslK+4qtip/KkYqDSrTKZkpXikjKecorChvKDMo9Se4J3knOyf7JrsmeyY6JvgltiV0JTIl7iSrJGckIyTeI5gjUyMNI8YigCI5IvEhqSFhIRghzyCFIDwg8R+mH1sfDx/EHngeKx7eHZEdQx31HKccWBwJHLobahsbG8saehopGtcZhhkzGeEYjhg6GOcXkhc+F+oWlRY/FukVkhU7FeQUjBQ0FNwTghMpE84SdBIZEr4RYhEFEakQSxDtD44PLw/PDm8ODg6tDUsN6QyFDCIMvwtaC/YKkQorCsUJXgn3CI4IJgi9B1QH6gaABhUGqgU/BdMEZwT6A40DIAOzAkUC1wFoAfkAiwAbAKz/PP/M/lz+6/16/Qn9l/wm/LT7QfvP+l766/l4+Qb5k/gg+K33OvfH9lT24fVu9fr0h/QU9KHzLvO78kjy1fFh8e/wffAK8JfvJe+z7kLu0O1f7e3sfewM7JvrKuu66knq2ulr6fzojugf6LHnQ+fW5mnm/eWS5Sblu+RQ5OXje+MS46niQOLY4XHhCuGk4D7g2t913xHfrd5K3ujdht0l3cXcZdwG3KfbS9vt2pLaNtrb2YHZKNnP2HfYINjK13XXINfM1nnWJ9bW1YXVNtXn1JnUTNQA1LXTa9Mh09nSkdJL0gXSwNF80TrR+NC40HjQOND6z77Pgc9GzwzP086bzmTOLs76zcbNlM1izTLNA83VzKfMe8xPzCXM+8vUy63LiMtiyz/LHMv7ytvKvMqeyoHKZcpLyjHKGcoByuzJ1snDybDJnsmOyX/JcMljyVfJTclDyTvJM8ktySjJJMkgyR7JHckeyR/JIskmySvJMck4yT/JSMlSyV3Jacl3yYXJlcmlybfJycncyfDJBsocyjPKS8pkyn7Kmcq0ytHK7coMyyvLS8tsy43Lr8vSy/XLGsw/zGXMi8yyzNrMA80rzVXNf82qzdXNAc4tzlrOh861zuTOE89Cz3PPo8/UzwXQN9Bp0JzQz9AE0TjRbdGi0djRDtJE0nzSs9Lr0iPTXNOW08/TCtRE1H/UutT21DLVbtWr1enVJtZl1qPW4tYi12LXotfj1yTYZdim2OnYK9lu2bHZ9dk52n7awtoI203bk9vZ2yDcZtyt3PXcPd2F3c3dFt5g3qne8t4834ff0d8d4Gjgs+D/4EzhmOHk4THif+LM4hvjaOO34wXkVOSj5PLkQuWS5eLlM+aD5tTmJed258fnGehr6L3oD+lh6bTpBupZ6q3qAOtU66fr++tP7KPs9+xM7aDt9u1K7p/u9O5K76Dv9e9L8KDw9vBM8aLx+PFO8qXy+/JS86nz//NW9K30BPVb9bH1CfZg9rf2Dvdm9733FPhr+MP4Gvly+cn5IPp3+s76Jvt9+9X7LPyD/Nv8Mv2J/eH9N/6O/uX+PP+T/+v/QQCXAO0ARAGaAfABRgKcAvICSAOeA/QDSQSfBPQESgWfBfUFSQaeBvIGRwebB+8HQwiXCOsIPgmRCeUJOAqLCt0KLwuBC9QLJQx3DMgMGg1rDbsNCw5bDqsO+w5LD5oP6Q83EIYQ1BAiEXARvhELElcSpBLwEjwTiBPUEx4UaRS0FP4USBWSFdsVJBZtFrUW/RZFF40X1BcaGGEYphjsGDEZdhm7Gf8ZQxqHGskaDBtOG5Ab0RsTHFMclBzUHBQdVB2SHdEdDx5MHokexh4CHz0feR+0H+8fKSBiIJsg1SANIUUhfCG0IeohISJWIosiwCL1IigjXCOOI8Ej8yMlJFUkhiS2JOYkFSVDJXElnyXMJfglJCZQJnsmpibQJvomIydMJ3MnmyfCJ+knDyg0KFkofSihKMQo5ygJKSspTCltKY4prSnMKespCSomKkMqXyp7KpYqsSrKKuQq/CoVKy0rRCtbK3IrhyudK7ErxivaK+0rACwRLCIsMyxCLFIsYSxvLH0siiyXLKMsryy6LMUszyzYLOEs6SzxLPgs/ywFLQotDy0TLRctGi0dLR8tIC0hLSItIi0hLSAtHS0bLRgtFC0PLQstBi0ALfos8yzrLOMs2izRLMcsvSyzLKgsmyyPLIIsdCxlLFcsSCw4LCgsFywFLPMr4SvOK7orpiuRK3wrZitQKzorIysLK/Mq2irBKqYqjCpxKlUqOSocKv8p4SnCKaQphCllKUUpJCkDKeEovyidKHkoVigyKA4o6CfDJ50ndidPJygnACfXJq4mhSZbJjEmBibcJbAlhCVXJSsl/iTQJKIkcyREJBQk5COzI4MjUSMfI+0iuiKHIlMiHyLqIbYhgSFMIRYh4CCpIHIgOyADIMsfkh9ZHyAf5h6sHnEeNx78HcEdhR1JHQ0d0ByTHFYcGBzaG5wbXRseG98anxpfGh4a3hmdGVwZGhnZGJcYVRgSGM8XjBdIFwUXwRZ8FjgW9BWvFWkVJBXeFJgUUhQLFMUTfhM3E/ASqBJhEhgS0BGIET8R9hCtEGQQGhDQD4YPPA/xDqcOWw4QDsUNeQ0tDeEMlQxIDPsLrgthCxMLxQp3CikK2gmLCTsJ6wiaCEsI+gepB1gHBwe1BmMGEQa+BWsFFwXDBG4EGwTGA3EDHAPGAnACGgLEAW0BFgHAAGkAEQC6/2L/Cf+x/lj+//2m/U398/ya/ED85/uN+zL72Pp9+iP6yPlt+RL5t/hc+AH4pfdK9+/2k/Y49tz1gPUl9cr0b/QU9LnzXvMC86fyTPLx8ZbxPPHh8IbwK/DR73fvHe/D7mruEO637V3tBe2t7FTs/Oul603r9eqe6kfq8emb6Ubp8eib6Efo8uee50rn+Oak5lLmAOat5VzlC+W75GvkGuTM433jL+Ph4pTiR+L74bDhZeEa4dDgh+A+4PXfrt9n3yHf296V3lHeDd7J3YfdRN0D3cLcgtxC3APcxduI20rbDtvT2pnaX9om2u3Zttl/2UnZE9nf2KvYd9hE2BPY49ey14PXVdcn1/rWztaj1njWT9Ym1v7V19Wx1YvVZ9VE1SHV/9Te1L3UntR/1GLURdQp1A7U9NPa08LTqtOU037TatNV00PTMNMf0w7T/tLv0uHS1NLH0rzSstKo0p/Sl9KQ0onShNKA0nzSedJ30nbSdtJ30nnSe9J+0oLSh9KM0pLSmdKh0qrSs9K90sjS09Lg0u3S+9IK0xnTKdM600rTXdNv04PTltOq07/T1dPr0wHUGNQw1EjUYdR61JTUrtTK1OXUAdUd1TvVWNV21ZPVstXR1fHVEdYy1lPWddaW1rjW29b+1iLXRtdq14/XtNfa1wDYJ9hN2HTYnNjF2O3YF9lB2WvZldnA2ezZF9pD2nDanNrK2vfaJdtS24HbsNvg2w/cP9xw3KHc0twE3TbdaN2b3c7dAd413mnend7S3gffPN9y36jf398W4E7gheC94PXgLeFl4Z7h2OER4kviheLA4vriNeNx463j6eMm5GLkn+Tc5BnlV+WU5dPlEeZQ5o/mz+YO507njufO5w7oT+iQ6NHoE+lV6Zbp2ekb6l3qn+rj6iXraeut6/DrNOx47LzsAO1F7Yntzu0T7lnunu7k7invb++17/vvQvCI8M/wFfFc8aTx6/Ey8nnywfII81DzmPPg8yj0cPS49AD1SfWR9dr1IvZr9rT2/PZF94331vcf+Gj4sfj6+ET5jPnW+R/6aPqy+vv6RPuN+9f7IPxp/LL8+/xE/Y391/0g/mr+sv77/kX/jv/X/x8AaACxAPoAQgGLAdMBHAJlAq0C9QI9A4UDzQMVBF0EpQTtBDQFewXCBQkGUAaXBt4GJQdsB7MH+Qc/CIUIywgRCVYJmwnhCSYKagqvCvQKOAt9C8ELBQxIDIwMzwwSDVUNmA3bDR0OXg6gDuIOIw9kD6UP5g8mEGcQpxDmECYRZRGkEeIRIRJfEp0S2xIZE1YTkhPPEwsURxSDFL8U+hQ1FW8VqRXkFR0WVhaQFsgWARc5F3AXqBffFxYYTBiDGLkY7hgkGVkZjRnBGfQZKBpbGo4awBrzGiQbVRuGG7cb5xsXHEccdhykHNMcAR0uHVsdiB20HeAdDB43HmIejR63HuAeCR8yH1sfgx+qH9Ef+B8eIEQgaiCPILMg1yD7IB4hQSFkIYYhpyHJIekhCiIpIkkiaCKHIqUiwyLgIvwiGCM0I08jayOFI58juSPSI+sjAyQbJDIkSCRfJHUkiiSfJLQkyCTcJO8kAiUUJSYlNyVIJVglaCV3JYUllCWiJa8lvCXJJdUl4CXrJfYlACYKJhMmHCYkJiwmMyY5JkAmRiZLJlAmVSZZJl0mYCZiJmQmZiZnJmcmZyZnJmYmZCZiJmAmXSZaJlYmUiZNJkgmQiY8JjUmLiYmJh4mFiYNJgQm+iXvJeQl2SXOJcIltSWnJZkliyV9JW4lXyVPJT8lLiUcJQol+STlJNIkviSrJJYkgiRsJFYkQCQqJBIk/CPkI8wjsyOaI4AjZSNLIzAjFCP4ItwivyKiIoQiZiJIIikiCiLqIcohqiGJIWchRiEkIQIh3iC7IJggdCBPICsgBSDgH7oflB9tH0YfHh/2Hs4eph59HlQeKh4AHtYdqx2AHVUdKB38HNAcoxx2HEkcGxztG74bjxtgGzEbARvRGqAabxo+Gg0a2xmpGXcZRRkSGd8Yqxh4GEQYEBjbF6cXchc9FwcX0RabFmUWLhb3FcAViRVRFRkV4RSpFHAUNxT+E8UTixNSExgT3hKjEmkSLhLzEbgRfRFBEQURyRCNEFAQFBDWD5oPXA8fD+IOpQ5nDikO6w2tDW4NMA3xDLIMcww0DPULtgt2CzYL9gq2CnYKNgr2CbUJdQk0CfMIsghxCDAI7getB2sHKQfnBqUGYwYgBt4FmwVYBRUF0gSPBEsECATFA4ADPAP4ArMCbgIpAuQBnwFaARQBzgCJAEMA/f+3/3D/Kv/i/pv+VP4M/sX9fv02/e78pvxe/Bb8zfuF+z379Pqr+mP6GvrS+Yn5QPn4+K/4Zvgd+NP3ivdB9/j2rvZl9hv20vWJ9UD19/Su9GX0HPTT84rzQfP58rDyZ/If8tfxj/FH8f/wuPBw8Cnw4e+b71TvDe/H7oHuOu707a/tae0k7eDsm+xX7BPsz+uM60jrBevC6oDqPur86bvpeek56fjouOh56Dro++e9537nQecD58bmieZN5hLm1+Wc5WHlJ+Xu5LXkfORE5A3k1eOf42jjM+P+4sriluJj4i/i/eHL4ZrhaeE54Qnh2uCr4H3gUOAj4Pffy9+g33bfS98i3/re0d6q3oPeXd443hPe7t3L3ajdhd1k3UPdI90D3eTcxtyo3Ivcb9xT3DncHtwF3Ovb09u726Tbjtt422PbT9s72yjbFtsE2/Pa49rU2sXat9qq2p3akdqF2nvacdpo2l/aV9pP2kjaQto92jjaNNow2i3aK9oq2inaKNop2iraK9ou2jDaNNo42jzaQdpG2kzaU9pb2mPaa9p02n3ah9qR2pzap9qz2r/azNrZ2ufa9doE2xPbI9sz20PbVNtm23fbiduc26/bwtvW2+rb/9sT3CncP9xV3Gvcg9ya3LLcytzi3PvcFd0u3UndY91+3Zndtd3R3e3dCt4o3kXeY96B3qDev97e3v3eHt8+31/fgN+i38Pf5t8I4CvgTuBy4JbguuDf4AThKeFP4XXhnOHC4enhEOI44l/iiOKw4tniA+Ms41bjgeOs49fjAeQs5FjkhOSw5NzkCeU25WPlkeXA5e7lHOZL5nvmquba5grnO+dr55znzef95y/oYeiT6MXo9+gq6Vzpj+nD6ffpK+pf6pPqyOr96jLrZ+uc69LrCOw+7HXsq+zi7BntT+2H7b7t9e0t7mTune7V7g3vRu9/77jv8e8q8GPwnfDX8BHxS/GF8cDx+vE18nDyq/Lm8iHzXPOX89PzDvRK9Ib0wvT+9Dr1dvWz9e/1K/Zo9qX24fYd91r3l/fU9xH4TviM+Mn4BvlD+YH5vvn8+Tn6ePq1+vL6L/tt+6v76Psm/GT8ovzg/B39W/2Z/db9FP5S/pD+zf4L/0n/hv/E/wAAPgB7ALkA9gAzAXEBrgHrASgCZQKiAt8CGwNYA5UD0gMOBEsEhwTDBAAFPAV4BbQF7wUrBmcGogbeBhgHVAePB8oHBQhACHoItQjvCCkJYwmdCdcJEApJCoIKuwr0Ci0LZQueC9YLDgxGDH4MtQzsDCMNWg2RDcgN/g00DmoOoA7VDgoPPw90D6gP3Q8REEUQeRCtEOAQExFGEXkRqxHdEQ8SQRJyEqMS1BIEEzQTZBOUE8QT8xMiFFEUgBSuFNwUCRU2FWMVkBW9FekVFRZBFmwWlxbBFuwWFhdAF2kXkxe7F+QXDBg0GFsYgxipGNAY9hgcGUIZZxmMGbAZ1Rn5GR0aQRpkGoYaqRrLGuwaDhsuG08bbxuPG64bzRvsGwscKRxGHGQcgRydHLoc1RzxHAsdJh1BHVoddB2NHaYdvh3WHe4dBR4dHjMeSR5fHnUeiR6eHrIexh7aHu0eAB8SHyQfNh9HH1gfaB94H4cflx+lH7MfwR/PH9wf6R/1HwEgDCAXICIgLSA3IEAgSSBSIFogYiBpIHEgdyB+IIMgiSCOIJMglyCbIJ4goiCkIKYgqCCpIKogqyCrIKogqiCpIKcgpiCjIKEgnSCaIJYgkiCNIIkggyB9IHYgcCBpIGEgWSBRIEggPyA2ICwgISAXIAsgACD0H+gf3B/PH8IftB+mH5gfiB95H2kfWR9JHzkfJx8VHwMf8R7eHsseuB6kHpAeex5mHlEeOx4lHg4e9x3gHcgdsB2ZHYAdZx1OHTQdGh0AHeUcyhyvHJMcdxxbHD4cIRwDHOYbyBupG4obaxtMGywbDBvsGsoaqRqIGmYaRBoiGv8Z3Rm6GZYZchlOGSkZBRngGLsYlRhvGEkYIhj7F9UXrReFF10XNRcNF+QWuxaSFmgWPhYVFusVwBWWFWoVPxUTFecUuxSPFGIUNhQJFNwTrhOBE1MTJRP2EsgSmRJqEjsSCxLcEawRfBFMERsR6xC6EIkQWBAmEPUPww+RD2APLg/7DskOlg5kDjEO/g3LDZcNZA0wDfwMyAyUDF8MKwz2C8ELjAtXCyIL7Aq3CoIKTAoWCuEJqwl1CT8JCQnTCJ0IZggvCPgHwgeLB1QHHQfmBq4GeAZABgkG0QWZBWIFKQXxBLoEggRJBBIE2gOhA2kDMAP3Ar8ChgJNAhUC3AGjAWoBMQH4AL8AhQBMABIA2v+g/2f/Lf/z/rr+gP5G/gz+0f2X/V39Iv3n/K38cvw4/P37wvuH+0z7EfvW+pv6YPok+un5rvlz+Tj5/fjC+Ib4S/gQ+NX3mvde9yP36Pau9nP2N/b99cL1iPVN9RL12PSe9GP0KfTu87TzevNA8wbzzfKT8lryIPLn8a7xdfE98QTxzPCU8FzwJPDt77Xvfu9H7xDv2u6k7m3uOO4C7s3tl+1j7S7t+uzG7JLsX+ws7PnrxuuU62LrMOv/6s7qnupt6j7qDurf6bDpgulU6Sbp+OjL6J7ocehG6Bro7+fF55rncOdG5x3n9ObM5qTmfeZW5jDmCubk5b/lm+V35VPlMOUN5erkyeSo5IfkZuRG5CfkCOTp48zjruOR43XjWeM94yPjCOPu4tXivOKk4ozideJe4kjiMuId4gni9OHh4c3hu+Gp4Zjhh+F24WbhV+FI4TrhLOEf4RPhB+H74PDg5eDb4NLgyeDB4LngseCq4KTgnuCY4JPgj+CL4IfghOCB4H7gfeB84HvgeuB64HvgfOB+4IDgguCF4IngjOCQ4JXgmuCf4KXgq+Cx4LjgwODH4M/g1+Dg4Ong8+D94AjhEuEe4SnhNeFB4U7hW+Fo4XbhhOGS4aHhr+G/4c7h3uHv4QDiEeIi4jTiRuJZ4mzifuKS4qbiuuLP4uTi+OIO4yTjOuNQ42fjfuOV463jxuPe4/fjEOQp5ELkXOR35JHkrOTH5OLk/uQa5TblU+Vw5Y7lrOXJ5ejlBuYl5kTmY+aD5qPmw+bj5gTnJedH52jniues58/n8ecU6DfoW+h/6KPox+js6BDpNulb6YHppunM6fLpGepA6mfqjuq16t3qBest61brf+un69Dr+esj7E3sd+yh7Mvs9uwg7Uvtd+2i7c7t+e0l7lLufu6q7tfuBO8x71/vjO+67+fvFfBD8HLwoPDP8P7wLfFc8YvxuvHp8RnySfJ58qny2vIK8zvzbPOc883z/vMv9GH0kvTD9PX0J/VY9Yr1vPXv9SH2U/aG9rj26vYd91D3g/e19+n3HPhP+IL4tfjp+Bz5UPmD+bb56vke+lL6hfq5+u36IftU+4j7vPvw+yT8WPyM/MD89Pwo/Vz9kP3F/fn9Lf5h/pX+yf79/jH/ZP+Z/83/AAAzAGcAmwDPAAMBNwFqAZ4B0gEGAjkCbQKhAtQCBwM6A20DoAPTAwYEOQRsBJ8E0QQEBTcFaQWbBc4FAAYyBmQGlgbIBvkGKwdcB40HvwfwByEIUQiCCLMI4wgUCUQJdAmkCdQJAwoyCmIKkQrACu8KHgtMC3oLqAvWCwQMMgxgDI4MuwzoDBQNQQ1tDZoNxg3yDR4OSQ50Dp8Oyg71DiAPSg90D54PyA/yDxsQRBBsEJUQvhDmEA4RNRFcEYQRqhHREfgRHhJEEmoSkBK1EtoS/xIkE0gTbBOQE7QT1xP6Ex0UPxRhFIMUphTHFOgUCBUpFUkVaRWJFakVyBXnFQUWJBZCFmAWfRabFrgW1RbxFg0XKRdEF18XeheUF68XyRfjF/wXFhguGEcYXxh3GI4Yphi8GNMY6Rj/GBQZKRk+GVMZaBl8GY8Zoxm2GcgZ2hnsGf4ZDxogGjEaQhpSGmEacRqAGo8anRqrGrkaxhrTGuAa7Br4GgQbDxsaGyUbLxs5G0MbTBtVG14bZhtuG3UbfRuEG4sbkRuXG5wboRumG6obrhuyG7UbuBu7G70bvxvBG8IbwxvEG8QbxBvEG8MbwxvBG8AbvRu7G7gbtRuyG64bqhumG6EbnBuWG5EbihuEG30bdhtvG2cbXxtXG04bRRs7GzIbJxsdGxIbBxv7GvAa5BrXGsoavhqwGqIalBqGGncaaRpZGkkaOhopGhkaCBr2GeUZ0xnBGa4ZmxmIGXUZYRlOGTkZJRkQGfsY5RjPGLgYohiLGHQYXRhGGC4YFRj9F+UXyxeyF5gXfxdkF0kXLhcUF/gW3BbAFqQWiBZrFk4WMRYUFvYV2BW6FZsVfBVeFT4VHxX/FN8UvxSeFH0UXBQ7FBoU+BPWE7QTkhNvE00TKRMGE+ISvxKbEncSUhIuEgkS5BG/EZkRdBFPESkRAxHcELYQjxBpEEIQGhDyD8sPow96D1IPKg8BD9kOsA6GDl0ONA4KDuANtg2LDWENNw0MDeIMtwyMDGEMNgwLDN8LtAuIC1wLMAsEC9gKrAp/ClMKJgr5CcwJnwlxCUQJFwnqCLwIjwhhCDMIBQjYB6oHfAdOByAH8gbDBpUGZwY4BgkG2wWsBX0FTwUgBfEEwgSSBGMENAQFBNYDpgN3A0cDGAPoArkCiQJZAioC+gHKAZsBawE8AQwB3ACsAHwATAAcAO3/vf+N/13/Lf/8/sz+nP5s/jz+DP7c/av9e/1L/Rr96vy6/Ir8Wfwp/Pn7yPuY+2j7N/sH+9b6pvp1+kX6Ffrl+bX5hPlU+ST59PjD+JT4Y/gz+AP40/ej93P3RPcU9+T2tPaF9lb2Jvb39cf1mPVp9Tr1C/Xc9K70f/RR9CP09PPG85jza/M98w/z4vK18ojyW/Iu8gHy1fGp8X3xUfEl8frwz/Ck8HnwTvAk8Pnvz++l73zvUu8p7wDv2O6v7ofuYO447hHu6u3D7Zztdu1Q7SvtBe3g7Lvsluxy7E/sK+wI7OXrwuug63/rXes76xrr+ura6rrqm+p76l3qPuog6gLq5enH6avpj+lz6VfpPOkh6Qfp7ejT6LrooeiJ6HHoWehC6CvoFOj+5+nn0+e/56rnlueC52/nXOdK5zjnJucV5wXn9ebl5tbmx+a45qrmnOaP5oHmdOZo5lzmUeZG5jvmMeYn5h7mFeYM5gTm/OX05e3l5+Xh5dvl1eXQ5cvlxuXD5b/lvOW55bbltOWy5bHlsOWv5a7lruWv5a/lsOWx5bPltOW35bnlveXA5cTlyOXM5dDl1eXb5eDl5uXs5fLl+eUA5gjmD+YX5h/mKOYx5jrmROZO5ljmYuZt5njmg+aP5pvmp+a05sHmzubb5unm9+YF5xTnI+cy50LnUudh53LngueT56TntufI59rn7Of/5xHoJOg46EvoX+h06Ijoneiy6Mjo3ejz6AnpIOk36U3pZOl86ZPpq+nE6dzp9ekO6ifqQOpa6nTqjuqo6sPq3ur56hTrMOtM62jrhOuh677r2+v46xXsM+xR7HDsjuyt7Mzs6+wK7SrtSe1p7Yntqu3K7evtDO4t7k7ucO6S7rTu1u757hvvPu9h74TvqO/M7+/vE/A38Fvwf/Ck8Mnw7vAT8TjxXfGD8ajxzvHz8RnyP/Jm8o3ys/La8gHzKPNQ83fzn/PG8+7zFvQ+9Gf0j/S49OD0CfUx9Vr1hPWt9db1APYp9lP2fPam9tD2+vYk9073ePei98z39/ch+Ez4d/ih+Mz49/gi+U35ePmj+c/5+vkm+lH6fPqn+tP6/voq+1b7gfut+9n7Bfwx/Fz8iPy0/OD8DP03/WP9j/27/ef9FP5A/mz+mP7D/vD+HP9I/3T/oP/M//j/IwBOAHoApgDSAP0AKQFVAYABrAHXAQMCLgJaAoUCsQLcAggDMwNeA4kDtAPfAwoENQRgBIsEtQTgBAoFNQVfBYoFtAXeBQcGMQZbBoUGrgbYBgEHKwdUB30HpgfOB/cHIAhICHAImQjBCOkIEQk4CWAJhwmuCdUJ/AkjCkoKcQqXCr0K4woJCy8LVQt7C6ALxQvrCxAMNAxZDH0MogzGDOoMDQ0xDVUNeA2bDb4N4A0DDiUORw5pDosOrQ7PDvAOEQ8yD1IPcw+TD7MP0g/yDxIQMBBQEG4QjBCrEMkQ5xAFESIRPxFcEXgRlRGxEc0R6REFEiASOxJWEnESixKlEr8S2BLxEgsTJBM9E1UTbROFE5wTsxPLE+IT+RMPFCUUOxRQFGYUexSQFKQUuRTMFOAU9BQHFRoVLRVAFVIVZBV2FYcVmBWpFboVyhXaFekV+RUIFhcWJhY0FkIWUBZdFmsWdxaEFpEWnRapFrQWwBbLFtUW4BbqFvQW/RYHFxAXGRchFykXMRc5Fz8XRhdNF1MXWRdfF2QXaRduF3MXdxd7F38XgxeHF4oXjBeOF5AXkReTF5QXlReVF5YXlheWF5UXlBeTF5EXkBeOF4wXiReGF4MXfxd7F3cXchdtF2kXZBdeF1gXUhdLF0UXPhc2Fy8XJxcfFxcXDhcFF/wW8hbpFt8W1RbKFr8WtBapFp0WkRaFFngWaxZeFlEWQxY1FicWGBYKFvsV7BXcFcwVvBWsFZwVixV6FWkVVxVFFTMVIRUOFfsU6BTVFMIUrhSaFIYUcRRcFEcUMhQdFAcU8RPaE8QTrROWE38TZxNQEzgTIBMIE+8S1hK9EqQSixJxElcSPRIjEggS7RHSEbcRnBGAEWURSREsERAR8xDWELkQnBB+EGEQQxAlEAcQ6A/KD6sPjA9tD04PLg8OD+8Ozw6vDo8Obg5ODi0ODA7rDcoNqQ2HDWYNRA0iDQAN3gy7DJkMdgxTDDAMDQzpC8YLowt/C1sLNwsTC+4KygqlCoEKXAo4ChMK7gnJCaQJfwlZCTMJDQnoCMIInAh2CFAIKggDCN0HtweQB2oHQwccB/UGzwaoBoEGWgYzBgsG5AW8BZUFbgVGBR8F9wTPBKcEgARYBDAECQThA7kDkQNpA0EDGQPxAsgCoAJ4AlACKAIAAtcBrwGHAV8BNgEOAeYAvQCVAG0ARAAcAPX/zP+k/3z/U/8r/wP/2v6y/or+Yv45/hH+6f3A/Zj9cP1I/R/99/zP/Kf8f/xX/C/8B/ze+7b7jvtm+z77Fvvu+sf6n/p3+k/6J/oA+tn5sfmJ+WL5OvkT+ez4xPid+HX4Tvgn+AH42fez94z3Zvc/9xj38vbM9qX2f/ZZ9jP2Dvbo9cL1nfV49VL1LfUI9eP0vvSa9HX0UfQt9Aj05PPA853zevNW8zPzEPPt8svyqPKG8mTyQvIh8v/x3fG88Zvxe/Fa8TrxGvH68NrwuvCb8HzwXfA/8CDwAvDk78fvqe+M72/vUu827xrv/u7j7sfure6S7nfuXO5C7ijuD+727d3txO2s7ZTtfO1l7U3tNu0g7Qrt9Oze7Mnss+yf7Irsduxi7E/sO+wo7BXsA+zx6+Drzuu+663rneuN633rbete61DrQesz6yXrF+sK6/7q8erl6tnqzerC6rfqrOqi6pjqjuqE6nvqcupq6mLqWupS6kvqROo96jfqMeor6ibqIOoc6hfqE+oP6gvqCOoF6gLq/+n96fvp+un46ffp9un16fTp9On16fXp9un36fnp++n86f/pAeoE6gfqCuoO6hHqFeoa6h/qJOop6i/qNOo66kDqR+pN6lTqXOpj6mvqc+p76oTqjOqV6p7qqOqy6rzqxurR6tvq5+ry6v3qCesV6yHrLus760jrVetj63DrfuuM65rrqeu468fr1uvm6/brBuwW7CfsOOxJ7FrsbOx+7JDsouy17Mfs2uzt7ADtFO0o7TztUO1k7Xntju2j7bntzu3k7frtEO4m7jzuU+5q7oHume6x7snu4e757hHvKu9D71zvde+O76jvwe/b7/XvD/Aq8ETwX/B68JbwsfDM8OjwBPEg8TzxWfF18ZLxr/HM8enxB/Ik8kLyX/J98pzyuvLY8vfyFvM181Tzc/OT87Lz0vPx8xH0MfRR9HH0kvSz9NP09PQV9Tb1V/V49Zn1uvXc9f71IPZC9mT2hvao9sv27fYP9zL3Vfd495r3vffg9wT4J/hK+G34kfi0+Nj4/Pgg+UP5Z/mL+a/51Pn4+Rz6QPpk+on6rfrR+vb6G/s/+2T7iPut+9L79/sc/EH8ZfyK/K/81Pz6/B/9RP1p/Y79s/3Y/f39Iv5I/m3+kv63/tz+Af8m/0z/cf+W/7v/4P8FACoATwB0AJkAvgDjAAgBLAFSAXYBmwHAAeUBCQIuAlMCdwKcAsEC5QIKAy4DUwN3A5sDvwPjAwcEKwRPBHMElgS6BN0EAQUlBUgFawWPBbIF1QX4BRoGPQZgBoMGpQbIBuoGDAcvB1EHcweVB7cH2Af6BxsIPAhdCH4InwjACOEIAQkiCUIJYgmCCaIJwwniCQIKIQpACmAKfwqdCrwK2gr5ChcLNQtTC3ELjgusC8oL5wsEDCEMPQxaDHYMkgyvDMsM5wwDDR4NOQ1UDW8Nig2kDb4N2A3yDQwOJQ4/DlgOcQ6KDqMOuw7TDuwOBA8bDzMPSg9hD3gPjw+lD7wP0g/oD/4PFBApED4QUxBoEHwQkRClELgQzBDfEPMQBhEYESsRPRFPEWERcxGFEZYRpxG4EcgR2RHpEfgRCBIXEiYSNhJEElMSYRJvEn0SixKYEqUSshK/EssS1xLjEu8S+hIGExETGxMmEzATOhNEE04TVxNgE2kTcRN6E4ITihORE5kToBOnE60TsxO6E8ATxRPLE9AT1RPZE94T4hPmE+oT7RPwE/QT9hP5E/sT/RP/EwEUARQCFAMUAxQDFAQUAxQDFAIUARQAFP4T/BP7E/gT9hPzE/AT7RPqE+YT4hPeE9kT1BPQE8sTxRO/E7oTtBOtE6cToBOZE5ITihOCE3oTchNqE2ETWBNPE0UTOxMxEycTHRMSEwgT/RLxEuYS2hLOEsISthKpEpwSjxKCEnQSZhJYEkoSOxItEh4SDxIAEvER4RHREcARsBGfEY8RfhFtEVsRShE4ESYRExEBEe4Q3BDJELUQohCOEHoQZxBSED4QKRAUEP8P6g/VD78PqQ+TD30PaA9RDzoPIw8MD/UO3g7GDq4Olg5+DmUOTQ40DhwOAw7rDdENuA2fDYUNaw1RDTcNHQ0CDegMzQyyDJcMfAxgDEUMKQwODPIL1gu6C50LgQtkC0cLKwsOC/EK1Aq3CpkKfApeCkAKIgoECuYJyAmqCYwJbglPCTAJEQnyCNQItAiVCHYIVgg2CBYI9wfXB7cHlwd3B1cHNgcWB/UG1Qa1BpQGdAZTBjIGEQbwBdAFrwWOBWwFSwUqBQkF6ATGBKUEgwRiBEAEHwT9A9sDugOYA3YDVAMzAxED7wLNAqsCiQJnAkUCJAIBAt8BvQGbAXkBVwE1ARMB8QDPAKwAigBoAEcAJAACAOH/v/+d/3r/Wf83/xX/8/7R/q/+jf5r/kn+J/4F/uP9wf2g/X79XP06/Rn99/zW/LT8k/xx/FD8LvwN/Oz7yvup+4j7Z/tG+yX7BPvj+sL6ofqA+mD6P/oe+v353fm9+Z35fflc+Tz5HPn8+Nz4vPic+Hz4Xfg9+B74//ff98D3ofeB92L3RPcl9wb36PbJ9qv2jfZu9lH2M/YV9vf12vW99Z/1gvVl9Uj1LPUQ9fP01/S79J/0g/Ro9Ez0MfQW9Pvz4PPF86vzkPN281zzQvMp8w/z9vLc8sPyqvKS8nnyYfJJ8jLyGvID8uvx1PG+8afxkfF78WXxT/E68SXxD/H78Obw0vC98KnwlvCC8G/wXPBJ8DfwJPAS8ADw7u/d78zvu++r75rviu9672vvW+9M7z3vL+8g7xLvBO/27uju2+7O7sLute6p7p3uku6G7nvucO5l7lvuUe5G7j3uM+4q7iHuGO4Q7gjuAO747fDt6e3i7dvt1e3O7cjtwu287bftsu2t7antpO2g7Zztme2V7ZLtj+2M7YrtiO2G7YTtgu2A7YDtf+1+7X7tfu1+7X7tf+2A7YDtgu2D7YXth+2J7Yvtju2Q7ZPtl+2a7Z7tou2m7artr+207bntvu3D7cntz+3V7dvt4u3p7fDt9+3+7QbuDu4W7h7uJu4v7jjuQu5L7lTuXu5o7nLufe6H7pLune6p7rTuwO7M7tju5O7x7v3uCu8X7yXvMu9A707vXO9q73jvh++W76XvtO/E79Tv5O/07wTwFPAl8DbwR/BY8Gnwe/CN8J/wsfDD8NXw6PD78A7xIfE08UjxXPFw8YTxmPGt8cHx1vHr8QDyFfIq8kDyVvJr8oHymPKu8sTy2/Lx8gjzH/M3807zZfN985TzrPPE89zz9fMN9Cb0P/RY9HH0ivSj9L301vTw9Ar1JPU+9Vj1cvWN9af1wvXc9fj1EvYu9kn2ZPZ/9pv2t/bS9u72Cvcm90L3X/d795f3tPfR9+33Cvgn+ET4Yfh++Jv4ufjW+PT4Efku+Uz5avmI+ab5xPni+QD6Hvo8+lv6efqY+rb61Prz+hL7MPtP+237jPur+8r76fsI/Cb8Rfxl/IT8o/zC/OH8Af0g/T/9X/1+/Z39vP3b/fv9Gv45/ln+ef6Y/rj+1/73/hb/Nf9U/3T/k/+y/9L/8f8QAC8ATgBuAI0ArADMAOsACgEpAUgBaAGHAaYBxQHkAQMCIgJBAmACfwKdArwC2wL6AhgDNwNVA3QDkgOxA88D7QMLBCoERwRlBIMEoQS/BN0E+gQYBTYFUwVwBY0FqwXIBeUFAgYfBjwGWAZ1BpEGrgbKBuYGAgcfBzsHVgdyB44HqgfFB+EH/AcXCDIITAhnCIIInAi3CNEI6wgGCSAJOglUCW0JhwmgCboJ0wnsCQQKHQo2Ck4KZgp+CpYKrgrGCt0K9AoMCyMLOgtRC2gLfguVC6sLwQvXC+0LAgwYDC0MQwxYDG0MgQyWDKsMvwzTDOcM+wwPDSENNA1HDVoNbQ1/DZINpA22DcgN2g3rDfwNDg4fDi8OQA5RDmEOcQ6BDpAOoA6vDr4OzQ7cDusO+Q4HDxUPIw8xDz4PTA9ZD2UPcg9/D4sPlw+jD68Pug/FD9AP2w/mD/AP+w8FEA8QGRAiECwQNRA+EEYQTxBXEF8QZxBvEHYQfRCEEIsQkRCYEJ4QpBCqELAQtRC6EL8QxBDJEM0Q0hDWENkQ3BDgEOMQ5hDoEOsQ7RDvEPEQ8xD0EPUQ9hD3EPgQ+BD4EPgQ+BD4EPcQ9hD1EPQQ8hDxEO8Q7RDqEOgQ5hDjEOAQ3BDZENUQ0RDNEMgQxBC/ELoQtRCvEKoQpBCeEJcQkRCLEIQQfRB1EG4QZhBfEFcQThBGED0QNRAsECMQGRAQEAYQ/A/yD+gP3Q/SD8gPvA+xD6YPmg+PD4IPdg9qD10PUA9DDzYPKA8bDw0PAA/xDuMO1Q7GDrcOqQ6aDooOew5rDlsOSw47DisOGg4KDvkN6A3XDcYNtA2jDZENfw1tDVsNSA02DSMNEA39DOoM1gzDDK8MnAyIDHMMXwxLDDcMIgwNDPgL4wvOC7kLowuNC3cLYQtMCzULHwsJC/MK3ArFCq4KlwqACmgKUQo5CiEKCgryCdoJwgmqCZIJeQlgCUgJLwkWCf4I5AjLCLMImQiACGYITQgzCBkI/wfmB8sHsQeXB3wHYgdHBy0HEwf4Bt0GwganBowGcQZWBjsGIAYFBuoFzgWzBZcFfAVgBUQFKAUMBfAE1AS4BJwEgARkBEcEKwQPBPMD1gO6A54DgQNlA0gDLAMPA/IC1gK5Ap0CgAJjAkcCKgINAvAB1AG2AZoBfQFgAUMBJgEJAewA0ACzAJYAeQBdAEAAIwAGAOr/zf+x/5T/d/9a/z3/If8E/+f+y/6u/pH+df5Y/jz+H/4D/ub9yv2t/ZH9dP1Y/Tz9IP0E/ef8y/yv/JP8d/xb/ED8JPwI/Oz70Pu1+5n7fvti+0f7K/sQ+/X62vq/+qT6ifpu+lP6OPod+gP66PnO+bP5mfl/+WT5Svkw+Rb5/Pjj+Mn4r/iW+H34Y/hK+DH4GPj/9+b3zfe095z3g/dr91P3O/cj9wv38/bc9sT2rfaW9n72Z/ZR9jr2I/YN9vb14PXK9bT1nvWI9XP1XfVI9TP1HvUJ9fT04PTL9Lf0o/SP9Hz0aPRV9EH0LvQb9An09vPk89Hzv/Ot85zzivN582jzV/NG8zXzJPMU8wTz9PLk8tTyxfK28qfymPKJ8nvybfJf8lHyQ/I18ijyG/IO8gHy9fHo8dzx0PHE8bnxrfGi8ZfxjPGC8XfxbfFj8VrxUPFH8T3xNPEr8SPxGvES8QrxAvH78PPw7PDm8N/w2PDR8MvwxfC/8LrwtfCv8KrwpfCh8JzwmPCU8JDwjPCJ8Ibwg/CA8H3wevB48HbwdfBz8HHwcPBv8G7wbfBs8GzwbPBs8GzwbfBt8G7wb/Bw8HHwc/B18HfwefB78H7wgPCD8IbwivCN8JHwlfCZ8J3wofCm8KrwsPC18LrwwPDG8Mzw0vDY8N7w5fDs8PPw+/AC8QrxEfEZ8SHxKfEy8TrxQ/FM8VXxXvFo8XLxe/GG8ZDxmvGk8a/xuvHF8dDx3PHo8fTx//EM8hjyJPIx8j7ySvJY8mXycvKA8o7ym/Kq8rjyxvLV8uPy8vIB8xDzIPMv8z/zT/Ne827zfvOP86DzsPPB89Lz4/P08wb0F/Qp9Dv0TfRf9HH0g/SV9Kj0u/TO9OH09PQH9Rv1LvVC9Vb1afV99ZH1pvW69c/15PX59Q72IvY39kz2YfZ39o32ova49s725Pb69hD3Jvc991P3aveA95f3rvfF99z38/cK+CH4OfhQ+Gj4gPiX+K/4x/jf+Pf4D/kn+UD5WPlx+Yn5ovm6+dP57PkF+h76N/pQ+mn6gvqb+rT6zfrn+gD7Gvsz+037Z/uA+5r7tPvO++j7Avwc/Db8UPxq/IT8nvy4/NL87fwH/SH9PP1W/XD9i/2m/cD92/31/RD+Kv5F/l/+ev6U/q7+yP7j/v3+GP8z/07/aP+D/53/uP/S/+3/BgAhADwAVgBxAIsApgDAANsA9QAPASkBQwFeAXgBkgGsAccB4QH7ARUCLwJJAmMCfQKXArECywLlAv4CGAMyA0sDZQN+A5gDsQPLA+QD/QMWBC8ESARiBHoEkwSsBMUE3gT2BA8FJwVABVgFcAWIBaAFuQXQBegFAAYYBi8GRwZeBnUGjQakBrsG0gbpBgAHFgctB0QHWgdwB4cHnQezB8kH3wf0BwoIHwg1CEoIXwh0CIkIngizCMcI3AjwCAUJGQktCUEJVQlpCXwJjwmjCbYJyQncCe8JAQoUCiYKOApKClwKbgqACpEKowq0CsUK1groCvgKCQsZCyoLOgtKC1oLagt5C4kLmAunC7YLxQvUC+ML8Qv/Cw4MHAwpDDcMRAxSDF8MbQx5DIYMkgyfDKsMtwzDDM8M2gzmDPEM/AwHDRINHQ0nDTENPA1GDVANWQ1jDWwNdQ1+DYcNkA2YDaANqA2wDbgNvw3HDc4N1Q3cDeMN6Q3wDfYN/A0CDggODQ4TDhgOHQ4iDicOKw4vDjMONw47Dj8OQg5GDkgOSw5ODlAOUw5VDlcOWQ5aDlwOXQ5eDl8OYA5hDmEOYQ5iDmEOYQ5hDmAOXw5eDl0OWw5aDlgOVg5VDlIOUA5NDksOSA5FDkEOPg47DjcOMw4vDioOJg4hDhwOFw4TDg0OCA4CDvwN9g3wDekN4w3cDdUNzg3HDcANuQ2xDakNoQ2YDZANhw1+DXYNbQ1kDVoNUQ1HDT0NMw0pDR8NFQ0KDf8M9AzpDN4M0wzHDLwMsAykDJgMjAyADHMMZgxZDEwMPwwyDCUMFwwJDPsL7QvfC9ELwwu0C6ULlguHC3gLaQtaC0oLOwsrCxsLCwv7CusK2grKCrkKqAqXCoYKdApjClIKQAouChwKCwr5CeYJ1AnCCa8JnQmKCXcJZAlRCT4JKwkYCQUJ8QjdCMoItQihCI0IeQhlCFEIPAgoCBMI/gfqB9UHwAerB5YHgAdrB1UHQAcqBxUH/wbqBtQGvgaoBpIGfAZmBlAGOQYjBgwG9gXfBcgFsQWaBYQFbQVWBT8FJwUQBfkE4gTLBLMEnASEBG0EVQQ9BCYEDgT3A98DxwOwA5gDgANoA1ADOAMgAwcD7wLXAr8CpwKOAnYCXgJGAi0CFQL9AeQBzAGzAZsBgwFqAVIBOgEiAQkB8QDYAMAAqACPAHcAXgBGAC0AFQD+/+X/zf+1/5z/hP9s/1P/O/8j/wr/8v7a/sL+qf6R/nn+Yf5J/jH+Gf4B/un90f25/aL9iv1y/Vr9Qv0r/RP9+/zk/Mz8tfye/Ib8b/xX/ED8KfwS/Pv75PvN+7b7n/uJ+3L7XPtF+y/7GPsC++v61fq/+qn6k/p9+mf6Ufo7+iX6EPr6+eX5z/m6+aX5j/l6+WX5Ufk8+Sf5Evn++Or41vjB+K34mfiF+HH4XvhK+Db4IvgP+Pz36ffW98P3sPed94v3ePdm91T3Qvcw9x73DPf69un21/bG9rT2o/aS9oH2cPZg9k/2P/Yv9h/2D/b/9fD14PXR9cH1svWj9ZX1hvV49Wn1W/VN9T/1MfUj9Rb1CfX79O704fTV9Mj0u/Sv9KP0l/SL9H/0dPRo9F30UvRH9D30MvQo9B30E/QJ9P/z9vPs8+Pz2vPQ88jzv/O3867zpvOe85bzj/OH84DzePNx82rzZPNd81fzUfNK80XzP/M58zTzLvMp8yTzIPMb8xfzEvMO8wrzBvMD8//y/PL58vby8/Lx8u7y7PLp8ufy5fLk8uLy4fLg8t/y3vLe8t3y3fLc8tzy3PLd8t3y3vLe8t/y4PLi8uPy5fLn8ujy6vLt8u/y8vL08vfy+vL+8gHzBPMI8wzzEPMU8xnzHfMh8ybzK/Mw8zXzO/NB80bzTPNS81jzX/Nl82zzc/N684HziPOQ85fzn/On86/zt/O/88jz0PPZ8+Lz6/P08/3zB/QQ9Br0JPQu9Dj0QvRN9Fj0YvRt9Hj0g/SP9Jr0pvSy9L70yfTW9OL07/T79Aj1FPUh9S71O/VJ9Vb1Y/Vx9X/1jfWb9an1t/XG9dT14/Xy9QH2EPYf9i72PvZN9l32bfZ99o32nfat9r32zfbe9u72//YQ9yH3MvdD91T3Zfd394n3mves97730Pfi9/T3BvgY+Cr4PfhP+GL4dPiH+Jr4rfjA+NP45/j6+A35Ifk1+Un5XPlw+YT5mPms+cD51Pno+fz5EPol+jn6Tvpi+nf6jPqg+rX6yvrf+vT6Cfsf+zT7Sfte+3P7ifue+7T7yfvf+/T7Cvwg/Db8TPxh/Hf8jfyj/Ln8z/zl/Pv8Ef0n/T39U/1p/YD9lv2s/cL92f3v/QX+HP4y/kj+X/52/oz+o/65/s/+5v78/hL/Kf8//1b/bP+D/5n/sP/H/93/8/8JAB8ANQBMAGIAeQCPAKUAvADSAOgA/wAVASsBQgFYAW4BhAGaAbABxgHcAfIBCAIeAjQCSgJgAnYCjAKhArcCzQLiAvgCDQMjAzgDTgNjA3kDjgOjA7gDzgPiA/cDDAQhBDYESwRfBHQEiQSdBLIExgTbBO8EAwUXBSsFPwVTBWcFegWOBaIFtQXJBdwF7wUCBhYGKQY8Bk4GYQZ0BocGmQasBr4G0QbjBvUGBwcZByoHPAdOB18HcQeCB5MHpQe2B8cH1wfoB/kHCggaCCoIOwhLCFsIagh6CIoImgipCLgIyAjXCOYI9QgECRIJIQkvCT4JTAlaCWgJdQmDCZEJngmrCbgJxgnTCeAJ7An5CQYKEgoeCioKNgpCCk0KWQpkCnAKewqGCpEKnAqmCrEKuwrGCs8K2QrjCu0K9goACwkLEgsbCyQLLQs2Cz4LRwtPC1cLXwtnC24Ldgt9C4QLiwuSC5kLoAumC6wLsgu4C74LxAvKC88L1AvZC98L4wvoC+0L8Qv1C/kL/QsADAQMBwwLDA4MEQwUDBcMGQwcDB4MIAwiDCQMJgwnDCkMKgwrDCwMLQwuDC4MLwwvDC8MLwwvDC4MLgwtDCwMKwwqDCgMJwwlDCQMIgwgDB4MGwwZDBYMEwwQDA0MCgwHDAMMAAz8C/gL9AvwC+sL5wviC90L2AvTC84LyQvDC74LuAuyC6wLpQufC5kLkguLC4ULfgt2C28LZwtgC1gLUAtIC0ALOAsvCycLHgsWCw0LBAv6CvEK5wreCtQKygrACrYKrAqhCpcKjAqBCnYKawpgClUKSgo+CjMKJwobCg8KAwr2CeoJ3gnRCcUJuAmrCZ4JkQmECXYJaQlcCU4JQAkyCSQJFgkICfkI6wjcCM0IvwiwCKEIkgiDCHQIZQhVCEYINggmCBYIBgj3B+cH1gfGB7YHpQeVB4QHcwdiB1EHQAcvBx4HDQf8BuoG2QbHBrYGpAaSBoAGbgZcBkoGOAYmBhQGAQbvBd0FygW3BaUFkgWABW0FWgVHBTQFIQUOBfsE5wTUBMEErgSaBIcEcwRfBEwEOAQkBBEE/QPpA9UDwQOtA5kDhQNxA10DSQM1AyEDDQP4AuQC0AK7AqcCkwJ+AmoCVQJBAi0CGAIDAu8B2wHGAbEBnQGIAXQBXwFLATYBIQENAfgA5ADPALoApQCRAHwAZwBSAD4AKQAUAAAA7P/X/8P/rv+Z/4X/cP9c/0f/M/8e/wr/9v7h/s3+uf6k/pD+fP5n/lP+P/4r/hf+Av7u/dr9xv2y/Z79iv12/WL9Tv06/Sb9E/3//Ov81/zE/LD8nfyK/Hb8Y/xQ/Dz8KfwW/AP88Pvd+8v7uPul+5L7gPtt+1v7SPs2+yT7Efv/+u362/rJ+rf6pfqU+oL6cPpf+k36PPoq+hn6CPr2+eX51PnD+bL5ovmR+YH5cPlg+VD5P/kv+R/5EPkA+fD44PjR+MH4svij+JT4hfh2+Gf4WPhJ+Dv4LPge+BD4Avj09+b32PfK9733r/ei95X3h/d69233YfdU90f3O/cv9yL3FvcK9/728/bn9tz20PbF9rr2r/ak9pn2j/aE9nn2b/Zl9lv2UfZH9j72NPYr9iH2GPYP9gf2/vX19e315fXc9dX1zfXF9b31tvWu9af1oPWZ9ZL1i/WF9X71ePVy9Wz1ZvVg9Vr1VPVP9Un1RPU/9Tr1NfUx9S31KPUk9SD1HPUY9RX1EfUO9Qv1CPUF9QL1//T99Pr0+PT29PT08vTx9O/07vTt9Ov06vTp9On06PTo9Of05/Tn9Of06PTo9On06fTq9Ov07PTt9O708PTy9PP09fT39Pn0+/T+9AD1A/UG9Qn1DPUP9RP1FvUa9R71IvUm9Sr1LvUz9Tf1PPVB9Ub1S/VQ9VX1W/Vg9Wb1bPVy9Xj1fvWF9Yv1kvWZ9aD1p/Wu9bX1vfXE9cz10/Xb9eP17PX09fz1BfYO9hb2H/Yp9jL2O/ZE9k72V/Zh9mv2dfZ/9on2k/ae9qj2sva99sj20/bd9un29Pb/9gr3Fvci9y73OvdG91L3Xvdq93f3g/eQ9533qfe298P30Pfe9+v3+PcG+BP4Ifgv+D34S/hZ+Gf4dfiD+JL4oPiv+L74zPjb+Or4+fgI+Rf5Jvk2+UX5Vflk+XT5g/mT+aP5s/nD+dP54/nz+QT6FPok+jX6RfpW+mf6d/qI+pn6qvq7+sz63fru+v/6Efsi+zT7RftW+2j7efuL+537rvvA+9L75Pv2+wj8Gvws/D78UPxi/HT8h/yZ/Kv8vvzQ/OP89fwI/Rr9Lf0//VL9ZP13/Yr9nf2v/cL91f3o/fr9Df4g/jP+Rv5Z/mv+f/6S/qX+uP7L/t7+8f4E/xf/Kf88/0//Yv91/4j/m/+u/8H/1P/n//r/DAAfADIARQBYAGsAfgCRAKQAtwDKAN0A8AADARYBKQE8AU4BYQFzAYYBmQGrAb4B0QHjAfYBCAIaAi0CPwJRAmQCdgKIApoCrAK/AtEC4wL1AgcDGQMrAz0DTgNgA3IDgwOVA6cDuAPJA9sD7AP+Aw8EIAQxBEIEUwRkBHUEhgSXBKcEuATJBNkE6QT6BAoFGgUrBTsFSwVbBWsFewWLBZsFqgW6BckF2QXoBfcFBgYVBiQGMwZCBlEGXwZuBnwGiwaZBqcGtgbEBtIG4AbtBvsGCQcWByMHMQc+B0sHWAdlB3IHfgeLB5gHpAewB70HyQfVB+EH7Qf5BwUIEAgcCCcIMgg9CEgIVAheCGkIdAh+CIkIkwidCKcIsgi8CMUIzwjYCOII6wj0CP0IBwkPCRgJIQkpCTIJOglCCUsJUglaCWIJaglxCXkJgAmHCY4JlQmcCaMJqQmwCbYJvAnCCcgJzgnTCdkJ3gnjCekJ7QnyCfcJ/AkACgUKCQoNChEKFQoZCh0KIAokCicKKgotCjAKMwo2CjgKOwo9Cj8KQQpDCkUKRwpICkoKSwpMCk0KTgpPClAKUApRClEKUQpRClEKUQpQClAKTwpPCk4KTQpMCkoKSQpHCkYKRApCCkAKPgo8CjoKNwo1CjIKLwosCikKJgoiCh8KGwoXChQKEAoMCgcKAwr/CfoJ9QnxCewJ5wnhCdwJ1wnRCcwJxgnACboJtAmuCacJoQmaCZQJjQmGCX8JeAlwCWkJYglaCVMJSwlDCTsJMwkqCSIJGQkRCQgJ/wj2CO0I5AjbCNIIyAi+CLUIqwihCJcIjQiDCHkIbwhlCFoITwhFCDoILwgkCBkIDggCCPcH6wfgB9QHyAe8B7AHpAeYB4wHfwdzB2YHWgdNB0EHNAcnBxoHDQcAB/IG5QbYBsoGvQavBqIGlAaGBngGagZcBk0GPwYxBiIGEwYFBvcF6AXZBcoFvAWtBZ4FjwWABXEFYgVSBUMFNAUkBRUFBQX1BOYE1gTGBLcEpwSXBIYEdgRmBFYERgQ2BCYEFQQFBPUD5APUA8MDsgOiA5EDgQNwA18DTgM+Ay0DHAMLA/oC6QLYAscCtgKkApMCggJxAmACTwI9AiwCGwIKAvgB5wHWAcUBswGiAZABfwFtAVwBSwE5AScBFgEEAfMA4gDQAL8ArQCcAIsAeQBnAFYARQAzACIAEAAAAO7/3f/L/7r/qP+X/4b/dP9j/1L/QP8v/x3/DP/7/ur+2f7I/rb+pf6U/oP+cf5g/k/+Pv4t/hz+C/77/er92f3I/bf9p/2W/YX9dP1k/VP9Q/0y/SL9Ef0B/fH84fzQ/MD8sPyg/JD8gPxw/GD8UfxB/DH8IfwR/AL88vvj+9T7xPu1+6b7lvuH+3j7avta+0z7Pfsu+x/7EfsC+/T65frX+sn6uvqs+p76kPqC+nT6Z/pZ+kz6Pvow+iP6FfoI+vv57vnh+dT5x/m7+a75ofmV+Yn5fflw+WT5WPlM+UD5Nfkp+R35EfkG+fv47/jk+Nn4zvjD+Lj4rvij+Jn4jviE+Hr4b/hm+Fz4UvhI+D/4Nfgs+CP4GfgQ+Af4/vf29+335Pfc99P3y/fD97v3s/er96P3nPeU9433hfd+93f3cPdp92L3XPdV90/3SfdD9z33N/cx9yv3Jfcg9xr3FfcQ9wv3BvcB9/32+Pb09u/26/bn9uP23/bb9tf20/bQ9s32yfbH9sP2wfa+9rv2ufa29rT2svaw9q72rPar9qn2p/am9qX2o/aj9qL2ofag9qD2n/af9p/2n/af9p/2n/ag9qD2ofai9qP2pPal9qb2p/ap9qr2rPau9rD2sva09rb2uPa79r32wPbD9sb2yfbM9s/20/bW9tr23fbi9ub26vbu9vP29/b79gD3BfcK9w/3FPcZ9x73I/co9y73NPc59z/3RfdL91H3WPde92X3a/dy93n3gPeH9473lved96T3rPe097v3w/fL99P32/fk9+z39Pf99wb4DvgX+CD4Kfgy+Dv4RfhO+Fj4Yfhr+HX4f/iJ+JP4nfin+LH4u/jG+ND42/jm+PD4/PgH+RL5Hfkp+TT5P/lL+Vb5Yvlu+Xr5hfmR+Z35qfm1+cH5zfna+eb58/n/+Qz6Gfom+jP6P/pM+ln6Z/p0+oH6j/qc+qn6t/rE+tL64Pru+vv6CfsX+yX7M/tB+0/7Xftr+3r7iPuW+6X7s/vC+9H73/vu+/37C/wa/Cn8OPxH/Fb8Zfx0/IP8k/yi/LH8wPzQ/N/87vz+/A39Hf0s/Tz9S/1b/Wr9ev2K/Zn9qf25/cn92P3o/fj9CP4Y/ij+OP5H/lf+aP53/of+l/6n/rf+x/7X/uf+9/4I/xj/KP84/0j/WP9o/3j/iP+Y/6j/uP/I/9n/6f/5/wgAGAAoADgASABYAGgAeACIAJgAqAC4AMgA2ADoAPgACAEYAScBNwFHAVcBZwF3AYYBlgGmAbYBxQHVAeQB9AEDAhICIgIxAkECUAJfAm8CfgKNApwCqwK7AsoC2QLoAvYCBQMUAyMDMgNBA08DXgNtA3sDigOYA6YDtQPDA9ED3wPuA/wDCgQYBCYENARCBE8EXQRrBHgEhgSTBKEErgS7BMgE1gTjBPAE/QQKBRcFJAUxBT0FSgVWBWIFbgV7BYcFkwWfBasFtwXDBc8F2gXmBfIF/QUIBhQGHwYqBjUGQQZMBlYGYQZsBnYGgQaLBpUGoAaqBrQGvgbIBtIG3AblBu8G+AYCBwsHFAcdByYHLwc4B0EHSQdSB1oHYwdrB3MHeweDB4sHkwebB6IHqgexB7kHwAfHB84H1QfcB+MH6QfwB/YH/QcDCAkIDwgVCBsIIQgmCCwIMQg3CDwIQQhGCEsIUAhVCFkIXghiCGcIawhvCHMIdwh7CH4IggiGCIkIjAiPCJMIlQiYCJsIngigCKIIpQinCKkIqwitCK8IsAiyCLMItQi2CLcIuAi5CLoIuwi7CLwIvAi8CLwIvQi8CLwIvAi7CLsIugi6CLkIuAi3CLYItQizCLIIsAivCK0IqwipCKcIpQijCKAIngibCJkIlgiTCJAIjQiKCIYIgwh/CHsIeAh0CHAIbAhoCGQIYAhbCFcIUghNCEgIQwg+CDkIMwguCCkIIwgdCBgIEggMCAYIAAj6B/MH7QfnB+AH2QfSB8sHxAe9B7YHrweoB6EHmQeRB4oHggd6B3IHagdiB1oHUgdJB0EHOAcwBycHHgcVBwwHAwf6BvAG5wbeBtQGywbBBrcGrgakBpoGkAaGBnwGcQZnBlwGUgZHBj0GMgYnBh0GEQYHBvwF8AXlBdoFzwXDBbgFrAWhBZUFiQV+BXIFZgVaBU4FQgU2BSkFHQURBQQF+ATsBN8E0gTGBLkErASfBJMEhgR5BGwEXwRSBEQENwQqBBwEDwQCBPQD5wPZA8wDvgOxA6MDlQOHA3kDbANeA1ADQgM0AyYDGAMKA/wC7gLgAtECwwK1AqcCmAKKAnwCbQJfAlACQgIzAiUCFgIIAvkB6wHcAc0BvwGwAaEBkwGEAXUBZwFYAUkBOgEsAR0BDwEAAfEA4gDTAMUAtgCnAJgAiQB6AGwAXQBOAD8AMQAiABMABAD2/+f/2f/K/7v/rf+e/4//gP9y/2P/VP9G/zf/KP8a/wv//f7u/uD+0f7D/rT+pv6X/on+ev5s/l7+UP5B/jP+Jf4X/gn++v3s/d790P3C/bT9pv2Y/Yv9ff1v/WH9U/1G/Tj9Kv0d/Q/9Av30/Of82vzM/L/8svyl/Jj8ivx9/HD8ZPxX/Er8Pfww/CT8F/wK/P778fvl+9n7zPvA+7T7qPub+4/7hPt4+2z7YPtU+0n7Pfsy+yb7G/sP+wT7+fru+uP62PrN+sL6t/qt+qL6l/qN+oL6ePpu+mP6WfpP+kX6O/ox+ij6HvoU+gv6Avr4+e/55vnd+dP5yvnC+bn5sPmn+Z/5lvmO+YX5ffl1+W35Zfld+Vb5TvlG+T/5N/kw+Sn5Ifka+RP5DPkG+f/4+Pjy+Ov45fje+Nj40vjM+Mb4wPi6+LX4r/iq+KT4n/ia+JX4kPiL+Ib4gvh9+Hn4dPhw+Gv4Z/hj+F/4XPhY+FT4UfhN+Er4R/hD+ED4Pfg6+Dj4Nfgy+DD4Lvgr+Cn4J/gl+CP4Ifgg+B74Hfgb+Br4GfgY+Bf4FvgV+BT4FPgT+BP4EvgS+BL4EvgS+BP4E/gT+BP4FPgV+Bb4FvgY+Bj4Gvgb+Bz4Hvgf+CH4I/gk+Cb4Kfgr+C34L/gy+DT4N/g6+Dz4P/hC+EX4SfhM+E/4U/hW+Fr4Xvhi+GX4afhu+HL4dvh7+H/4hPiI+I34kviX+Jz4ofim+Kz4sfi3+Lz4wvjH+M340/jZ+N/45vjs+PL4+Pj/+Ab5DPkT+Rr5Ifko+S/5Nvk9+UX5TPlU+Vv5Y/lr+XP5evmC+Yv5k/mb+aP5rPm0+b35xvnP+df54Pnp+fL5+/kE+g36Fvog+in6M/o8+kb6T/pZ+mP6bPp2+oD6i/qV+p/6qfqz+r76yPrT+t366Pry+v36CPsT+x77Kfs0+z/7SvtV+2D7bPt3+4L7jvua+6X7sfu9+8j71Pvg++z79/sD/A/8G/wn/DP8QPxM/Fj8Zfxx/H38ivyW/KP8r/y8/Mj81fzi/O78+/wI/RX9If0u/Tv9SP1V/WL9b/18/Yn9lv2j/bD9vv3L/dj95f3z/QD+Df4b/ij+Nf5D/lD+Xf5r/nj+hv6T/qH+rv68/sn+1/7k/vL+//4N/xv/KP82/0P/Uf9f/2z/ev+I/5X/o/+w/77/zP/a/+f/9f8BAA8AHAAqADcARQBTAGAAbgB7AIkAlgCjALEAvgDMANkA5wD0AAIBDwEcASoBNwFFAVIBXwFsAXkBhwGUAaEBrgG8AckB1gHjAfAB/QEKAhcCJAIxAj0CSgJXAmMCcAJ9AokClgKiAq8CuwLIAtQC4QLtAvkCBgMSAx4DKgM2A0IDTgNaA2YDcgN+A4kDlQOhA6wDuAPEA88D2wPmA/ED/QMIBBMEHgQpBDQEPwRKBFUEYARrBHUEgASKBJUEnwSqBLQEvgTIBNIE3ATmBPAE+gQEBQ4FGAUhBSsFNQU+BUcFUAVaBWMFbAV1BX4FhwWPBZgFoAWpBbIFugXCBcsF0wXbBeMF6wXzBfsFAwYKBhIGGQYhBigGLwY3Bj4GRQZMBlMGWgZhBmcGbgZ0BnsGgQaHBo4GkwaZBp8GpQarBrEGtga7BsEGxgbMBtEG1gbbBuAG5QbpBu4G8wb3BvsGAAcEBwgHDAcQBxQHGAcbBx8HIwcmBykHLQcwBzMHNgc4BzsHPgdBB0MHRgdIB0sHTQdPB1EHUwdUB1YHWAdZB1sHXAddB18HYAdhB2IHYgdjB2QHZAdlB2UHZQdmB2YHZgdlB2UHZQdlB2QHZAdjB2MHYgdhB2AHXwdeB1wHWwdaB1gHVgdVB1MHUQdPB00HSwdIB0YHRAdBBz8HPAc5BzYHMwcwBy0HKgcnByMHIAccBxkHFQcRBw0HCQcFBwEH/Qb4BvQG8AbrBuYG4gbdBtgG0wbOBskGxAa+BrkGtAauBqgGowadBpcGkQaLBoUGfwZ5BnIGbAZlBl8GWAZSBksGRAY9BjYGLwYoBiEGGQYSBgoGAwb7BfQF7AXkBdwF1QXNBcQFvAW0BawFpAWbBZMFigWCBXkFcAVoBV8FVgVNBUQFOwUyBSgFHwUWBQwFAwX5BPAE5gTdBNMEyQS/BLUEqwShBJcEjQSDBHkEbwRkBFoEUARFBDsEMAQmBBsEEAQFBPsD8APlA9oDzwPEA7kDrgOjA5gDjQOBA3YDawNfA1QDSQM9AzIDJgMaAw8DAwP4AuwC4ALVAskCvQKxAqUCmQKNAoECdQJqAl0CUQJFAjkCLQIhAhUCCQL8AfAB5AHYAcsBvwGzAacBmgGOAYIBdQFpAVwBUAFEATcBKwEeARIBBQH5AOwA4ADTAMcAugCuAKEAlQCIAHwAbwBjAFYASgA9ADEAJAAXAAsAAADz/+f/2v/O/8H/tf+o/5v/j/+D/3b/av9d/1H/RP84/yz/IP8T/wf/+/7u/uL+1v7K/r3+sf6l/pn+jf6B/nX+af5d/lH+Rf45/i7+Iv4W/gr+/v3y/ef92/3P/cP9uP2s/aH9lf2K/X79c/1o/Vz9Uf1G/Tr9L/0k/Rn9Dv0D/fj87fzi/Nf8zfzC/Lf8rfyi/Jf8jfyC/Hj8bvxj/Fn8T/xF/Dv8Mfwn/Bz8E/wJ/P/79fvr++L72PvP+8X7vPuy+6n7oPuX+437hPt7+3L7aftg+1j7T/tG+z77Nfst+yX7HPsU+wz7BPv8+vP67Prk+tz61PrM+sX6vfq1+q76p/qf+pj6kfqK+oP6fPp1+m76aPph+lr6VPpN+kf6Qfo7+jX6L/op+iP6HfoX+hH6DPoG+gH6/Pn2+fH57Pnn+eL53fnY+dP5z/nK+cb5wfm9+bn5tPmw+az5qPml+aH5nfmZ+Zb5kvmP+Yz5iPmF+YL5f/l8+Xr5d/l0+XL5b/lt+Wr5aPlm+WT5Yvlg+V75XPlb+Vn5WPlW+VX5VPlT+VL5UflQ+U/5TvlO+U35TflM+Uz5TPlM+Uz5TPlM+Uz5TflN+U35TvlP+U/5UPlR+VL5U/lU+VX5VvlY+Vn5W/lc+V75YPlh+WP5Zfln+Wn5a/lu+XD5c/l1+Xj5e/l9+YD5g/mG+Yn5jPmQ+ZP5l/ma+Z75ofml+an5rfmx+bX5ufm9+cH5xvnK+c/50/nY+d354vnm+ez58Pn2+fv5APoF+gv6EPoW+hv6Ifon+i36M/o5+j/6RfpL+lH6WPpe+mX6a/py+nj6f/qG+o36lPqa+qH6qfqw+rf6vvrG+s361frd+uT67Pr0+vz6A/sL+xP7G/sj+yv7NPs8+0T7TftV+137Zvtu+3f7gPuI+5H7mvuj+6z7tfu++8f70PvZ++P77Pv1+//7CPwS/Bv8Jfwu/Dj8QvxL/FX8X/xp/HP8ffyH/JH8m/yl/K/8uvzE/M782fzj/O38+PwC/Qz9F/0i/Sz9N/1B/Uz9V/1i/Wz9d/2C/Y39mP2j/a79uP3D/c792v3l/fD9+/0G/hH+HP4n/jP+Pv5J/lT+X/5r/nb+gf6N/pj+o/6v/rr+xv7R/tz+6P7z/v/+Cv8W/yH/Lf84/0P/T/9a/2b/cf99/4j/lP+f/6v/tv/C/83/2f/l//D//P8GABIAHQApADQAQABLAFYAYgBtAHkAhACQAJsApgCyAL0AyADUAN8A6wD2AAEBDQEYASMBLgE6AUUBUAFbAWYBcQF8AYcBkgGdAagBswG+AckB1AHfAeoB9QEAAgoCFQIgAisCNQJAAksCVQJgAmoCdQJ/AokClAKeAqgCswK9AscC0QLbAuUC7wL5AgMDDQMXAyEDKgM0Az4DSANRA1sDZANuA3cDgQOKA5MDnAOmA68DuAPBA8oD0wPcA+UD7QP2A/8DCAQQBBkEIQQqBDIEOgRDBEsEUwRbBGMEawRzBHsEgwSKBJIEmgSiBKkEsQS4BMAExwTOBNUE3ATjBOoE8QT4BP8EBgUMBRMFGQUgBSYFLQUzBTkFPwVFBUsFUQVXBV0FYwVpBW4FdAV5BX4FhAWJBY4FkwWYBZ0FogWnBawFsQW1BboFvgXDBccFzAXQBdQF2AXcBeAF5AXnBesF7wXzBfYF+QX9BQAGAwYGBgkGDAYPBhIGFAYXBhkGHAYeBiEGIwYlBicGKQYrBi0GLwYxBjIGNAY1BjcGOAY6BjsGPAY9Bj4GPwY/BkAGQQZBBkIGQgZDBkMGQwZDBkMGQwZDBkMGQwZDBkIGQgZBBkEGQAY/Bj4GPQY8BjsGOgY5BjcGNgY0BjMGMQYwBi4GLAYqBigGJgYkBiIGHwYdBhoGGAYWBhMGEAYNBgoGCAYFBgEG/gX7BfgF9AXxBe0F6QXmBeIF3gXaBdYF0gXOBcoFxgXBBb0FuQW0BbAFqwWmBaIFnQWYBZMFjgWJBYQFfgV5BXQFbgVpBWMFXQVYBVIFTAVGBUAFOgU0BS4FKAUiBRsFFQUPBQgFAQX7BPQE7QTnBOAE2QTSBMsExAS9BLYErgSnBKAEmASRBIkEggR6BHMEawRjBFsEUwRLBEMEOwQzBCsEIwQbBBMECgQCBPoD8QPpA+AD2APPA8YDvgO1A6wDowObA5IDiQOAA3cDbgNlA1wDUgNJA0ADNwMtAyQDGwMRAwgD/gL0AusC4QLYAs4CxAK6ArECpwKdApMCigKAAnYCbAJiAlgCTgJEAjoCMAImAhwCEQIHAv0B8wHpAd4B1AHKAcABtQGrAaEBlgGMAYIBdwFtAWMBWAFNAUMBOAEuASMBGQEOAQQB+QDvAOQA2gDPAMQAugCvAKUAmgCPAIUAegBwAGUAWgBQAEUAOwAwACUAGwAQAAYA/P/x/+f/3P/S/8f/vf+y/6f/nf+S/4j/fv9z/2n/Xv9U/0n/P/81/yr/IP8V/wv/Af/3/uz+4v7Y/s3+w/65/q/+pf6b/pD+hv58/nL+aP5e/lT+Sv5A/jb+LP4j/hn+D/4F/vv98v3o/d791f3L/cL9uP2u/aX9nP2S/Yn9f/12/W39ZP1a/VH9SP0//Tb9Lf0k/Rv9Ev0K/QH9+Pzv/Of83vzW/M38xPy8/LT8q/yj/Jr8kvyK/IL8evxy/Gr8Yvxa/FL8SvxD/Dv8M/wr/CT8HPwV/A38Bvz/+/j78Pvp++L72/vU+837xvu/+7n7svur+6X7nvuY+5H7i/uF+3/7eftz+2z7Zvtg+1r7VPtO+0n7Q/s9+zj7Mvst+yj7Ivsd+xj7E/sO+wn7BPv/+vr69vrx+uz66Prk+t/62/rX+tL6zvrK+sb6wvq/+rv6t/qz+rD6rPqp+qX6ovqf+pz6mfqW+pP6kPqN+or6h/qF+oL6gPp9+nv6ePp2+nT6cvpw+m76bPpq+mj6Z/pl+mT6Yvph+mD6Xvpd+lz6W/pa+ln6WfpY+lf6V/pW+lb6VfpV+lX6VPpU+lT6VPpU+lX6VfpV+lb6VvpW+lf6WPpY+ln6Wvpb+lz6Xfpe+mD6Yfpi+mT6Zfpn+mn6avps+m76cPpy+nT6dvp4+nr6ffp/+oL6hPqH+or6jPqP+pL6lfqY+pv6nvqh+qX6qPqr+q/6svq2+rr6vfrB+sX6yfrN+tH61frZ+t364vrm+uv67/rz+vj6/foB+wb7C/sQ+xX7Gvsf+yT7Kfsu+zT7Ofs/+0T7SvtP+1X7Wvtg+2b7bPty+3j7fvuE+4r7kPuX+537o/uq+7D7t/u9+8T7y/vS+9j73/vm++379Pv7+wL8CfwQ/Bf8H/wm/C38Nfw8/ET8S/xT/Fr8Yvxp/HH8efyB/In8kfyY/KD8qPyx/Ln8wfzI/ND82fzh/On88vz6/AL9C/0T/Rz9JP0t/Tb9Pv1H/VD9WP1h/Wr9c/17/YT9jf2W/Z/9qP2x/br9w/3M/db93/3o/fH9+v0E/g3+Fv4f/in+Mv47/kX+Tv5Y/mH+a/50/n3+h/6Q/pr+pP6t/rf+wP7K/tP+3f7n/vD++v4E/w3/F/8h/yr/NP8+/0j/Uf9b/2X/bv94/4L/jP+V/5//qf+z/7z/xv/Q/9n/4//t//f/AAAJABMAHQAmADAAOgBEAE4AVwBhAGsAdAB+AIcAkQCbAKQArgC3AMEAygDUAN4A5wDxAPoABAENARcBIAEqATMBPQFGAU8BWQFiAWsBdAF9AYcBkAGZAaIBrAG1Ab4BxwHQAdkB4gHrAfQB/QEGAg4CFwIgAikCMgI6AkMCTAJUAl0CZgJuAncCfwKHApACmAKhAqkCsQK6AsICygLSAtoC4gLqAvIC+gICAwoDEgMaAyEDKQMwAzgDQANHA08DVgNdA2UDbANzA3sDggOJA5ADlwOeA6UDrAOzA7kDwAPHA80D1APbA+ED6APuA/QD+wMBBAcEDQQUBBoEIAQmBCwEMQQ3BD0EQgRIBE4EUwRZBF4EYwRoBG4EcwR4BH0EggSIBIwEkQSWBJsEnwSkBKkErQSyBLYEugS/BMMExwTLBM8E0wTXBNsE3wTiBOYE6QTtBPAE9AT3BPsE/gQBBQQFBwUKBQ0FEAUTBRUFGAUbBR0FIAUiBSUFJwUpBSsFLQUvBTEFMwU1BTcFOAU6BTwFPQU/BUAFQQVCBUQFRQVGBUcFRwVIBUkFSgVKBUsFTAVMBU0FTQVNBU0FTQVOBU4FTgVOBU0FTQVNBU0FTAVMBUsFSgVKBUkFSAVHBUYFRQVEBUMFQgVABT8FPgU8BTsFOQU4BTYFNAUzBTEFLwUtBSsFKAUmBSQFIQUfBR0FGgUYBRUFEgUQBQ0FCgUHBQQFAQX9BPoE9wTzBPAE7QTpBOYE4gTeBNsE1wTTBM8EzATIBMMEvwS7BLcEsgSuBKkEpQSgBJwElwSTBI4EiQSEBIAEewR2BHEEawRmBGEEXARWBFEETARGBEEEOwQ2BDAEKgQlBB8EGQQTBA0EBwQBBPsD9QPvA+gD4gPcA9UDzwPJA8IDvAO1A68DqAOhA5oDkwONA4YDfwN4A3EDagNjA1sDVANNA0YDPwM3AzADKQMhAxoDEgMLAwMD/AL0AuwC5QLdAtYCzgLGAr4CtgKvAqcCnwKXAo4ChgJ+AnYCbgJmAl4CVQJNAkUCPQI0AiwCJAIbAhMCCgICAvkB8QHpAeAB2AHPAccBvgG1Aa0BpAGbAZMBigGBAXkBcAFnAV4BVgFNAUQBOwEyASoBIQEYAQ8BBgH9APQA6wDjANoA0QDIAL8AtgCtAKQAmwCSAIkAgAB3AG4AZQBcAFMASgBBADgALwAmAB4AFQAMAAMA+//y/+n/4P/X/87/xf+8/7P/qv+h/5n/kP+H/37/df9s/2T/W/9S/0n/QP84/y//Jv8e/xX/DP8E//v+8v7q/uH+2P7Q/sf+v/62/q7+pf6d/pT+jP6D/nv+c/5q/mL+Wv5R/kn+Qf45/jH+Kf4g/hj+EP4I/gD++f3x/en94f3Z/dH9yf3B/bn9sv2q/aL9m/2T/Yz9hP19/XX9bv1m/V/9WP1Q/Un9Qv07/TT9Lf0m/R/9GP0R/Qr9A/38/Pb87/zo/OL82/zV/M78yPzB/Lv8tfyu/Kj8ovyc/Jb8kPyK/IT8fvx4/HL8bPxm/GD8W/xV/E/8SvxE/D/8Ofw0/C/8Kvwk/B/8GvwV/BD8C/wG/AL8/fv4+/P77/vq++b74vvd+9n71PvQ+8z7yPvE+8D7vPu4+7T7sPus+6n7pfui+577m/uX+5T7kfuO+4r7h/uE+4H7fvt7+3j7dfty+3D7bftq+2j7Zftj+2H7Xvtc+1r7WPtW+1T7UvtQ+0/7TftL+0r7SPtH+0X7RPtC+0H7QPs/+z77Pfs8+zv7Ovs5+zj7OPs3+zf7Nvs2+zX7Nfs1+zX7Nfs0+zT7NPs0+zX7Nfs1+zb7Nvs2+zf7N/s4+zn7Ovs6+zv7PPs9+z77QPtB+0L7Q/tE+0b7R/tJ+0v7TPtO+1D7UftT+1X7V/tZ+1v7Xvtg+2L7Zftn+2n7bPtv+3H7dPt2+3n7fPt/+4L7hfuI+4v7jvuR+5X7mPub+5/7ovum+6r7rfux+7X7uPu8+8D7xPvI+8z70PvU+9j73fvh++X76vvu+/P79/v8+wD8BfwK/A/8E/wY/B38Ivwn/Cz8Mvw3/Dz8QfxH/Ez8UfxX/Fz8Yvxn/G38c/x4/H78hPyK/I/8lfyb/KH8p/yt/LP8uvzA/Mb8zPzT/Nn83/zm/Oz88/z5/AD9Bv0N/RT9Gv0h/Sj9Lv01/Tz9Q/1K/VH9WP1f/Wb9bf10/Xv9gv2J/ZH9mP2f/ab9rv21/b39xP3L/dP92v3i/en98f34/QD+CP4P/hf+H/4m/i7+Nv49/kX+Tf5V/l3+Zf5s/nT+fP6E/oz+lP6c/qT+rP60/rz+xP7M/tT+3P7k/uz+9P79/gX/Df8V/x3/Jf8u/zb/Pv9G/07/Vv9f/2f/b/94/4D/iP+Q/5j/of+p/7H/uf/C/8r/0v/a/+L/6//z//v/AgALABMAGwAjACwANAA8AEQATABVAF0AZQBtAHUAfgCGAI4AlgCeAKYArgC2AL8AxwDPANcA3wDnAO8A9wD/AAcBDwEXAR8BJgEuATYBPgFGAU4BVgFdAWUBbQF1AXwBhAGMAZMBmwGiAaoBsQG5AcEByAHQAdcB3gHmAe0B9AH8AQMCCgIRAhkCIAInAi4CNQI8AkMCSgJRAlgCXwJmAm0CcwJ6AoEChwKOApUCmwKiAqkCrwK2ArwCwgLJAs8C1QLcAuIC6ALuAvQC+wIBAwcDDQMSAxgDHgMkAyoDLwM1AzsDQANGA0sDUQNWA1sDYQNmA2sDcAN1A3sDgAOFA4oDjwOUA5kDnQOiA6cDqwOwA7UDuQO+A8IDxgPLA88D0wPXA9sD3wPjA+cD6wPvA/MD9wP6A/4DAgQFBAkEDQQQBBQEFwQaBB0EIQQkBCcEKgQtBC8EMgQ1BDgEOgQ9BEAEQwRFBEgESgRNBE8EUQRTBFUEVwRZBFsEXQRfBGEEYgRkBGYEZwRpBGoEbARtBG4EcARxBHIEcwR0BHUEdgR3BHgEeAR5BHoEewR7BHwEfAR8BH0EfQR9BH0EfQR9BH4EfQR9BH0EfQR9BH0EfAR8BHwEewR6BHoEeQR4BHcEdgR1BHQEcwRyBHEEcARvBG0EbARqBGkEZwRmBGQEYwRhBF8EXQRbBFkEVwRVBFMEUQRPBEwESgRIBEYEQwRBBD4EPAQ5BDcENAQxBC4EKwQoBCUEIgQfBBwEGAQVBBEEDgQLBAcEBAQABP0D+QP1A/ID7gPqA+YD4gPeA9oD1gPSA84DygPGA8EDvQO4A7QDsAOrA6cDogOdA5kDlAOPA4oDhgOBA3wDdwNyA20DaANiA10DWANTA04DSANDAz0DOAMzAy0DKAMiAxwDFwMRAwsDBgMAA/oC9ALuAugC4gLcAtYC0ALKAsQCvgK4ArICqwKlAp8CmAKSAosChQJ/AngCcgJrAmUCXgJXAlECSgJDAj0CNgIvAikCIgIbAhQCDQIGAv8B+AHxAeoB4wHcAdUBzgHHAcABuQGyAasBowGcAZUBjgGGAX8BeAFxAWkBYgFbAVMBTAFFAT0BNgEuAScBIAEYAREBCQECAfoA8wDsAOQA3QDVAM4AxgC+ALcArwCoAKAAmQCRAIkAggB6AHIAawBjAFwAVABMAEUAPQA2AC4AJgAfABcAEAAIAAAA+v/y/+v/4//c/9T/zf/F/77/tv+v/6f/oP+Y/5H/if+C/3r/c/9r/2T/XP9V/07/Rv8//zj/MP8p/yH/Gv8T/wz/BP/9/vb+7/7n/uD+2f7S/sv+w/68/rX+rv6n/qD+mf6S/ov+hP59/nf+cP5p/mL+W/5V/k7+R/5B/jr+M/4t/ib+H/4Z/hL+DP4F/v/9+P3y/ez95f3f/dn90v3M/cb9wP26/bP9rf2n/aH9m/2V/Y/9iv2E/X79eP1y/W39Z/1h/Vz9Vv1Q/Uv9Rf1A/Tv9Nf0w/Sv9Jf0g/Rv9Fv0R/Qz9B/0C/f38+Pzz/O786fzl/OD82/zX/NL8zvzJ/MX8wPy8/Lf8s/yv/Kv8p/yj/J78mvyW/JP8j/yL/If8hPyA/Hz8ePx1/HH8bvxq/Gf8ZPxg/F38WvxX/FP8UPxN/Er8R/xF/EL8P/w8/Dn8N/w0/DL8L/wt/Cr8KPwm/CT8Ifwf/B38G/wZ/Bf8FfwT/BL8EPwO/A38C/wJ/Aj8BvwF/AT8AvwB/AD8//v9+/z7+/v6+/r7+fv4+/f79vv2+/X79fv0+/T78/vz+/P78vvy+/L78vvy+/L78vvy+/L78/vz+/P78/v0+/T79fv1+/b79/v3+/j7+fv6+/v7/Pv8+/37//sA/AH8AvwD/AX8BvwI/An8C/wN/A78EPwS/BT8FvwX/Bn8G/wd/B/8Ivwk/Cb8KPwr/C38L/wy/DT8N/w5/Dz8P/xB/ET8R/xK/E38UPxT/Fb8Wfxc/F/8Y/xm/Gn8bfxw/HP8d/x6/H78gfyF/In8jPyQ/JT8mPyc/KD8pPyo/Kz8sPy0/Lj8vPzB/MX8yfzO/NL81/zb/OD85Pzp/O388vz3/Pz8AP0F/Qr9D/0U/Rn9Hv0j/Sj9Lf0y/Tj9Pf1C/Uf9Tf1S/Vf9Xf1i/Wj9bf1z/Xj9fv2D/Yn9jv2U/Zr9oP2l/av9sf23/b39w/3J/c/91f3b/eD95v3t/fP9+f3//QX+DP4S/hj+H/4l/iv+Mf44/j7+RP5L/lH+WP5e/mT+a/5x/nj+f/6F/oz+kv6Z/qD+pv6t/rT+uv7B/sj+zv7V/tz+4/7q/vH+9/7+/gX/DP8T/xn/IP8n/y7/Nf88/0P/Sv9Q/1f/Xv9l/2z/c/96/4H/iP+P/5b/nf+k/6v/sv+5/8D/x//O/9X/3P/j/+r/8f/3//7/BQAMABMAGQAgACcALgA1ADwAQwBKAFEAWABfAGYAbQBzAHoAgQCIAI8AlgCdAKQAqwCxALgAvwDGAMwA0wDaAOEA6ADuAPUA/AACAQkBDwEWAR0BIwEqATABNwE9AUQBSgFRAVcBXgFkAWsBcQF3AX4BhAGKAZEBlwGdAaQBqgGwAbYBvAHCAcgBzgHUAdoB4AHmAewB8gH4Af4BBAIKAg8CFQIbAiACJgIsAjECNwI8AkICRwJNAlICWAJdAmMCaAJtAnMCeAJ9AoIChwKMApEClgKbAqACpQKqAq8CtAK4Ar0CwgLHAssC0ALUAtkC3QLiAuYC6gLvAvMC9wL8AgADBAMIAwwDEAMUAxgDHAMgAyQDKAMsAy8DMwM3AzoDPgNBA0UDSANMA08DUgNWA1kDXANfA2IDZQNpA2sDbgNxA3QDdwN6A30DfwOCA4QDhwOJA4wDjgORA5MDlQOYA5oDnAOeA6ADogOkA6YDqAOqA6wDrQOvA7EDsgO0A7UDtwO4A7oDuwO8A70DvgPAA8EDwgPDA8QDxQPGA8YDxwPIA8kDyQPKA8sDywPMA8wDzAPNA80DzQPNA80DzQPNA80DzQPNA80DzQPNA8wDzAPMA8sDywPKA8oDyQPIA8gDxwPGA8UDxAPDA8MDwgPAA78DvgO9A7wDugO5A7cDtgO1A7MDsgOwA64DrQOrA6kDpwOlA6QDogOgA54DmwOZA5cDlQOTA5ADjgOMA4kDhwOEA4IDfwN8A3oDdwN0A3EDbgNrA2kDZgNjA2ADXANZA1YDUwNQA0wDSQNGA0IDPwM7AzgDNAMxAy0DKgMmAyIDHgMaAxYDEwMPAwsDBwMDA/4C+gL2AvIC7gLqAuUC4QLdAtgC1ALQAssCxwLCAr0CuQK0ArACqwKmAqECnAKYApMCjgKJAoQCfwJ6AnUCcAJrAmYCYQJcAlYCUQJMAkcCQQI8AjcCMQIsAicCIQIcAhYCEQILAgYCAAL6AfUB7wHpAeQB3gHYAdMBzQHHAcEBuwG2AbABqgGkAZ4BmAGSAYwBhgGAAXoBdAFuAWgBYgFcAVYBUAFKAUMBPQE3ATEBKgEkAR4BGAESAQsBBQH/APkA8gDsAOYA3wDZANMAzADGAMAAuQCzAK0ApgCgAJkAkwCNAIYAgAB5AHMAbQBmAGAAWQBTAEwARgA/ADkAMwAsACYAHwAZABMADAAGAAAA+v/0/+3/5//g/9r/1P/N/8f/wP+6/7T/rf+n/6H/m/+U/47/iP+B/3v/df9v/2j/Yv9c/1b/T/9J/0P/Pf82/zD/Kv8k/x7/GP8S/wz/Bv8A//r+9P7u/uj+4v7c/tb+0P7K/sT+vv64/rL+rf6n/qH+m/6V/pD+iv6E/n/+ef5z/m7+aP5j/l3+V/5S/k3+R/5C/jz+N/4y/iz+J/4i/h3+GP4S/g3+CP4D/v79+f30/e/96v3l/eD92/3W/dH9zP3I/cP9vv25/bX9sP2s/af9ov2e/Zr9lf2R/Yz9iP2E/X/9e/13/XP9b/1r/Wf9Y/1f/Vv9V/1T/U/9S/1H/UT9QP08/Tj9Nf0x/S79Kv0n/SP9IP0d/Rn9Fv0T/Q/9DP0J/Qb9A/0A/f38+vz3/PX88vzv/Oz86vzn/OT84vzf/N382vzY/NX80/zQ/M78zPzK/Mj8xvzE/MH8wPy+/Lz8uvy4/Lb8tfyz/LH8sPyu/Kz8q/yp/Kj8p/yl/KT8o/yi/KH8oPye/J38nfyc/Jv8mvyZ/Jj8mPyX/Jb8lvyV/JX8lPyU/JT8k/yT/JP8kvyS/JL8kvyS/JL8kvyS/JP8k/yT/JP8k/yU/JT8lfyV/Jb8lvyX/Jf8mPyZ/Jr8m/yc/J38nfye/J/8oPyi/KP8pPyl/Kb8qPyp/Kv8rPyu/K/8sfyy/LT8tfy3/Ln8u/y9/L/8wPzC/MT8x/zJ/Mv8zfzP/NL81PzW/Nn82/ze/OD84/zl/Oj86vzt/PD88vz1/Pj8+/z9/AD9A/0G/Qn9Df0Q/RP9Fv0Z/Rz9IP0j/Sb9Kv0t/TD9NP03/Tv9P/1C/Ub9Sf1N/VH9Vf1Z/Vz9YP1k/Wj9bP1w/XT9eP18/YD9hf2J/Y39kf2V/Zr9nv2i/af9q/2w/bT9uP29/cL9xv3L/dD91P3Z/d794v3n/ez98f31/fr9//0E/gn+Dv4T/hj+Hf4i/if+LP4x/jb+O/5A/kb+S/5Q/lX+Wv5g/mX+av5w/nX+ev6A/oX+iv6Q/pX+m/6g/qb+q/6x/rb+vP7B/sf+zf7S/tj+3f7j/un+7v70/vr+AP8F/wv/Ef8W/xz/Iv8o/y7/M/85/z//Rf9L/1D/Vv9c/2L/aP9u/3T/ef9//4X/i/+R/5f/nP+i/6j/rv+0/7r/wP/G/8z/0v/Y/93/4//p/+//9f/7/wAABgAMABIAGAAdACMAKQAvADUAOwBBAEcATABSAFgAXgBkAGoAbwB1AHsAgQCHAI0AkgCYAJ4ApACpAK8AtQC6AMAAxgDMANEA1wDdAOIA6ADtAPMA+AD+AAQBCQEPARQBGgEfASUBKgEvATUBOgFAAUUBSgFQAVUBWgFgAWUBagFvAXUBegF/AYQBiQGOAZMBmAGdAaIBpwGsAbEBtgG7AcABxQHKAc4B0wHYAd0B4QHmAesB7wH0AfkB/QECAgYCCwIPAhQCGAIcAiECJQIpAi0CMgI2AjoCPgJCAkcCSwJPAlMCVwJbAl8CYgJmAmoCbgJyAnUCeQJ9AoAChAKIAosCjwKSApYCmQKdAqACowKnAqoCrQKwArQCtwK6Ar0CwALDAsYCyQLLAs4C0QLUAtYC2QLcAt4C4QLkAuYC6QLrAu0C8ALyAvQC9wL5AvsC/QL/AgEDAwMFAwcDCQMLAw0DDwMRAxIDFAMWAxcDGQMbAxwDHgMfAyADIgMjAyQDJQMnAygDKQMqAysDLAMtAy4DLwMvAzADMQMyAzMDMwM0AzQDNQM1AzYDNgM3AzcDNwM4AzgDOAM4AzgDOAM4AzgDOAM4AzgDOAM4AzcDNwM3AzYDNgM2AzUDNQM0AzQDMwMyAzEDMQMwAy8DLgMtAywDKwMqAykDKAMnAyYDJAMjAyIDIAMfAx4DHAMbAxkDGAMWAxQDEwMRAw8DDQMMAwoDCAMGAwQDAgMAA/4C/AL6AvcC9QLzAvEC7gLsAuoC5wLlAuIC4ALdAtsC2ALVAtMC0ALNAsoCyALFAsICvwK8ArkCtgKzArACrQKpAqYCowKgAp0CmQKWApMCjwKMAogChQKBAn4CegJ3AnMCbwJsAmgCZAJgAl0CWQJVAlECTQJJAkUCQQI9AjkCNQIxAi0CKQIlAiACHAIYAhQCEAILAgcCAwL+AfoB9QHxAewB6AHjAd8B2gHWAdEBzAHIAcMBvwG6AbUBsQGsAacBogGdAZkBlAGPAYoBhQGAAXsBdwFyAW0BaAFjAV0BWAFTAU4BSQFEAT8BOgE1ATABKgElASABGwEWAREBCwEGAQEB/AD2APEA7ADnAOEA3ADXANEAzADHAMEAvAC3ALEArACnAKEAnACWAJEAjACGAIEAewB2AHEAawBmAGAAWwBWAFAASwBFAEAAOgA1ADAAKgAlAB8AGgAUAA8ACQAEAP//+v/1/+//6v/k/9//2v/U/8//yf/E/7//uf+0/6//qf+k/5//mf+U/47/if+E/3//ef90/2//af9k/1//Wv9V/0//Sv9F/0D/O/81/zD/K/8m/yH/HP8X/xL/Df8I/wP//v75/vT+7/7q/uX+4P7b/tb+0f7M/sj+w/6+/rn+tf6w/qv+pv6i/p3+mP6U/o/+iv6G/oH+ff54/nT+b/5r/mb+Yv5e/ln+Vf5R/kz+SP5E/kD+O/43/jP+L/4r/if+I/4f/hv+F/4T/g/+C/4H/gP+//38/fj99P3w/e396f3l/eL93v3a/df90/3Q/c39yf3G/cP9v/28/bn9tf2y/a/9rP2p/ab9o/2g/Z39mv2X/ZT9kf2P/Yz9if2G/YT9gf1+/Xz9ef13/XT9cv1v/W39av1o/Wb9Y/1h/V/9Xf1a/Vj9Vv1U/VL9UP1O/Uz9Sv1I/Uf9Rf1D/UH9QP0+/T39O/05/Tj9N/01/TT9Mv0x/TD9L/0t/Sz9K/0q/Sn9KP0n/Sb9Jf0k/SP9I/0i/SH9IP0g/R/9Hv0e/R39Hf0c/Rz9G/0b/Rv9G/0b/Rv9Gv0a/Rr9Gv0a/Rr9Gv0a/Rr9Gv0b/Rv9G/0b/Rz9HP0c/R39Hf0e/R79H/0g/SD9If0i/SP9I/0k/SX9Jv0n/Sj9Kf0q/Sv9LP0t/S/9MP0x/TL9NP01/Tf9OP06/Tv9Pf0+/UD9Qf1D/UX9Rv1I/Ur9TP1O/VD9Uv1U/Vb9WP1a/Vz9Xv1g/WL9ZP1n/Wn9a/1u/XD9c/11/Xj9ev19/X/9gv2E/Yf9iv2N/Y/9kv2V/Zj9m/2d/aD9o/2m/an9rP2v/bP9tv25/bz9v/3C/cb9yf3M/dD90/3W/dr93f3h/eT96P3r/e/98v32/fr9/f0B/gX+Cf4M/hD+FP4Y/hz+IP4k/ij+K/4v/jP+N/47/j/+Q/5H/kv+UP5U/lj+XP5g/mT+af5t/nH+dv56/n7+g/6H/ov+kP6U/pn+nf6i/qb+q/6v/rT+uP69/sH+xv7L/s/+1P7Y/t3+4v7m/uv+8P71/vn+/v4D/wf/DP8R/xb/Gv8f/yT/Kf8u/zL/N/88/0H/Rv9L/1D/Vf9a/1//Y/9o/23/cv93/3z/gf+G/4v/kP+V/5r/n/+k/6n/rv+z/7j/vf/C/8f/zP/R/9b/2//g/+X/6v/v//T/+f/+/wIABwAMABEAFgAbACAAJQAqAC8ANAA5AD4AQwBHAEwAUQBWAFsAYABlAGoAbwB0AHkAfQCCAIcAjACRAJYAmwCfAKQAqQCuALMAtwC8AMEAxgDKAM8A1ADZAN0A4gDmAOsA8AD0APkA/gACAQcBCwEQARQBGQEdASIBJwErAS8BNAE4AT0BQQFFAUoBTgFSAVcBWwFfAWMBaAFsAXABdAF4AX0BgQGFAYkBjQGRAZUBmQGdAaEBpQGpAawBsAG0AbgBvAG/AcMBxwHLAc4B0gHWAdkB3QHgAeQB5wHrAe4B8gH1AfkB/AH/AQMCBgIJAgwCEAITAhYCGQIcAh8CIgIlAigCKwIuAjECNAI3AjoCPQI/AkICRQJHAkoCTQJPAlICVAJXAlkCXAJeAmECYwJlAmgCagJsAm4CcQJzAnUCdwJ5AnsCfQJ/AoECgwKFAocCiAKKAowCjgKPApECkwKUApYClwKZApoCnAKdAp4CoAKhAqICpAKlAqYCpwKoAqkCqgKrAqwCrQKuAq8CsAKxArICsgKzArQCtAK1ArYCtgK3ArcCtwK4ArgCuAK5ArkCuQK5ArkCuQK6AroCugK6AroCugK6AroCuQK5ArkCuQK4ArgCuAK3ArcCtwK2ArYCtQK0ArQCswKyArICsQKwAq8CrwKuAq0CrAKrAqoCqQKoAqcCpgKkAqMCogKgAp8CngKdApsCmgKYApcClQKUApICkQKPAo0CjAKKAogChgKFAoMCgQJ/An0CewJ5AncCdQJzAnECbwJsAmoCaAJmAmMCYQJfAlwCWgJYAlUCUwJQAk4CSwJIAkYCQwJAAj4COwI4AjYCMwIwAi0CKgInAiQCIQIeAhsCGAIVAhICDwIMAgkCBgICAv8B/AH5AfUB8gHvAesB6AHlAeEB3gHbAdcB1AHQAc0ByQHFAcIBvgG6AbcBswGvAawBqAGkAaABnQGZAZUBkQGNAYkBhQGCAX4BegF2AXIBbgFqAWYBYgFeAVkBVQFRAU0BSQFFAUEBPAE4ATQBMAEsAScBIwEfARsBFgESAQ4BCQEFAQEB/AD4APMA7wDrAOYA4gDdANkA1ADQAMsAxwDCAL4AugC1ALEArACoAKMAnwCaAJUAkQCMAIgAgwB/AHoAdQBxAGwAaABjAF8AWgBVAFEATABIAEMAPgA6ADUAMQAsACcAIwAeABoAFQAQAAwABwADAP//+v/2//H/7f/o/+P/3//a/9b/0f/N/8j/xP+//7v/tv+x/63/qP+k/6D/m/+X/5L/jv+J/4X/gP98/3j/c/9v/2r/Zv9h/13/Wf9U/1D/TP9H/0P/P/87/zb/Mv8u/yn/Jf8h/x3/GP8U/xD/DP8I/wP///77/vf+8/7v/uv+5/7j/t/+2/7X/tP+z/7L/sf+xP7A/rz+uP60/rD+rf6p/qX+of6e/pr+lv6T/o/+jP6I/oT+gf59/nr+dv5z/m/+bP5p/mX+Yv5e/lv+WP5U/lH+Tv5L/kf+RP5B/j7+O/44/jX+Mv4v/iz+Kf4m/iP+IP4d/hr+GP4V/hL+D/4N/gr+B/4F/gL+AP79/fr9+P32/fP98f3u/ez96v3n/eX94/3h/d793P3a/dj91v3U/dL90P3O/cz9yv3I/cb9xP3C/cH9v/29/bv9uv24/bf9tf2z/bL9sP2v/a79rP2r/ar9qP2n/ab9pP2j/aL9of2g/Z/9nv2d/Zz9m/2a/Zn9mP2X/Zf9lv2V/ZT9lP2T/ZL9kv2R/ZH9kP2Q/Y/9j/2P/Y79jv2O/Y39jf2N/Y39jf2N/Y39jP2N/Y39jf2N/Y39jf2N/Y39jv2O/Y79j/2P/Y/9kP2Q/ZH9kf2S/ZP9k/2U/ZT9lf2W/Zb9l/2Y/Zn9mv2a/Zv9nP2d/Z79n/2g/aL9o/2k/aX9pv2o/an9qv2r/a39rv2w/bH9s/20/bb9t/25/br9vP2+/cD9wf3D/cX9x/3I/cr9zP3O/dD90v3U/db92P3a/dz93v3h/eP95f3n/en97P3u/fD98/31/fj9+v39/f/9Af4E/gf+Cf4M/g7+Ef4U/hb+Gf4c/h/+If4k/if+Kv4t/jD+M/42/jj+O/4//kL+Rf5I/kv+Tv5R/lT+V/5a/l3+Yf5k/mf+a/5u/nH+df54/nv+f/6C/ob+if6N/pD+lP6X/pr+nv6i/qX+qf6s/rD+tP63/rv+v/7C/sb+yv7O/tH+1f7Z/t3+4P7k/uj+7P7w/vT+9/77/v/+A/8H/wv/D/8T/xf/G/8f/yP/J/8r/y//M/83/zv/P/9D/0f/S/9Q/1T/WP9c/2D/ZP9o/2z/cP91/3n/ff+B/4X/iv+O/5L/lv+a/57/o/+n/6v/r/+0/7j/vP/A/8X/yf/N/9H/1f/a/97/4v/m/+v/7//z//f/+/8AAAMABgAKAA4AEwAXABsAHwAkACgALAAwADQAOQA9AEEARQBJAEwAUQBVAFkAXQBhAGUAagBtAHEAdQB5AH0AgACEAIgAjACQAJQAmACcAKAApACnAKsArwCyALYAugC+AMEAxADIAMwAzwDTANcA2gDeAOEA5ADoAOwA7wDyAPUA+QD9AP8AAwEHAQkBDQEQARMBFwEaAR0BIAEjASYBKQEtAS8BMwE1ATkBOwE+AUEBRAFGAUoBTAFPAVIBVQFYAVoBXQFgAWIBZQFnAWsBbQFwAXIBdQF3AXoBfAF/AYABgwGFAYcBigGMAY8BkAGTAZUBlwGZAZsBngGfAaIBowGlAacBqQGrAa0BrwGxAbIBtAG2AbgBuQG7Ab0BvgHAAcEBwgHFAcYBxwHJAcoBzAHNAc4B0AHRAdMB0wHUAdYB1wHZAdkB2gHcAdwB3gHeAd8B4QHhAeIB4wHkAeUB5QHnAecB6AHpAekB6gHqAesB6wHsAe0B7QHuAe4B7wHvAe8B7wHvAfAB8AHwAfAB8QHwAfEB8QHxAfEB8QHxAfEB8QHxAfEB8QHwAfEB8AHwAe8B8AHvAe8B7gHuAe4B7QHtAewB7AHrAesB6gHpAekB6AHoAecB5gHmAeUB5AHkAeIB4gHhAeAB3wHfAd0B3AHcAdoB2QHYAdcB1gHVAdQB0wHRAdABzwHOAc0BzAHKAckBxwHGAcUBxAHCAcEBvwG9AbwBuwG5AbgBtgG0AbIBsQGvAa4BrAGrAakBpwGmAaQBogGgAZ8BnQGbAZkBlwGVAZMBkQGPAY0BiwGJAYcBhQGEAYIBgAF9AXsBeQF3AXUBcwFxAW4BbAFqAWgBZgFjAWEBXwFdAVoBWAFWAVQBUQFPAU0BSgFIAUUBQwFBAT4BPAE5ATcBNQEyATABLQErASgBJQEjASABHgEbARkBFgEUAREBDwEMAQkBBwEEAQIB/wD8APoA9wD1APIA7wDtAOoA5wDlAOIA3wDcANoA1wDUANIAzwDMAMkAxwDEAMIAvwC8ALkAtwC0ALEArgCrAKgApgCjAKAAngCbAJgAlgCTAJAAjQCKAIcAhACCAH8AfAB5AHcAdABxAG8AbABpAGcAZABhAF4AWwBZAFYAUwBQAE4ASwBJAEYAQwBAAD0AOwA4ADYAMwAwAC0AKwAoACUAIwAgAB4AGwAYABYAEwAQAA4ACwAIAAYAAwABAP///P/6//f/9P/y//D/7f/q/+j/5f/j/+D/3v/c/9n/1v/U/9H/z//N/8r/yP/F/8P/wf++/7z/uf+4/7X/s/+w/67/rP+p/6j/pf+j/6H/n/+c/5r/mP+W/5T/kf+P/43/i/+J/4f/hf+D/4D/f/98/3v/eP93/3X/c/9x/2//bf9r/2n/Z/9l/2P/Yv9g/17/XP9b/1j/V/9V/1T/Uv9Q/07/Tf9L/0n/SP9G/0X/Q/9C/0D/Pv88/zv/Of84/zf/Nf80/zL/Mf8v/y7/Lf8r/yr/KP8n/yb/Jf8k/yL/If8g/x7/Hv8c/xv/Gv8Z/xj/F/8W/xT/FP8S/xH/EP8Q/w7/Df8N/wz/Cv8K/wn/CP8H/wb/Bv8F/wT/A/8C/wL/Af8A///+//7+/v7+/f78/vz++/76/vr++v75/vn++P74/vf+9/72/vb+9f71/vX+9f70/vT+9P7z/vP+8/7y/vL+8v7y/vL+8v7x/vH+8f7x/vH+8f7x/vD+8f7x/vH+8P7x/vH+8f7x/vH+8f7x/vH+8f7x/vL+8v7y/vL+8v7z/vP+8/70/vT+9P70/vX+9f72/vb+9v73/vf+9/74/vj++f75/vn++v77/vv++/78/v3+/f7+/v7+//4A/wH/Af8C/wL/A/8D/wT/Bf8G/wb/B/8I/wn/Cf8K/wv/DP8N/w7/D/8P/xD/Ef8S/xP/FP8U/xX/Fv8X/xj/Gf8a/xv/HP8d/x7/H/8g/yH/Iv8j/yT/Jf8m/yf/Kf8p/yv/LP8t/y7/L/8w/zH/Mv80/zX/Nv83/zn/Ov87/zz/Pf8//0D/Qf9C/0P/Rf9G/0f/SP9K/0v/TP9N/0//UP9R/1P/VP9V/1f/WP9Z/1r/XP9d/1//YP9h/2L/ZP9l/2f/aP9p/2v/bP9t/2//cP9y/3P/dP92/3f/ef96/3v/ff9+/3//gf+C/4T/hf+H/4j/if+L/4z/jv+P/5D/kv+T/5X/lv+X/5n/mv+c/53/nv+g/6L/o/+k/6b/p/+p/6r/q/+t/67/sP+x/7L/tP+1/7b/uP+5/7v/vP+9/7//wP/C/8P/xP/G/8f/yf/K/8v/zf/O/8//0f/S/9P/1f/W/9f/2f/a/9z/3f/e/9//4f/i/+P/5P/m/+f/6P/q/+v/7P/t/+//8P/x//P/9P/1//b/9//5//r/+//8//7///8AAAEAAgADAAQABQAGAAgACQAKAAsADAANAA4AEAAQABIAEwAUABUAFgAXABgAGQAaABsAHAAdAB4AHwAgACEAIgAjACQAJQAmACcAKAApACoAKwAsAC0ALQAuAC8AMAAxADIAMwAzADQANQA2ADcAOAA4ADkAOgA7ADwAPAA9AD4APwA/AEAAQQBBAEIAQwBDAEQARQBGAEYARwBHAEgASQBJAEoASgBLAEwATABNAE0ATgBOAE8ATwBQAFAAUQBRAFIAUgBTAFMAVABUAFQAVQBVAFYAVgBWAFcAVwBXAFgAWABZAFkAWQBaAFoAWgBaAFsAWwBbAFsAXABcAFwAXABdAF0AXQBdAF4AXgBeAF4AXgBeAF8AXwBfAF8AXwBfAF8AXwBfAF8AXwBgAF8AYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAXwBfAF8AXwBfAF8AXwBfAF8AXwBeAF4AXgBeAF4AXgBeAF0AXQBdAF0AXQBdAFwAXABcAFwAWwBbAFsAWwBaAFoAWgBaAFoAWQBZAFkAWABYAFgAVwBXAFcAVwBWAFYAVgBVAFUAVABUAFQAVABTAFMAUgBSAFIAUQBRAFAAUABQAE8ATwBOAE4ATgBNAE0ATABMAEwASwBLAEoASgBJAEkASQBIAEgARwBHAEYARgBFAEUARABEAEMAQwBDAEIAQgBBAEEAQABAAD8APwA+AD4APQA9ADwAPAA7ADsAOgA6ADkAOQA4ADgANwA3ADYANgA1ADUANAA0ADMAMwAyADIAMQAwADAAMAAvAC8ALgAtAC0ALQAsACsAKwAqACoAKQApACkAKAAoACcAJwAmACYAJQAkACQAJAAjACMAIgAiACEAIQAgACAAHwAfAB4AHgAdAB0AHAAcABwAGwAbABoAGgAZABkAGAAYABgAFwAXABYAFgAVABUAFQAUABQAEwATABMAEgASABEAEQARABAAEAAQAA8ADwAOAA4ADgANAA0ADQAMAAwADAALAAsACwAKAAoACgAKAAkACQAJAAgACAAIAAgABwAHAAcABgAGAAYABgAFAAUABQAFAAUABAAEAAQABAAEAAMAAwADAAMAAwACAAIAAgACAAIAAgACAAEAAQABAAEAAQABAAEAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==","base64");
	var clap = Buffer("UklGRsRiAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YaBiAAAAAKb/jwEN/mYORR/MJcQHQAXjBr/Uz8gexmTQaLygwsqu4cVeN8c5ww/i8kX65BhWKBkseEA2QRYwphzqDkYdNxRsFYAr3Qr3/icaFx5vKG8qYx+KFvAQ8Akm7+ziRNX1uYeqSrF9z77RfMmw1F7sLQLf8xL3k/N3/4sPZBdmFNwS8xYCDKoB0Q+bGycaUQlK+FLz8PLt/av/hw2HDr8F5gz8CP0f0yNSG80Q5PVoFUYcIgtp/L7si/TF+YAFOwFwCBn6aOdb2z3gtuYI27HtKPym/hwDOBPTE2cN7w1FE3kE0PsA/B/sTPZf/OD9mvaY+n/0ofKq+LP9ZQPR8Ab2/ANoAmb+iAVVAnD8Rgj2AIYEmA/TEdAUvBS2C6YCoAtRCTEG7AbJAnUEfwHn81bxwOqR6pD8IP5+BUML0Q+GEL4Co/xJ+Q7x5vYS+kHy7+3w9pEAXAFjCWUN4//S9c35lACxCPYC4ANw/1gE1wOJAVv7HPm/+5z/7AbiA4QJCwZZBu0FyQmiBr0Ah/xU8BjxF/ZX9+b7wPysBCsP1Q7ICaYEZwhdBYEBnwVI/Wn0K/XP+aT/jQGTA2f+5fmk/OH6+vz0AU8CbAHEAf/55/k3AOP8RAFGCIL+Hv2vBAwG2wXs/30FGAcUBEEDbvvz/F8ATgZqBN37Avvd+jn3KvsSA2IDmQCc/Qn6QvlX/p8F9gbZDMgKQAbCA5P8H/2L+9T5+vtk+o74u/kS/QMCzAGk/lz/T/7j/okBUQB/Aa8EKgQEBjwIbwQZAg79L/j/+uMAzQXfAAABbv/C+aD9Ff1a/bX86/rh+/T6zvrP/38FLAJcA0AAnP1NAyYChgTvA+ADqAcVCAcFNwYoCQUFAARgAGD9e//iASr/Lf37/n39m/10/Pj9WwC1+6f6WPrg+9L5Z/lC+8L7z/4EAEgDiQHAAa0A6ADr/4H+t/7PARsDjgPkBWsEtAL/AKYB6gAGARsCVwGJAYUAqv++ACIBhP68/fX/QQEwAVACqwJfADL/o/wP/mICrgHr/6f+fv2k/Vj92PxZ/mIAbAA8/8z+zABSA4wEoAIAAksBfQHLATcBPgGNAL3/xf+W/wsA5AF+AcIBVQAv/+IAGQDMAPoAV/6c/C7+L/8bAOv/rQDnABz/hv5g/7T/uf+v/3/+2/+R/0z/iQBsAOgA+ABrAeUCKQIoAgcD1AObArEBhAHl/jn/rPydAbr68SCUQ/ZHnEMgJ08SyPiW+53fd+VK6QDiTfUc0afBFtft9b/+IeIf6twACATk/jAMVRbFGBke7ROyGt8Qpurs6czd9tus4kfZJey759IMexQlG04VXPTQAp35wAM+6sDzJQe++oz9QxYpKe0d+RQ6D9IjVS57InMbdR6jDdXu4N2T4VT5xxcUGbsT4QtK/Dn/2+YO0LfH/9YU6b/wUNxO25betd5Q7g7yJP4gAFUFxhRjEmUaSzdPNV8NFQZEBGEPriZbExQZVht3EH3++QXiDO34PO+C5qjVFNGJ7HD19/0n9yP+IQtgFKcePBNWBysRnA9+DQMILwLUBXfzf/cq8yXqpvn99zTsqOYE8A//R/1q8kn1//u19toD8woUD2kBVvRL/YT30PPLBYULmhOsJVYm5CIYGNsQXQ2UCsAOYw5OEpMbfgQa/8H6KOv76GTe89/l5+fmY/X/+Xj5J/kh8HTuo+kt7ffrxu/L+1sJfgG++jEEkv5VCWkQtxMTGc0PPxyFGmIY0BzPEfsPWxBpCtL9IAJ7B6MCb/cu9TX38fXn9GLwZe9B9Gr+8ACu/oj9u/gU9PPyCfjlAgsDgvct+msMuxCGCYoGPBDVC/sG6ANIBnv/pP9bB3b9bPb392DyOfHB/5cCwQDsAtwBxAPN+wD5Pv6a+uj+twcvEd4Q+wsQDFwLzQgQCw8PqA3IBhQDVP2l+vv4zfQS/eT9SQK/+tzz0fgI9g30O/Y//CT9GgT1ASUEiwcWA2cCgPnB+538sPoYAgYFgQepCYsDzgS6BN4DvAJUBPcFAAMjBd0Gjwh0B00DvwC4+k77C/dR9bP37AJvBVz+2AMOAgICdP/N+L37+fub/sn/lgIKBQ7+AP0RBWgHjwSLAoz/BAQQCKgHDAciBccBfwWZCHUCIAXZBsADGwQpA0YFygDX/foBf/2x/dT+ofuM/bz92fkh/y8EJAEQAh0FRgI+AaQCzAMtAZX9DQKM/8P+rvxH/aUC+P60+kn9IP9U/rn9lwJcA2QCIP9L/PT9KgEwBjgGsARBBdQFKAVjAzcD2AMJAMMBjwIZAZYDzwHr/oX9tf5bANAA0QK5AKAB8wB8/f7/fgFzAIgDUQVKBCECXgIvA5sBZQMDBFkCkgC6AVIB/gBUApABcACFAZgBagHHA84DRQOYAokAY/6T/fn73/y5/qb/RwBtAMz/9f0wADsDEgNCA/QDJAXGBQ8GewUMBC0FwgRsA3ICev+z/DP7XPww/mb+Mv/2/7r/9QBWADH/Jv9qAIX/kP7m/p/+3/7X/n//x/9d/0sA6gAXAoICggL4A90FGAVxBUoGIwZ+BF4BcwIsAXwA5f7w/z0A+ABmAT0B+AI/7EviBfZxG+sZSxIuEGkG3ASNDP8YRgAL8lv4BfLL6Hfqfub01zz7BByhBGgG3Qmb57He5v2QIaMV+BFAB1sQ8g856X76DQewCToISAUZAxgCuhWTG8kfEhBq/LsObwbq63jtAfH17bv7NA9sD/QVNxlKEz8Nrgq5CPv2G+zl2brdNvBm/H3/4f9//JT0Gwhx72fyIQwj/tALrBHbAFMJ2wsDDMgRxwbZCMf6FuG63FDn+OY64Ajihepr9cH7TPP5/vYeri4/K1IWswQSBZwMzv5GA0cbZyBVIGQcBxpPFUMOjQ4THAEc2Qdu+3D6/vkA/kzmIedT7u3wwe9H4Ib37e+C6UzrU+qH/IX2kOwI8Bj76PnW7aPs2vLc8Lb6ogVNBVIEDQluGfYeBxQpFKMfgBdGGs4Tkg2nEy0GT/wn+tn5RPUz8Vf3LQTo/jsBwwb1AcTxpvPQ9X32b/J88csCngZy/wIAKPwQ9fn4DvmB+17+Lgh4Amj7kvo7+2ABrgzTBI0GMQ3KBSsG+v/RBkIHlQABAs4ISgsIE3Ia1Q9aBVwCxgVV+1fyYOnM7pXx1OW96ELuTPlp/tMBbQVbBdoCv/xiALkBLgg8FwUX3xbrC2cLyxE9DscLKQjwAzoAuvph8X32EvvF/lUA8wCpBJb94/oP/joFTAO2/0z+Tfzv+Vb6vvyy/7MGe/w3/GYCtPzqAQAABfkl9sHzZPrmAgIInARwAHoBEQUoA4UC2gHxAU0DJgPx+2r32vzT+r0CUAXABTsCjvYk9mP7QQDaAnAD8wNlBsf/ovzn/XX/mwCv/3gDBgYLBP4GPwzSB4IFpgCf+v303vcY/uL8w/r9+QX5Ef4yAgcD3gV+A9MD0//c+Gb7Ov2a/ur/Kv4PAT4BOAAABLkE/gQoBI8Amv/gAswCVwOmAwUEkgXzAEn99/0BAE3/lwKDAvUGTwj3BQUBv/69/bH7TgEyAPP7IfrY96r7jPze+/j8xPsX/0n/BAS5Eg0N5QGM/8sMvh/fIZgm/hke/371tAb49ZvO1ef64VjX+uZQ8NwIUuWo76oH6g0e9qvyMBKADiHyivncEqEjTSI0DRsesiDyIakhogu1BLECWyNMJuP2UOsO5JDe1tK/2kPXf95s8QTu3dbo5TMEx/z08BfZZ/uZDFwOyBJS7LzQU84tAI4biRtqE/AjxkwqYBo7ARKW9xv/1RkXGKMa8hx7DsAEhQHb+iDtq8in2Kf0Lf0J9pztetxq3sbvfhw8Gfz/egUq7i/aDd6u9yz2b/UbC3YJQxHWHtwY4iXeK0YcHv9p5O7h9/D74Z/4Rv1C3YrtpChjGSf26RA5Hx0iPxbkGEAS3wvd/FzpkfUM4nve8tyd29EBhvcn/476FNLq8csfzxNoFzop8C4OJ/sLhu0l/Z8SShSeCVbxGfr0Cb7xFtef1L7EbsxC1DjMCbpW1ukKIRueL/VDRVFcNxAiTx8pEM0NAxDgCxQEfPyQAz4OzBZ3FIAeVf+j/W0qlQNdz5XMP9Vs5j3pvM1hyfW4JdJ/4FHsZBv+CaQTPR3GDxwM2wDS6bTiyvqGB+8NDCCHK8L/6QWZGT4WaQ1YAdcf0hrSA+8VmgF8+kH2Y/KV/8QUFAE29hIHhf1p+hfqM/OV7SbppeeF9SD72u8x/H4OfRovDMcWZQ0633nTZe+ZBbsRbh4lFdUF/PqDDlPzbuZtDd0aoyB/DsEWkRj8Ir4cvgKX+PXgnun86Wf2TgBS9h/9OvpnANoHQPd75BXbfOWV+YT/LiT9DcL0bgMyAE4KLQmI8Kf6fgnkAVQNdxXFGC0cGwvsBRQM9Qhl9h8CsAGXA6n3DNF1v/TcGPZm70r4d/Im9Yji0dv/2E/faPFACxgephCQHY0dDh5PKGg4TULZGSv11/rv7Szz9fCS5dn30Ph3FgQk6hTc+/3lm/SpATD56fmp9hjn7eQ349H3UAwhA8v/rfkQAXT3JwvGGvAImhdrHZYRNgofC24DkgpfEOP99g0DFEwGGP+a8//0FOuX9cTzufk9EYX3uAPWAgjd2etb9SPplOlt9KfvDPAu+1oLiAr28EX7weys+PsBOP4aHH0epQNN9V8UjCLLISsapBmRF5ogHh4VFggTmBWUDtD4Hvo276jOHtFU8LLq1edY5nvfS+eP3bfhPu9X8/H4+wOI/jgASw7xBEYRcRqxEzokbSAwABgOihYhEJD8JN+Y6+XhQuHe+QkEMhN9HRcLwAgSFHIFIf/++R/6OPQu4fLcrcl22Y31nwVbD2AQjgMTEmkALfXeDQ0bRR/BHwcmaBoXIkUiTDHNIiwLCP5c3zDi0u5W8jDrKtHHzSvZEN/640X0KfEB6ErxAPKmBFIR6R70LPs5mDi+KFwT1Pxl8dHlCd1Qzo/hN/yn/DsLoAy+ESgFRQPM9KLvKPeS+IcXWRXsGEUUZvKW8+zpA+JW71XwJ+0y8Ij+Hg1aEY8XcDBGMYkdpArgGjIT3QEl9HX0H/n9+d8FRfe/8wz5IPGW75TlpfhQ/CLupg6EADv1R+4H7Fnx4eLI8psB+fud9xIGKw8//KsFShRKHhcWqh34LI0YRxSgBdf5ZPqg75r+OPj1/oAOZBLrGDEMyf419IXsKOag5mnl3Nid5IbvWOj14IHLSOcSAyoE+AwfDYAP6BfSGLwVxSABGR0pAzMwJesWTQ4GBhP24uv54Wf1iwHg8Nnw/Pg17+/q3gD4DagHSPvW63Ph/enT647v2fyu9732TPbr/EcGVP7S9oLpQPlGDRkk1ilmK/MxWx0lFBIEG++o+cQMbRec/zz6zgfsDeAKa/wRBWHvt+Gx4lTeQdVjxnzRYt+k5dj93QrfDrUQogjtCcQCLAehFFkSNgn8FLwc/AmLCwEIiw6TI/kXtgrgBQEF8/5s8rvxPwihF9wSJAf5+ITvOu2p39jTe+u7//z5jPa04lbjcOW77Abu7ebu6Zr4hwJOC0AsiCz5HiMfFSM8FikRahdBB3kMKBNlCNIKM/eb6ePoDuvk7Znwevhw8uD1CPIA/JUCrPzLCykFigjKDl0NwhIjAn7rnPuR8gbpRAV1BFz4g+9733/PR9y96Njp/vwHBsMaTBvDHgYn2SIODWMB3RWbIEscNSQkI6ofySB5FgsPlPqn+Fz3HvMy3CnHUMwf0JTRvNbU7avuPNpu58v+LQ01C9kMZA8OFTkTXhUjDBX/WwbpBRT0Wv4CCgkIKg2LBA0BjP3DAnEGTgM1Bdby/fn496fwQwYB/5EEeA4ADhQMAP3o9N79aww5FBsccAdi9yIBhPaw9RP9SwUJEUAUjA6H81Tu0v5W7AjuK/k9+/f9EQd3DOD/zgfyByf8kfbM6OPqKfGN+qH/ogABEHER2QtA/5T0J/VzBTX72PwQ9472yAFu9PX0BgXEB3j7O/uiAPwCugLpC5oQgRWEESgG/AFj+RQChgYU8xf5mvsb+0b9jQTHAxD8/wVT/r34kfeH/VQQVRDHDOYQARGYCAIHh/xB9Dv/Kv396hHnc9wQ4sjhO98/57Ljr+sX60X5GgtYD3cQmRDTE4sRlhUeDHEQBCIIIRQTYxh8HRQldC75HQoSpgXUAqQApOsR4O/gGuff2iXpFPJE5bHncd0u4SDeneBf74r+UgjW/on9W/Mo+poMghPFF50ighcjHRMr+SyxLpYZqxrEFL0EFf259uzvVOnn5UfmyenI8CPx1/DL7zfrf+Yk4g7p3ebe/CkI1fxmBGcMEhO4IMwQqhaRFgoJCgOh/mYHewLMC58KSwBdAN0FvxCIDZz9yvNJ7n/q/N6r48fxt/Od+5UB4/6xA94FnQUYBnkHlxDlCZX50vh19x8E/hUCEG8L8P4o9/P9cQIZ/2P3PPtV+RD6efye9TT4/ACkAjACPADP9EP7uvwV+1v+agGdBXMHDQiVDe0Z7hkpFoEQmAtBCnQBlPRV8GTt5P+i6pLp+P2D/48FFPyT7/3oN+4p4j3g9O2W/pgPbgmyB8EPvhUVFPQYbRQdDYELLgWUEQsTQgKL+iXygPBL+73+e/YU6oDySgLGBdr6YvzwBJsDVAQu/xMDZgLtBEYLE/2N/QQFLgc9ApD1sfYb8ePqZefO6JD3j/4PCzMLXgQHCW4KCA/9FOsGZgm7A9//mwHI8o3pS/Fv/dgDbf7O+yH6AQTPBPkFugnqB/wTWAhQBZgFOhUBCwD0v/rA+iz9avvnAGMJ5Pxv9xv10vBD6Xr2xfqQ9c8ELP7K/JoC3QJzCToH3w/wAk4AERJQD/0P5BAcB+H/DP23+D7+Nfy9/An19+r76Z3unOwU7/n1zPctBNcDvAfjFlEXmBrsEKULPRChCdIHq/w5/DH5U/0MBM33Hfu5A+gDtfri9RoC+gh4CJH/8/wo9TLx6e2N4jDoJepR93v1O/x+/Xr7Qw12EEAJVfDF9GDvr/RwAPkHJRwzIMsfZxDSDu4I4gTwAcoDpQg19h77pv+//XIBiPQq+YsFQfwz+hD58f7yCCIEI/1q9cHxlPHr/ur8lvWh+rr8BvwFAPP6J/fz/eP/OQV7/wYBhg1zDP0PFRibGrcUexGKFC0T9g9RBfr35flR+7H5xfRH93rvxPGa7wPmrvAy9ibrD+36+d8Bsv8v+kUALgAtCC8PYA56Bc/2/u7n8HL0G/zx/uP7r/mV+qICdge9A1cCngosC6USjhCCDssOIAZUCY0HkgcJAY0DgQeFBFMLnggX+m71nfVl8gL4NPkd+xz7zf2//SH+FP3U+hz2mvO+ANUEJRCzDur+HAKSADz8/gHxAUABvQjfCEYENAgJA54HGgnP/agC9f4R98T+Q/0s9d/xl/Bt78zq6fVuAZgFqgb8/pcGLAbsAbD+GgPyAzoD/AvrB9EGUABwAA/2dPN99B3rFvL19Zr4Vf1JCjAKAQK9Ex8NgvvGAPoMuw22B98FWP/DATsG3wLAAwT+7Pg6/TD+jgMeBjYEAfqt9Br7nfep+Tf6sfe577D3bfvn+kP1//cj/Iz7UgZdCAYJGwWbCVgTXwXbAn4HCwsjB6QJ8wYl/bz8f/7MAk4DDgUyAcv9Av8mAB78Uf49BiIERAJVAnP12P7NA5X9FP+U/Yn5XPOh+zwBOgPAAY/8cfpi/iT7CvLh+Ln7MvZC8ND3ivgFAOQDyAToDpIP5gylBAsIzQnKBl0I2wIr+3L1x/e8+PH+FgVQ/wv86fNz63/qrvPW+t35ewBaCmYMGQ/BE10U7xVPFB0O3QI8ANcA0/4BAEf5Wf1r/X77IwiQBE0C8QFiAkz+OwE9/z39kgAB/yQFTQXUAP8ABv0+9Ir0kPOu9Rf6cPrW+FL4XPao9RP4FfcB+qP4a/HX7mL5OAJzA2QJewpODLwP7wwDCYQDDgS7B4QGeQmXCOkBegOfDbQKLgNaBSgCygiaD14LkgVjAbkBPv1p9SH2/vhz+sHz0fGv9n/y8PKR9v/24PEZ7zryu/dm9nX06P8dAmYGOgOp/boFgQebBp4FLAMHBZMELglTDgUMoAv8DakM/gkYCsEM9A2pD2oNNgNz/dD2+vn5/lD5BfZW9z34Fvhm+gX5Zfd5/NEAzwEnAmAAdf3d+4L64/l29VX5hvnZ9R38dAWWDpkKygQJBccEAANuAo3/8Pz1/Yf9qABT/qr3T/u29W33k/kr/Gn/0Py/A+YENP0W/a3/zwE8BYb/sgWfDjgKTQWJCjoKHQg+BV8C9/l07uHuP/TM/+oAnf1E+2H8mv0QAlwBbAKWCMMD2QKe/439lv+FA18Exv+6/b8ATQITALMD/wbwACADYAq0C40IdwPuAU4KwgZ4/mgAJPub+XP6rvi+/AoDPwGs+dv0+PQa+BX3V/ZW+aL2q/fk93/7GfwG+5f/IgOVB5QOCw6bC24OlgXI/dL/Cf6k/bb96f1GACAEDwWiA8gBtARmB+f+qAJnB9H/Rviw9Ur73wFuBdQDHwVSA/b++gFIAuv+1Pa39MLxIPd5/iP0a/av+1oAowOcAHP/dgB9A6oArgBhARj8Mv5HBfsHlwcbBBwBBAa8C6oJjAdBAbv9MQIWBJIGJgOw/K365vqO++X/5AQ8Bw0DgAC9/an06PJK8//xyfeH9nz7N/4p+3X8ePkp+oP/ngeEBWcBAwXBBVIIdwnQC/IJhgv8BlsC+Qp+CNACWgTuArP+9AA3/tr9Vvtf/Yr9ufzp/hX5KPgZ9sL1EvuG/dr9OPzP9+/3N/ng+0X/ugBfAh0D9wDRBiUJKwl5CbwKRwv3CNEH3wYbBk0BcgNbASn67Pnr/C7/kf5Q+2f4B/l7+sr8eQCkAGb+F//a/z0B5P9O/Tz/sv9N//kBrAJt/pT6yvly+634oPgF/t3+/v4CBWMGhwEDAtIBNggrCOwHBAcfA/AEwgbzCqkIGAGX/+X+oP6G/mL/awChAPYBXQEF/9L9EQOB+6n4ev1J+5/6JvvB/dT6zfbl9dP1AffA9BT4nvyxAA8E9gT6BrcDjQVmBWEC1AJzBGUJrgptBdoCBwL4Anb/9/vw+eT2HvcN/PX+ffyu+5gAbgaABLYBvwH8BU4HKgQz/4380vhx9uj7rQA3ADgBTQGN/WT9SQBd/j//VAIgAo0Bh/81BNQEVAXNB44FdQVOAkf9Yv97+7/6M/h+9W/7jPx//mQDrAE5/y//9f7jAh0FPAVeAXAF3QfCBsAEAABS/93+XQErALr+NAAA/dv8UP+6/5sBaAFVAzEDegI/A5ABawMZB44FZQKZAYj/5/++AHD9P/mT+L72mPXA9a74XP3OAGIA1AOLBpcDiARyBPgDgwLH/4D+nP+1AI0DxgM1BPcB/fhZ9hL4n/yh+239VP8I/6D+Af5FAcsAKAEABGYGHQQVAuECXP9p/wr+rf77AWgCcwKwARAEXgOmA5gDWv/YAWEBzgDo/nf+sf+Q/z8Cuf8Z/dL+L/9VAXP9sPhc+BP4Gfu6/Sb8YfpT+Tz6Y/kc/lsEFwISAnkBPP8l/g8BSwUgCKkGHQf9CMcJ8AZ2AxYEugEUBVsGDgNb/1z9ef1A+9D6Vv4b+1X5bPcB+NH4yfRe+rb6kvv5AfgFsATNBVQIJgi2BJwF9gaXCFIFogM8BiUGLwPyAIwEigSIAkz9o/24/gL++Pqj+Bj4KvVw9yb3cfkE/LD5/PnH/C3+5/7b/6kATQRDBvoHLQnLB68FfAN/AN/9Mf9MAAX/cf74/eYAjgHtAYUBV/4//gr/Hvyo/UT/KAOkBWcCpf9Q/z0CvQDAAasBcACX/wz9Hvyp/Mj9oQGvAk7/7P6c/hMApgHNAR0EngAM/4MAfv5VAK3/ffwy/tAA0wCdALAAWf9HAQT+zPzO/JoAtwFp/Vb/2QIWAuACMAXfAWYEvgSfAf8CbwRxArL+hf7a/qn9s/6G/Gz4EPqG+Ur5Bfmr+If5J/zgAgICJQSSBhEGVwcnBqwIIwcnBbUDRgBjA0MDFQShA1UAH/5p/nH8RPoI/QD8z/2U/QX9KgCI/4UCZAG7AhgFDgUhBrYFKQb/BJEFTACc/L78zPmv+NP5XfsS+fv4j/o6/MD6xPr++5n7nvy9++P7tvqM+oz8kv/w/pUAXgSYBdcFiwXXBaEGsgixCs4Lcgm6CX0K9wj+B0AERgF1/8z/4v6G/Jv7yPkD+jj7A/4c/a36nPt5+gD6IPzl/Cf9v/0LAY8AR/zU+/H+of/XAlIBgP+GAwwF1gNEA9oB3wKbCGgIpwYjBg0DBf/v+wn7wvua/Jz8y/3p+7n8V/5//K774fy4/Z38df/7/3P/T/59/9ABxwAFAH3/EwGxAbf/rP7R/44CcAIcAJ4BQgN/AigCHgM6A5f/JP35/0v/igDTAasBTgJkABv+Nf3j/SD+hv4D/LP90PxF/cX+jgCeAaEAHAQWBO4D1ANjAQv/qf7CAd8C9gOEBiIFbQM3Avz/RAFs/S//j/7Y+24AUf1M/QL/xPyz/fj7Vv5HAscBuQIyA+YD2gUGBywGdAZQBRABg/7R/fT9lvuN+Fb2KPlr+9b8rf4F/6D+av2xAGf/P/0C/Sv+k/9y/bX+af9g/4v/9/2S/xT+rwGdArj/GAAgAoEDpQVAB8ME9AMlBL8C6P94AOcCxf+E/V/+fv3w/eb+pAGOA1ECPALEAvUBNwE4AdECZgKTADH+lv3SAMwBFwLaARACYQS3AmEAQv/P/zMARf6z/Wb9wfyi+9L9uf2W/Pn9DP+4/aX6jvxM/8P7WfqE/VgAaABIAdcB5QGVAmQBegKdAeEBqgGb/+P/C//rABMBEQC2/QD+YQCvAZgC6wTlBekElgYQBLIAhv/y/DX8rPu4/W//sAB//gn/5gCPAGoCMQFAAAcCsAF4AHX/UQCpAMj+cf9a/ysBNgICAcAB/AJCAg4Aov+cABYASv7++9T6bPux/H39t/3r/9n//QDSAt8BbwJvBNkDSwOkAun/5f5V/TL9OfzK/ab/Y/2C/eD+XP92AOwBTgA//9z/vgJNA3oBCwLsA8YF5QSrAd0AJf/y/Mf76fs0/eX8l/5y/cb+Tv8F/8r/4P7SACIBxwHb/gv+nwBNAIABMv/o/rMBNQN4A3gDVAXQBDUFXAUVBRAFfwPV/w//uf4X/A/5Tvrs/Fb7/Pwl/Zj8rvsz+u373P1KAJwAnwIsAz0DvgT4BOIDKAPRAx8DAwP4AuQAa/9m//b+hP+vAAkCsAHt/of/cwBu/kP/hv9s/mT8Bv9BAC4AsACP/2L/zf4DAJf/wv7w/iP/Rf0//SL/jwGJAoEAPgAhAJ3/jwAGAJv/9v+l/hEAxwEdAncCtgIpARECwwGv/9f/VgAO/4z/1QFSAuQBJwIIA/wC6wDA/gf/0//H/1oAW/9c/jL//f/v/fH8Uv4j/eH8VP3F/Q4Al/4R/QT/of53AGgB3ALoAkIBRQNfAyMC0QE5AvsCdAPkAnACMwL8AXv/xf5PAtcC1gIiAu0AbAB7AIoAbv8Y//D+b/8w/1b/J//K/h0AQwEt/+L+//5q/fD8xfx4/Zf8bP0+/Ib8Cv1l/Xr+mP/gAB0ApP/r/wT/GQDc/43/dgE9AYgBMgF1AGsCcAHKAAwDWgHJAP4ApwKQASIADgHVAVACIQK4Ae0BzAAMAEr/YP+jAEsABwE8AZYBMwH1AMX/av6U/s7+DP74/iQAQACbARQBOgDR/27/vf7T/h3/jv2M/TP9pv7+/xsADv83APQAEgHLAaoCfwE8AL8ABgPeAkkBHALVALb/CP4p/3oAPwBAAIkAjgE9AkkCXwH5/4j/LwCx/9H+0vwW/uv/n/9v/3P+VABhAi8DiwPSAqIC8gHnAPr/3P+1/nj9M/1P/vD+Qv8h/3D/ff9v/k3+Sv05/osAIgE8AagADQFxAqoChAPUA4ECLgDE/7T/RP4Q/vn8mf3Y/T39d/2b/vv95/6eAAgBQACq/0UBogEjA5AC5ABOAsUC2wLUA1MEWgWWBO8ChQE0AbwALv8Z/7P/j/9ZAFgAPP8R/5T98/zP/YL9c/5k/oX9R/0T/VD+gv6i/zkAKwD7/t7+rf9r/38AMQEiAGf/7f/GADT/VP7g/40AwACpAE0A9P8JAYACxgIUA1YCbQLWA/AC5AFHAXoBIQINAdz/AP///er9f//6/vf+RP9W/zH/Z/3m/SD/DQAdANT/lP43/m//pf57/of+WP7V/hT/xv/f/2cAWgFeAaAB8wFrA1gEcwMgBJ4DLQQiBSsEWwNGASIBGwHy/6H/5f6z/sf+lfyO+wv9Lfy4/P79mv0q/qb/Sf8P/y8AoQBpADMAfwCiAJABZgA+APQAjwGZA9YCWAPzAgcCmwFLAtsCjwHn/zT/IP+KAEUBKADYABEAZ/6g/Iv9n/3u/LP+nv6n/wAAnQB+AXgBhQFuAAYBDwF9AIAAAQDx/47/tf+E/xH/df4v/2b/c/8WAOn/PgCLAfgAwgCBAYsBwQFPAIX+kf4R/7//z/+a/rD+uf6w/r7/QAByAmwDZAILAw8DlwHYAHoAugDgANP/XgDRAGgA+v+AAHMASv+K/uL+kv+y/9/+Of7m/gX/SgBm/5z/4wHcAEEAm/+j/63+lv4e/+gARAG+/4oA2f9l/3H/b/+h/67/cP5M/hT/4P78/t7+Sv9YACX/X/6v/oT+0/9kAVgCRwLcAk4DxgKdAdgBIQOdApkCHgMsA+MBy//h/Wn9dP0c/i3+0Pxm+1/8uf0i/kgApgBMAFsBRwHrARADkgK0AqkCHQKIAvQBwQFoArQD5wNaAksBbAA2/3L/t/91/6L//P8GAAAAlQDJ//P/6/9c/0r/rP8FAJoARwFbAWUBhAHvARIBMgDY/+b/Yf+z/nj+Vv5S/pH9//wE/bb8uvwh/ef9oP5iABYAwP/G/7D/GwHpAcgBkQGLA9oC1QKfA/4BXQGsAIMA+/9MACgAUAABARoBUwD6/8n/ZP8rACUAhADb/6f/rgCTAEcADgDR/9X/j//b/iD/8f/p/9//H/8l/mT+W/+0AJUAegBMAM7+R/8XAEEA4wCsAXQCnAH2ADUBJQFvAWsBNAGX/3D+dQDrABv/dP5O/j7+6v4h/hz9aP0Z/sv9+v1E/lb+n/5a/4QAJAE0AM//2AAWAcMBDgJfAg8D9wKyAkoDhAPUAxIEjgS9BAkE2wLKASkBCgDr/9H+tf20/f79ov4i/m3+9/13/aj9pv0K/uj9NP63/sX/FgAXADYA6/9LAEcAygCMAIkAIALNAocBAgESARACQgKfAYMB0AEQAsYB8gHiAcIAAwCAAF0AbgBwANT/Wv8q/wL/NP/s/jf/h/9cAEcAif6o/pT+8P38/bD9Mf52/+r/GQD5/yIAeADz/pb+4P4//w0AJwCmAFQBqgB1ALIARgAlAa0AyP9lANH/lv9k/7X/NgAiABgBfAHZAYQB7gBOAUMA8f80AFsAKgHVAXkCPQI1AqsBZgGYASECoQGsAHEA9f8hAHYAfQDq//n/5v8+AKQAZQAjAAcAcADD//z/9/8u/8n+HP5c/uH8sPzv/K/8D/2L/fP9tf5d/2sA4wBZANEA6QBuAQcBIwHUAZYB3QGxAbwBzAEyAroCyQIlA9ICLAGRAREC2wCcAN0A+v8m/0X/o/4X/77//v4c/vb9Ff7a/Z/92P0j/0//NgBXAID/l/92//X/bQCiAPUAPQEAAfUAKgEeAfT/f/7m/hH/fP/l/0H/Af9H/3L/w//bAOEA5ADpAOEAWAFiAQACHgJmAj8CsAL/AqwC6gLpARgBowAL/5L+O/8n/wz/ev/S/oz+Dv9f/ysAjABwAGYA6P/KAF0BeAF3AH//zv+x/7f/MACD/+n+Mv+X/5f/Kv9w/0cAtwBxAAYBLAGqACcBQQGfAPL/qf9P/+v/+P9x/30AWgHiARsCawINAugBUwHlAFAAPgAhAHv/7P4B/1X/cv///vj9ev5q/pX+Wv/l/u7+VP+N/zUAgAHhARQC+wH9Af0BogG3AdoBjQEaAVEBTAHmADAAJQDT/5T+cf7P/t7+2/7s/oT+bf7N/n3/o/+G/xz/2P4K/1//CAAQAPUAogGvAoYD0QPfAw0DtwJcAsABrgD8/+z/QP/V/iz+Bf46/gj+tP1w/Y79AP7K/v7+Sv/T/0kAZQDGAG8A2v81AE8AIAFQAb8BbAHdALQAeQCyAG4AjABeADUAcAAuAFAAiAB/AN8ACQHpAAUBtgA8AOP/6P+B/7L+3f7q/kj/M//x/2IAYQCsAAkAJAAHAE4AiwBIACABXgGlATcCUgKcAh0C/wGLAmgCtwFLAe0ABQHVAPQAsACR/9v/LQDK/1X/sP4E/uv8S/wk/DT87fyB/e39Jf45/u/+jwBGAbQABwHvAWMCWwJEAqQCMwNXA5kCEQJWAsIBlQEhAYcAhABQAAsAsP9d//v+xP7A/ir/Vv/Y/rX+aP4K/9r+5f51/5v/+/+y/4gA9wAOAU4BcwFlASgBMQGGAEcA5v8dAC4Avv+P/4H/3f/7/3v/pP69/hv/F/+2/gr/Gf9q/8//JQBcADcAbADWAO4AiQDNAG4BKQLkAu0CKwMdBOMDKQT1A60DoQOJAnMCwAFWASQBwgA2AHz/ov47/v79tv2+/Wf9X/1x/Rz9VPwG/CH8Wvy8/Mn8v/ze/GP9kP7q/jv/WgCEARYCkgI+A8ID+gMaBPsDmANkA8ACJQJfAfoAxAB8AHwARQDP/03/3/5n/oL+Yf6O/nX+C/4p/oL+Dv9k/xAAewCsAN4A3gDxAPAALgFnAUsBeQHTAeUBvAGoASkBbQF0AS8BoAFWAfAArAChAIcAaQBXAIj/K/8W/wT/Sv7D/Xr9if20/Qz+qP4p/7T/QQDPAAgB1AEGA8kD7wOXA0QDKAO4AksCOgFIANH/Qv+R/vD9FP4d/gf+8f10/gT/jv9//2z/VADzANYAPgD6/5P/Hf+L/uL9I/4j/t396/3J/bH+Of+G/53/9f9WAIkAQQFiAaoB8AEXAjICywECArACywIjApcBFAEfAJ7/1/9AAKQAGgGnARIC3QG8AasBdQE/Aa4AZwAXANb/hP/9/k//S/+9/sj9Qf2w/Uz+nP6i/kT/fv9d//b/QwCbADoBJwGcAK8AmAB6AP4AOwHzAHUADADb/wIA6P/r/5f/Y/8MAPn/cgCPAJEAzADiAEABMwGtAeUBBQJqAYEApQDyABkBwAAhAAEAsf+L/2v/D//U/sr+4P47/1b/oP8JAOv/FwBRAAUA4P+3/9L+h/4H/wj/0v62/rD+5f5l/6//AwBdALoA7wADAWYB4wFlAuICbwPfAy0EfwSrBNgEogQ9BHoDwAIlAmcBfQBU/23+XP13/P77n/v9+yL8W/z6/D39qf39/UD+ff7F/lb/CABKAJMAwAC8AHwAXADcADAB9AEEArkBrwHKAeAB9QH3AZEBgwE0AQ4BJgHpAMwANADi/4r/Tf8h/yb/Jv/6/jT/yf52/kf+Ov6L/sD++v5S/2P/rP/h/73/4/88ALQAGAFDAT0BLwFQAYMBFwGyANAAFgH6ACoB1wDkAHIBQQEHAbAA5gAIAcYAnwAuAPL/ev/z/sT+uv5B/6T/rf92/5D//f9YAKIApADkABUBwAC3AN4AMQEAAX4AYADc/5H/ev9d/07/BP87/7b/FACtACgBLwEHAVUBUAHrALUAnwCDAJsAygCEAKYAawA0ACsAagDAALcAnAD1/8j/nf+d/3//ev+V/+/+7/5k/3H/TP95/8r/GQCgAJUAdQCUAHIAIQAuAI0AFAGvAcYBoQGwAaoBnwFiAVABswAXAPP/tf8eADAAMwBYAD4ACgDo/+X/kv8y/w7/Ff8n/9P+sf7E/rz+Cf9n/3//wv/G/8T/z/+0/xUAKADeAFkBZAF2AZsBvwHaARACugFeAbwAOABGAHoASgBVAKMAqgBXAOT/bv8E/5v+0v4t/z3/uv8MAAUAoQANAecAgADk/9r/MgAUALT/5f9DAGUAoADMAKYA3QAGAScBWwESAaAAQADM/+3/7P8AAOv/x/88AGcAYgBhAHIAigDJAI8AaQBuACQAnf8G//v+C/8S/5T/6P/4/+z/uf/s/2gAPwHIAZQBZwEPAXwAKQAWAJX/Dv8f/+7+uv7t/mf/AQBxAFQACgArABwAJgCPAAIBfwH9ASUCOgIKAtsBgwEsASMBrQAnANf/l/9w/yH///4W/wn/Cv+L/18AGwG7ASECEQJrApsCSgIMAqgBNwETATEBAgGoADIA+v/y/+D/Wv+2/hX+BP4V/vf93v3X/Qz+C/4k/jT+Tv6J/mP+tv5m/67/DQAXAJUA4wCcAIkAjQCaAMoAKAFNAagBmwHjATQCJAIMAgQCIgIVAgkC6QG6AUQBxAClAFAAwv8L/5P+Sv5k/ub+vP7G/u7+Ef8f/13/sv/l/ywATQB+AI0ApQAkAXMBcwELARQBEwEkAWcBEAEmATUBQQElAR8B3wBtAGEApP/0/rH+Tv4p/iP+IP4P/hz+hP72/n//RgCpADkBmQGnAWcBaQGeAW4BdQGYAc0BbgFXAVMB9ADJAD4AGQBZABoAyf84/9j+9/7P/oP+pf6s/p/+tf6P/rb+w/7i/kP/lv8zAIsA9QBzAbUBXALQAi8DQAMzAz0DNgM1AxUD2gKbApwCFAK1AVwBqwDcAMUALgCR//f+Qf6r/XL9/vxO/Xz9//zh/H795v0s/kv+K/5g/sT+N/8z/z3/jv/C/zQAmQDVABgBVgF2AXwB+QF2An8ChAKRAjECpwFuAVEBIQHfAJ0AiABdAEwAOwARADMALAASANv/lf+H/5T/ev9K/zL/EP8N//7+KP9Y/5D/0v86ALcA2gAwAWgBDQHOANwANQFSAQAB2gCcAFEASQBXAAIAlf9c/z//f/+B/5f/oP+p/xMAnAC/AGoAEAB5/0v/iP+4/wUASABoAEQAYgCJANIAEQGrAD4A8v/P/9P/rP/M/ycAbQDaADIBSQF2AZsBnwFqAQkBvQBZAND/hP9l/w3/Iv82/xz/R/+0/zoAwwD8ACoBXwEgAd4ANgDx/+r/j/97/1L/Tv9t/9f/CgD7/4cA7AAQAWwBngHmAdsBywG+AX0BKwEOARIB1wC9AJoAogChAIgAeAAAAGT/4v6I/k7+Af61/ZP9x/3u/Sf+j/7S/gj/dP8lAOAAYgG/ASYCjALPAuECUgO2A58DkQMYA0oC0AE1ASgAZP/W/n7+X/4q/iz+CP7j/dL97v36/fP9JP4+/mz+vv7j/nT/MgAcABkABABoABUBDQHCAMQA9wD0AOkA4ADVAJ8AxQBTAZYB1AH+AUMCUAJFAj4CGwLIAY0BjgFLAfcAgADt/2z/Nv8F/8f+gf5e/j7+Pv5Z/nj+0/4K/zL/Nv9R/8r/bgCxANcABgEzAXQBPQHtAMcAoACmAK4AlwCBAH8AfgChALEABwEaAfQAjQBUACwAEAAwABsABgADAL7/P/8W/wz/0/53/g/+C/4z/kL+zf4j/2P/ef/r/1UAswBJAZoB9QE0AqsCRQNxA1UDQgMlAy0DKQPaAn8CJAKpAVUB8gByAK3/2P5I/tn9l/1U/Tn9SP09/Uz9Uv1Q/Yz93P05/pj+1P4z/5X/5/+JABEBnQEmAqsCCQNrA5YDqwO0A28DIAPfAsYCLAJqAeMALgCq/zv/8f6M/h/+1v2m/Z79ff3J/Rb+Tv5y/q/+8P5e/67/0P8LAFMAlAC6ACYBdQFSARsB+QCgAHkAhABZAEoANQAlADAAOgA7ABQA6/8KACYANQApAMH/i/+i/9T/SQC/ABwBSwFiAUgBJwHdAKwAvwCiALAAuQC/AOwA2wC1AJ4AmgCcAKIAfQCoAAMBUAFGAVEBZQERAcUARwDt/3X/Kv/f/nP+A/7Y/eX98P0q/oj+xP7K/hr/Mv8r/zj/iP8HAI4A5gACAXQBrAHzAW8CowLqAmIDoAOYA6QDpQOUAx4DhQL7AYMB0wAOAG3/1f53/jv+LP7L/ZT9ff1Z/W39hv2t/eb9Sv7w/kP/nP8iAI0AlQBnACgAAQAAAC4AoQDPABABXwGrARcCiQKuApUCfwI9AvQB2gFmAdYArQBTAOj/TP+K/iv+3v2j/Yb9lP3D/dL9BP4W/k7+7/5s/4P/wP8JADQAcQCCANEA5wDoAAMBCQFzAcgB0AHwASMCYgJlAgsC9gEJAr8BVAELAeUA0QCDAEYARgBLADgAIgAzAHUArACVAG4AIwDb/+D/vf97/y7/+f7N/oP+JP7K/cv97v32/ff9+/0L/mX+sv46//3/dQDSACcBsAE9ApAC/gKNAxsEkARgBMUDKAOJArUBAwFzAB4AAAAKACUABADL/8D/w/+L/1z/+v6o/oD+VP5A/lj+bf6m/gD/Q/9W/zz/K/89/zP/If96/7//7P8ZADsAVwBlAIkA0QD9ADABlAHGAeQBIAL7AbsBcwEoAToBnAHeARYCYwKLAoYCJQJfAbUAOgCi/0T/3P6Y/n/+Mf4v/nT+1f4Q///+If9O/3//sv/E/yMAhwCeAI8ANADs/73/nv9g/0L/dP+Y/53/pP+w/3L/ZP95/3D/xP8YAEkAggCyANAA8wAEASMBJAEcAT8BAgHHAMUAywDNALwA0ADQAO4A9wD/AAoBAgHNAIcAXABWACsAAAD+//j//v8GAD8AbwCuAPMAYQG4AbIB8gEjAtgBYwH/AIgAJgDX/3//MP/R/l3+Gf4B/hT+Y/7I/kD/bv+j//n/CAA6AHYAbQApABQAEwAAACYANwBDAEwARABAADsAVQA1ABEAJABrANMA5QC3ANUAAAEHARIBKgH6AOYA4wDxAOYAkgBEAAAA0f+b/3T/KP/z/v/+S/+Q/6r/BQBtALwA4QAFAT8BWwE7AfkA3gC3AGAA9f+k/3z/VP8b/wD//f7T/un+Hf9A/2//qf/Y/xgAXwDNADIBZgGkAcEB3wEjAlUCLwLlAcgBhQEqAfIApQBQAN//wf/L/5P/S/86/zT/Df/9/gn/OP+I/87//v8/AF8AfAB1AHMAdQCVALYA1QAqAWQBsQHvARUCBwLxAesBtQF2AQYBdgAMAKr/Tf8P/+L+3/72/iX/Uf8x/x3/H/8q/0P/Zf9K/w3/Ov9V/3b/xf/4/zwAegB/AI8AwAATAVsBkgG/AbUBpAGAAVgBRwHtALMAjwCjAKYAZwAQALL/f/9U/2T/UP9i/2T/d/+c/3v/a/98/3X/dv+2/+3/+//2/wEA+//n//n/+f8LACoAIwAmAC8AWgCDAGsAgwCsAKQAogBQAEgAYgBXAI4AzwD6ACoBUQFkAVUBKQEuARMBpgBbADUAMAA/ACcAFwAaAA0ADgAqAEoAegBvAE4AWABQAHkAlwCtANwACQERAfwAzwB8AE8AQQAzACwAFgAKAOz/2v+3/4f/ef9I/y//Pv8v/zv/Wf9+/6H/t/+2/6D/f/9T/17/gf9q/5X/5f81AHMAogCpAEUA+//P/8j/2f/T/wEAgwDaAAcBRgFHAUIBCQHkAPYAAQEKAQkBFQH8ANYAwwDBANYA4ADXAPIAHwFDAWEBXgFmAXQBZwE0AewAqQBtAEsAKgDz/4v/H//d/pb+aP5q/o7+sf7c/h7/P/9R/1n/UP9v/5n/yP/p//z/8f8OAE8AiQDlACgBUAFoAVEB+QCbAE4AEAD7/wEA8//0/wcALwBBAD0AQABkAIYAgQCdAJ4AgwBaACsA7//Y/wYACwBXAN8AJgEhAfgA7QDxAO4A6ADLAJEAXwAXAPr/BgD6//H/BAAeAE8AeQBxAEMA+P/o/8T/wf/h//P/+v/r/xIAFgANABIA+//p/+//AwA3AKYAzgCyAKkAmgB2AGUAUABAAD8AXgCbAMsAEwFaAXIBZQEVAZwAIQCi/z7/If8v/x3/CP8E/yf/X/+S/8z/KQBhAH0AjwC0ANsA8QAZAVsBVgEGAesAygDDAMMAgQA3APL/z/+e/3v/kf+h/6X/sv/X//r/CgAMAC4AOQA8AFsAhAC0ANAACAFMAWIBjwG1AZEBSAEJAeIAsgBmAAMAuP+I/4X/fv9q/2L/av9P/x3/B/8a/yv/N/8h/zL/Wf9W/33/lv+W/3//nf/l/zAAoAADAU0BhQG2AdUB3gG4AZoBlwGYAYkBWgE7AecAlABbABQA+//i/8//1//h/xwAcAC1AOwA/QDtAKoAcgAYAK7/bf8z//j+tv6X/m/+Tf49/lH+kP7l/kz/ov/7/3wAAQFVAXMBiwGRAWsBYgFiAX8BogGtAbYBlwGPAW4BIgH1AL0AjQCGAGkAXABxAFcABQDB/3H/Yf+L/77/LABmAE4AEADW/7v/pv+c/4T/Xf84//X+0v7p/gb/EP8e/0f/i//W/0wAzwASAVgBagFmAYUBjAFqAT0BGgHkAK8AfACGAIMAQwAfACwAXABcAH4AkwCaAMsA/QAKAdwAvwCpAHcARQAEAOH/xv+i/7D/r/+u/73/s/+R/2r/ef96/7P/8f/o/+z/9v/6/wYAFgAfAFcAkwDTAPAA3wDdAKoAgwBwAHEAcQBdAGwAeQCMAIEAVQBhAG0AfgB+AEcA/f/V/9D/xP/T//D/7P/H/5b/d/9W/yb/Cv8e/z//TP+5/y8AOwAkAA0ANACYANwA/QAhAQoB9AAIAUsBtwG8AbUB1wHrAeIBrwGIAX0BRQEKAcQAcwBJABwAFQDY/43/Rf8S/xH/KP9F/y3/DP/t/ur+AP8x/zb/Kv80/0z/af99/53/yf/z/yYATgBlAIwAsgDkAA4BUQGDAcMBFAJFAmUCaAJEAvMBigEnAeQAfgA1AAoA7//q/+L/3/+9/3r/a/9S/13/h/+2/8r/5P/4//v/AAAAAPj/zv+q/5D/f/97/4//uf+5/7r/3f/2/xMAMABUAI8A5wBSAZQBlQGJAXUBhgGUAZIBrwGuAXoBigHEAdsB0QGSAVIB6ABhAPP/kf80/+X+1f7g/vT+Cf/t/rz+rf6q/rf+wv6s/qT+qf7P/gb/O/9s/4H/lP++/xEAWgBwAIwAygD4AAgBJwE8AV8BngHtASMCLQIwAuMBqwFwAQMBkwAaALj/hv9h/y//Kv80/0T/Sf8w/0D/Uf+K//j/cAC5ANMA1ADVAN4AAAErAWEBkgHdASUCVgJ1AmECPwIkAiUC9gGGAfEAiQAsAPP/3P+Z/1T//v6T/kD+AP7U/bn9pv2u/bX9yP0V/l3+gv6l/tn+N/91/7//CgBDAKoA+gANASkBQAEyATABKAFOAZkB8wFUAnICeQJiAikC9gG8AZwBRgHtAKMAgwBZACcAFQDx/7//fv9l/2z/Zf9l/0T/Mf9S/0//Rf9T/2T/l/+//7P/jv9R/0P/Lf8R/xD/Gf8+/1D/dP+i/7X/5f8pAH8A6QBZAb0B6AEMAhYC8AHBAZsBiQGLAXwBXQFHASoB9ACsAGQALwDk/7n/x//y/zMAPgAqAA0A1/+P/0v/Jv8M/wT/C/8e/03/ef+k/7j/JACmANAA3gAPAXIB2gEFAu0BzAGrAX8BVAEfAecAywCpAIYAXAArAOr/nP9c/xT/4v7I/r7+w/7U/s7+zf7x/gD/LP9n/7v/DgA6AHEAugASAVsBhwF3AXQBaAE8AfoAvQCJAGEAWgB2AHgAUABTAFgALQATAAsA7f/O/7f/rv/D/+z/CAAUAO3/+/82AEUAMwAfAAMA+v8eAFgAxQASATUBZgFnAVsBQwESAekAswCAAFQANgAbAPz/JQBDAHcAzwDiAP4A7wDoAPUA6wDjAOUA5ADjALIAXAAMAJz/RP8i/xL/Bf8v/y//Dv///v7+Ef/8/vb+EP9A/4r/yP8WAIsA1ADgAM4AxACzAJcAvgDBALUAowB3AFEALwAOAMX/hv9V/2P/pv/+/zgAcgCpAMMAwgDQAM0AeQBYAFAASAB/AO8ATQFwAWgBNwEcAS8BMwEVAckAdwAlANT/rv+N/3H/YP8+/zL/Of87/1L/W/9a/2L/cf+f//L/RAB7AI4AqQDNANIA0ADHAMQA3gDcALEAgABUADoAFQAAAAAAEAAfAC0AOgA8ABEA5P/G/5f/iv+i/8P/wf/S//v/AAAqAHcAqgDFALMAtQC1AMMABgFMAaEB3QH5AegBfwEAAYIAJwAGAPL/8v8EAC0ARQBOAE0AQAA5ADwAOgAnAB8AMwA7ADUAKAAzAEsATQAyAPz/xv/C/8v/tP+w/5n/lP/E/73/rf+W/3T/U/9E/3H/kv/C/wAAFwBkALQA5wBCAYMBjAGIAWoBQwEyARIB2AC9AJoAagBZAGUAbgBWAFQAfwCXAHIANQAAANr/3//z/+L/1P/g/wEABgAMACIAEQDw//7/IQBAAE4AOAAXAOb/vf+d/5H/yf8KACIANwB3ALUA6QDtALsAmACiAJcAfwBuACwA8v/f/8n/vv/C/8v/2//o/+r/+v8SAC4AUQBPAEYAUABKAG0AnADSABsBWAGuAeMB9AEeAi0C2wFWAcwAbAAjAMX/W//9/qv+i/6Y/qz+x/4E/1b/qv/z/ykAWgBXADwAWgB6ALIA4gDsAP4AEAEjAS8BOwFAAQEBxACZAGsAPwA6ADAAAwDY/8n/+f8DAOz/z//T/+j/5f8AACoANwAnABcA/v/h/77/1P/g/+H/BgAbABEA/v/+//f/7f/h/9T/0P/K/9j/EQAmACkAVQB1AKQA1wDiAOYA5ADpAO4A+QAXASEBKgEiAQEBugBaADoAJwAlADAAJgAFAMD/bP8L/7z+of7M/gr/TP+f/9P/EgA9AFkAbQByAHMAZgB+AKoAvwDMAOsAwgChAJwArgAFAVABUAENAeQAvgClAKwAiQBhAEQALQABAOH/z//D/8D/pf+z//7/IgATAAEACQAcABcAPgC1AFMB0wFJAnwCeQJmAv0BfgEEAYgAHADG/3f/Nv/+/tj+0/7i/vP+6/7s/v/+Ff8f/zP/Wf+U/8v/8/8MACIAKgAGAPf/DAApAEcAegC6AOwAKwFbAUYB8QCbAGUASgA4AEQAYAB8AKAAsQCvAI8AhgCeAJMAbwBEAD0ANgAnADIALAAiAD0AYQBmAG8AlQC6ALwArwC0ALAAnwCMAHcAKgDh/8f/qf+L/2r/af9z/5b/xP/y/xsALwA6ACUAKAAhABkAEwDo/8H/xv8HADIAOAB4AMYABwErASkBSQFzAYYBUQEwASIB8wDYAPkAHgElARUBCQH6AMIAiQB4AGcAOgALANT/v/+v/33/Wv8l/+L+nv5f/i/+R/5e/nP+k/63/uP+Ff9h/6n/BwCMAOMA/QDzAOIA6QD2ACkBZQGbAboB4wEDAvoB9gEDAikCPQI1AhUCzAGsAYwBSgH9AK4AWAD0/7n/l/+M/4z/jf+E/2b/Nv8G/9v+uf6T/mD+Vf5T/nP+uP7v/ij/dP/b/2IApgDFAPQAAAH8AAABCwEqAUEBOwEyAScBEAHeAJoARAAGAOr/yv+y/9b/4P/x/x0ARABHAFUAYgBRAFoATwBVAH4AnAC7AN4ABAFKAWcBfAGPAW4BOwH0AJkAYgA7APT/m/9b/zz/F/8C//f+AP/1/uv+Hf9A/2H/hv+e/8T/+/85AIQArQCPAHgAcwCLALIA8gAJAeMAyQDCAMwA0gD3ACsBKwEVAREBFwEVAf8A0wCMAE4AMgAfAAcA3P/A/6z/lf+U/4//qf+7/6j/kP+I/5n/pf+x/77/2f/3//n/1v+x/8T/+f85AG8AkgC/AP0AGQEpASIB4QDJALcAlwCEAGgASQA0ADgAPQBEAEoARwBTAFUATgBMAF4AXQBXADoAGwD6/87/v/+f/3z/bP92/37/f/+h/+D/OAB8AKMA3gDoANUA+QAhATwBRAEcAesAtgB9AEwAPAAtABsAHwAwAEgAQABGAHEAcAB/ALoAtQB7AEoAMwAhAAQA0P+j/4L/d/9+/4P/mf+j/7P/yv/Y/wYAOwCMAOEAKwFAAQ4B7QDxAOkApAB2AIYAlACCAFcAFAD0/+n/8f/V/7b/tv+6/wMAaACeAM4A7QD9AAQB+AAAAREBEwH2AMIAhwBEAAcA/P/b/7L/gv9O/17/ef96/3z/n//U/wEAFwAoAEwARQAdAPf/2v/c/9j/z//a/wEAVQCgANsAAwE7ATIB/ADcAK4AgQB5AJIAkABXAAkA6v/g/+f/6P/i//f/GAAmACUAKAAmADAARgBdAJEA1gARASIBAgHGAIcAUQAnAAYA6P/L/8b/4v/7/wQA9f8JADkARABqAJEAuQD6ABMBCwHkAK0AjwB3AHAAYgBTAEMAFAAAABEAHwAWABIAGQAvAFYAWgBWAGQATwBRAGQAUwB7ALMAyQDGALQAjwA5AOv/v/+t/5z/m/+v/7D/rf+V/5D/n/+k/7n/6f8lACcACQAHACQAOgBKAGIASQAZACMAOgBRAGAAcQB9AHUAgQCNAGoASABGACkAGwAZABEAFwAfAEAAWQBaAF4AVwBDAE8AgwCjAJ4AgABNAAIAz/+z/6L/sf+3/9L/9/8eAF8ArgD8AFcBtwHQAc4BpQFEAeAAqAB4AF4AZABbAFcAXgCQAM8ABAEHAdYApABnAF0AWgA3ABYA8//P/7n/rf+L/3P/Tf9A/z7/W/9y/4D/fv98/3//oP/f/+T/4f/Z/93/8f8ZAF8AjwC2AMYApQCEAHYAZQBYAGcAcgCAAJwApgCIAHEAigC2ALsAiABWABsA4v+x/4f/fP+M/77/4/8DADwAhACjAL4A1wDGAMEA5gAPASABHgEQAfcA1gCrAIwAfgCDAJUAkABzAF0AVQBYAEwACwDS/7r/1f/v/wAAEQAIAA4AFAAQACMAPwBJAEwAQAAuACoAOAAvAB8AEQANAA4ABQD6/+H/0P+6/5z/nf+n/7T/2/8EADIAXwCrAPYAIwEcAQIB4wDcAO4A4ADeANMAugCTAE8AEwDq/9L/yP/D/8P/uv/W/9j/z//0/xYAWABrAH4AngCBAHsAgQCJAJ4ArACqAJcAbgA9ACEAGgARAAcAGQA5AFoAaQBrAG4AcwBqAEEAAwDP/7D/qv/G/+X/CwA3AEkAXQBhAFAASwBkAF0AKgAUAP7/4//y/xQAKwArACgAGAAKAPH/4v8DAAoA+f/6/ygAewDMAPwAGgE9ASwBCAHbAMAA1gDjAAEBFAELAdoAoQCEAE4AFwDs/8X/n/+E/2f/Xf9k/3r/kf+n/9X/GwBmAKgAAAFGAWQBlwGkAYYBZAFNAUABGQHwANsArwBxAD0ACQDP/57/fP9y/1v/LP8C///+IP8z/03/Xv9v/4//ov+e/6//xP/Z/wEAPwBqAIcAvAD0ADgBSAFRAVABOAElAQMB4wCXADoAAgAAAPn/0P+w/5f/mP+Z/5L/kf+b/7j/z//5/zsAkgDYAO8A+gAkAU4BaAFVARYB2wCRAEQAGwD9//b/AAARABsAAgDl/9b/wf+q/5X/f/9y/4z/nf+d/7n/9f84AHgAuQDRAO4ADQE2ATwBNgEsAQsB8QDNAMkAzACyAJQAfwB7AHMAaQB+AIMAcQCNAKAAmgCdAKAAnQB9AEUABQC3/3f/Qf8f/w3/Dv8e/zL/Vf+V/+3/FgBZAI8ApgC5AMoA9QAbAUQBVAE3Af4AzgDcANsAqgBuACcA/f/F/5b/e/9x/4f/qP+6/8j/2//V/8//xv/T/w0ALgBqAJEAagBYAFgAXQBsAHMAmAC+ALAAogCgAKkAmgByAEoAHQD2/8r/wf/U/+f/7P8CACQAQwBnAIkAjAB5AEwABwDw/w4AOgB5AKwAvQDQAOQA6wDyAOAAtQCfAIYAcgCAAJUAqgDEANMAygCgAIMAggCRAK4AqwB8AEgALwAQANn/uP+o/5z/mf+V/4//av9I/0v/bf+K/5b/hP9l/0//WP9//7X/AAAiADcAVgB/AKsA0gAXAWIBmAG7AeAB4wHzAf4BzAGFASMB1QCcAFwAJAACAOb/v/+h/5j/lf+h/8H/4f8RAC8ALAAmABUA9v/m/9P/n/+E/3r/Yf9Y/1T/VP9U/3H/sv8AADsAdgClAMUA6QDuANcAvACcAJMAoQC9AAsBOAFGAVIBVQFNAU0BRQEQAdIAmABhACgA7P+5/4z/df9f/0f/U/9S/0z/Pf8d///+4v7t/gz/Jv9J/2v/mf/W/yMAbQDHACgBbgG5AfABBgIeAjECSAIxAh8CDALCAV4B8wCgAIMAggCMAJQAcgBLABgA0/99/zb/8P6p/oT+hf6M/pv+wv4G/1r/o//c/wgAKgBMAH4AqQCkAIcAlQDDAOYAAwH1AOUA3gDNAMUAxQDUAOQA1gDBAMcAuwCLAEAA8f+2/43/e/9z/33/gf+O/7P/0v/V/9z/4P/h/+//8//1//H/AQAoAEQAZgB9AIoAkQCaAKoA5gAmAVEBewGKAZgBmAGGAYQBhAFmASQBzgBhAAIAuv97/0v/Jf8J/+j+3v71/hv/Ov9d/5n/xf/5/zkAUwBsAHcAcAB5AH0AeACPAKoAvgDFAOsAGwEbAeMAvQC2AJMAcQBLAB4A3/+N/1L/TP9b/47/u//Z/w0AJQAtADQAHQABAPr//f/7/wAAFwAjACcAMgA4AE0ATgA2ACwAIQAtAEEALgAZABAAHwAaAAwANgBrAKQA2gAFASsBLgEuASEBAgEHAewAwQCRAGIARAAcAAQABwAVACUAKAAwAFYAjQDLAAcBDgHlAOQA7QDvANoApABYABkA3f+G/zj/AP/e/tH+2/7t/gn/Hf8p/0n/bv+X/8b/+/89AHkAsgDOAOEA6QDsAPEA9gABAfcA9gDnAN8A1ADEALIAowCcALcA1gDhANAAlQBbACEA/P/1/wMAEAAQABkAGwAnAB8AJwBOAGUAWgBOAFkAaQCOAJkAkACTAJkArwDDALMAiQBlAD4AKAAXACcAUQBJAD8AKgD5/8r/nv9+/1n/Sf9T/2L/ef92/3D/gP+u//L/KABXAGwAfwCcAJoAmAC1ALQAmQCKAH4AawA9AAEA8P/n/8X/rv+d/5D/df9Y/03/av+i/+P/LwByAL0A/AAkAVABgQGvAcoB1wHQAcQBsgGRAXIBVwElAe0AsgB+AFQAOABFAE0ANwAfAPT/pP9q/zz/G/8V/w3/B/8Z/z3/Wv93/4v/l/+q/8j/8/8NADoAkwDsAA8BGQEOAfAA3QDSANgA2gDeAOEA1ADcAOwA5QDRAJcAZwBHAE4AcQB3AH4AbgBaAEAAFgDl/+n/HQAaABQAJwA9AEgAOgApAAwA9P/n//P/3P+v/5f/e/9e/0//Tf9S/23/hv++//f/KABlAJsAsQCmAK0AqwCuAMQA0wDcANMA0wDgAMsAnwB6AGIAMwAMAOT/qP92/0n/J/8b/zP/Xf+e/9//HABOAH0A3gBEAYYBnwGuAakBiAFbARwB6wC6AHEALADx/9z/8v8FABYADAD4//T/+f/o/+L/9//y//X/GwBFAF0AbgB3AHkAiwCaAJoAjABmADkAAwDP/8X/1f/z/xEACgAZAEAAZABxAIYAsQDiAPgA5QDRAMMApQB+AGQAZgBzAHoAfwCJAJAAmgC5ALEAcAA6ADAAKwAHAOr/2/+7/5P/dv9z/3f/gP+c/6X/rP/S/wwAVwCHAJcAqwC5ALUAsACQAE8AHwD3/9T/xf/B/6L/hf9z/2L/Wv9Y/3b/pf/a/ysAfQDJAP8ALgFhAYgBiAF5AV8BOwE/AVEBVwFaATMB+ADXALMAhwBmAFMAGgD5/+j/xP+T/4D/l/+N/3T/ZP9H/y//LP83/0X/YP+O/8L/5/8GACMARQBeAIQApgCkAKwAjgBmAGsAogD2AEQBjAGuAb8BqgF/AUgBIQEGAc8AgAA9AB4ABgD4/9n/zP+9/53/l/+g/6H/nf+6/+T/EgA8AEsASwBkAIcAiwCKAJgAhgCDAI0AnACsAJUAdgBmAFgAMgAXAAcACwAQACIALwAnACUANgA9ADAALQAmACsALQArABoA7//Q/6P/hf+B/4f/k/+k/8H/v/++/9X/z//W/wcATgCcANAA6QADAQ0B/QDsAMEAkgBeACoAAwDt/+L/yP/V/xMAWACdANUA7QDuAPYAAQEPAR8BBgHXAJAAYQBoAI8AqwCsAK8AngCEAIAAdgBZAFUAWwB3AIYAhwCRAJEAhwBiAEoAJwDz/8b/qP9//2P/W/9W/3P/i/+P/5L/nv/A//v/SAB+AKwAvQCxAKwAkACLAJIAnACfAIAAiwCtAKkAewBDABIA4f+2/4f/W/8y/x7/DP/9/gn/M/9q/5//5/8zAH0AsgDOAOYABQEcAT8BWQF4AagBvwHfAQ4CFQLqAc4BrAFWAQoBwQB4AEwAGgDP/5X/W/8w/y3/Hf8H//f+2/7K/sz+3v4C/yb/RP9d/2b/cP9z/5b/1P8oAIIA1QAeAUUBkQHuATECZQJrAlMCMAICAtcBtQGFAU0B/ACQADMAAgD8//H/2f/E/6T/bv9H/zH/NP9M/1//YP9e/3H/f/+F/5H/mP+g/67/yv/0/ykAaQCVAK0AwADNAOAA3ADSANEA1gDmAO8A8gDtANcApQCAAFsALQANAPb/+f/w/8f/nv+K/4v/jf+h/9T/+/8NAAsACwApAE0AcwCeAKkAqAChALIAwACtAKAAlABsAEoAPwAvABcAEgAlADAAOQA8AD8APAA0AD0ASABTAHEAiwCJAF8ARwBBADcAGgD8/+r/6f/z/wMAJAAsADIAPwBAADAAEQDy/9H/wP/M/+D/AAAXAA0A/f/k/87/0f/1/yYAWgB+AJoAvwDTAOkAGAFHAWsBmwGmAYsBkAGFAWcBPwEGAcIAaQAOAMD/f/8//xX/Av/g/sj+1P7f/vn+DP8S/xr/Mv9r/4//u//8/zIATgBuAI4AngC/AMwAtwCkAKUArwDNAAMBLAFXAWsBcAFjATkBBwHeAM0AnwB8AGwAWABBACYA/P/R/7n/tv+9/7X/s//B/9//7f/3/xMAKAA0AC4AIQAmACwAIwAWAB4AOwBKAFkAVABBAEEANwA3ADYAJQANAP3/BQAyAFEAbQCCAHoAaQBtAI4ApQC7ANAA6wAYATIBRAFIATsBHwH6AO8A3wDBAHsALwAMANT/j/9T/yf/GP8X/yL/Mv8t/zL/NP8v/yn/PP9e/4v/t//l/0MAtQAlAX8B4gFHAnACYgJHAg4C0QGUAVUBEgHjALIAdwA9AAIA7P/g/8z/wP+o/5L/gv98/3f/ff+F/3//a/9U/2b/h/+j/8f/y//D/8n/y//A/8X/5P/r/+z/DgAuAEMAbgCPALkA7QAZAUUBcAGcAZkBewFRASMB+gDmANMAtACTAGsATwArAAMA2v+n/4L/Vv8i//b+0f7G/tP+6P4O/y3/Uf+E/7r/AABAAHkAqgDHAAIBMgFvAZkBnwG2AbsBsgGIAWEBNgH2ALcAjgBnADoAEADh/7f/hf9n/1//T/9Q/1v/Zv+A/6P/yv/0/xIAKgA1ADwAWAByAH4AfABpAF4AYQBmAGUAZwBmAFwAbQCEAIEAdQBeAFYAbgCQALAAyQDBAJgAcABPACcABADx/8//nv+D/5H/n/+7//b/NgCBANYAEwFCAWYBdQFsAWYBWQFKATIBFwHzAMkAkABJAAcAtf91/1H/Ov8j/xX/Dv8I/wD/9v7i/s/+7f4L/x7/RP9+/7P/3f8pAH4A5QBIAZgB6wEJAhYCNgI/AjEC/AHHAZcBUgH+ALcAnQCMAFoAHQDl/7X/fP9Y/07/QP9M/0z/Q/9D/zb/Hf8M/x3/Jf8v/1H/af+D/6z/0v/p/wsATgCrAAkBUQGcAdwBHAJCAksCVAI9AhUC1AGRAVQBIQHvALIAcAAsAAAA3f/G/7f/nv+C/2r/PP8N/+7+1v7H/sv+4P4K/x//NP9W/3f/pf/c/wQAEgApAFYAgACzAO8AJQFZAW0BTQExARABAAH5AM8AmwCKAHYAVQAzACcAEgDx/+X/0v/G/8T/tP+j/5n/mP+X/6P/vf/W//X/JgBiAG4AVgBRAGwAeABvAIEAqQDPANsA4QDvAA4BOQFLAUIBKgEGAd0A0QDgAM8AowCCAFYAKQAKAOn/zv+v/5//pf+d/57/nf+z/+v/LgBgAGkAbwBvAHkAgwB4AG8AZQBHABQA2/+k/47/kv+C/3X/d/9+/5T/m/+z/9H//f9JAIMAnQCxAN4AAwEDAd0AyQDAANMA7wDhALwAjQBdADoAKgAwAC4ANgBbAHMAfQCAAJAAsgDhAPcA6QDNAKgAiAB4AIoAlwCQAJgAoACbAIYAfACHAJEAgABaADUAIQAFAOP/t/+D/1r/Mv8N/wL/Ff8v/z7/RP9B/1D/b/+d/8n/7/8uAIMA4gAjAWQBmQGVAXoBVwE4AQoB0wCXAFcAJAD4/8r/rv+t/6T/nP+S/5T/uf/c/wgAPQBkAIkAsQDVAAEBBQHiAK4AfQByAGAATgBAADsANwAiABUABgARACYAJAAyAE0AYQBsAGUAWwBTAF4AfACPAKkAuQC3ALMAtwC+ALUAnACBAG8AeQB1AF0ATwBEACQA9//i/8n/sv+h/5T/hf+A/4T/hv+R/6r/xf/U/93/3f/i/wEALQBYAHAAfQCiANEA/wAXARIBBwH9ANQAmQBrAFoAYABVADcAPQBLAFkAaABlAF4ATgAvAA0A8v/h/9j/4//x/wwAJQA0AEkAVgBUAEkARABKAGEAcACAAIYAgwCLAJkAowC8AOIA8ADsAN0AtQCHAGYAaABWADAAEQDw/9D/wv+1/7H/wP/a//L/+/8bAB8AFwAdADcAVQBMAEcAPgBAAE4APQA6AD4ANgA0ABsA/f/+//n/2v+x/5j/lv+h/7P/xP/k/wgAOwBgAG4AeQCbAMoA7gAYAUQBZAFiAVABNAESAd8AnwB1AFAAJwAKAO3/2v/a//P/CAAAAO3/4v/X/9n/1v/r/yYAWwCUAMcA/wAgASMBIwEJAeQAsQB7AE4AIgADAOX/1P/K/7r/qv+g/63/yf/g//P/BQAsAF0AeACIAIAAggCVAJwAlACHAIcAgwCPAKMAoACPAHgAXwA0AAkABQAVACEAHAAdABsA/P/f/8z/w//J/9L/4P/p/+b/5//1/wwAEgAaAC0AMAA0ADoAUABqAG8AaQB/AJgArQDTAPAA+gD4AO8A4QDpAOcA1ADXAOIA5gDnAO8A8wDVAK0AegA6AAcA9//b/7f/tP+y/7D/qP+Y/33/dP+E/4z/n/+6/8v/z//i/xAAMABYAG4AWgBMAFEAaQCIAJEAlQCPAHwAdwBzAIkAuQDYAOIA3wDiAMoAkwBsAE0ATABfAGYAdQByAGsAbQBvAF8ASgA6ACYADgD4/9X/uP+n/6L/pf+l/7v/4f8CABkAEgDz/+L/6v/y//D/6f/7/wgADAAXACQAIAAPAA0AEwAZABgALQA2AEUAXwB1AHkAhACRAJwAogCtANAA8AAHAfYA2wDQAMcAtQCaAIQAcwByAHEAUQATAM3/oP+E/3D/Vf9V/2X/gP+t/9T/7//6//j/7v/j/9P/2v/5/xMAOwB3AKQAugDKAPQADAEkAV8BqgHxARoCIwIFAswBdgEUAbQAXAAhAOn/t/+e/4//gv91/2P/UP9I/0P/SP9Y/3T/jf+Z/67/vP+//83/4v/v//n/CAAiADoAXwCLALEAxAC+AK0AowCUAH4AcgB+AIQAcABbAFwAXwBTAFkAagCEAJAAewBjAEkAMgAhABAACQAFAB4ANABJAFkAUABFADoAMgAqACUAIQALAP7/AAAQADAASwBTAD0ALQAnACUAIwAlADEARgBYAGYAdgCEAJ0AnwCRAH8AcQBgAEwAPgA4ADYAGwD0/8r/sP+j/57/rf+t/7H/uP/L/97/6v/8//r/6//j/+j/4f/a/93/3v/q/wEAHwA/AG4AnwDGAPYACAEPARgBHgEvAToBPgE/AT8BHQHmAK0AeQBOACgAGAAIAP3/+P/e/7//qv+e/5b/hf96/3b/d/+B/4f/fv96/4P/lf+w/8X/2v/z/wcAHgAsADMARABUAGcAhwC+APAACgEuAVkBYwFIASEB9wDaAMQAtACRAFUAHgDy/9L/sv+V/4v/hf+H/4j/jf+c/6j/tv/M/+X/9/8IABgAIwAmACsAMgAzADgANwA5AEAAPgA4AC4AJQAoAEMAaQCGAJIAnACtAKEAjgB+AHMAbQBjAFsASwA2ABsABQDv/+P/1v+8/7T/r/+n/6T/qf+0/8r/8/8MABEAHwA0AFUAZwBZAEAAIwAJAPv/7v/n/+j/7//+/wcAEwAfADIARwBfAHIAegB7AH0AigCeAKwArwC0ALEAngCKAHgAbQBhAEsAOQAsACgAMwA8ADYAIQASAA4ADQAJAAAA7//o/+X/6P/i/87/v/+5/8L/1P/p/wIAFgAkACoAIAAgACgAIQAhACwAOwBHAEsATABTAFoAVAA+ACsAJAAgAB8AHQAgACgAOQBIAE8AVQBpAHUAdAB4AHYAcwBsAGAAUwA7ACUAEwD8/+z/3f/Q/8H/sv+o/6T/o/+o/7D/uP++/8P/yf/R/9//7/8HACUAPgBWAHUAjQCVAKAAnwCWAI8AfgBwAF8ASwA+ADIAKgAfABsAEgAKAAcA/v/3//L/9P/5//v/9v/w//X//P8DAA0AFgAeACEAIwAjABwAGgAdABkAHgAlACMAIgAmACMAHAAeACcAOQBJAE0ASgBIAEIAMwAjABIAAwD2/+r/4v/g/+j/9v8EABIAHgAoACkAJAAkACcALwA2AD4ARQBIAE8ATABKAEYAPwA+ADcALgAmACUAIgAfAB8AGwAdAB4AHgAcABMAAgD2/+3/5P/b/9L/zf/L/8n/yv/P/9r/5P/r//X/AAAOABoAIwAxAD0ARgBRAFoAYABiAFwASwA7ADcALwAmACMAHgATAAoAAADy/+f/4P/b/9j/2v/g/+H/5f/y/wIAEQAfACsAOgBJAFYAYwBmAGIAWABPAEIANgAsACAAGQAZABYAEgANAAAA8v/m/+D/3f/a/9j/2f/e/+f/7P/t//D/9v/8/wEACQAVAB8AMABHAFgAYQBqAHEAcQBqAGEAWABSAEwAOwAkABQACQD///T/6v/g/9n/1//a/97/4f/j/+X/6//t/+n/5v/n/+n/7v/z//v/AgAIAA4AFQAXABgAHgAgACMAKgAvAC4AJgAgABgADwAJAAQA///5//X/8v/v/+7/8P/y//b/+f/7/wAABwAKAAsADAAKAAcABQAHAA4AFQAWABcAFwAbACAAJQAoACYAJAAkACIAHwAZABUAEQALAAQAAAABAAUACQAKAAoACQAIAAgABgAGAAgABwAGAAUAAQD///z/+v/4//j/+f/6//v///8CAAYACAAJAAoADgARABQAFgAWABMAEAANAAkABwAFAAIAAAAAAAAA///9//3//v////7//f/8//z//P/8//z//v8AAAEAAwAEAAUABwAKAAwADQAMAAwACgAJAAgABgAEAAIAAQAAAP/////////////+//7//v/+//7/////////////////////////AAAAAAAAAAAAAAAAAAAAAAAAAAA=","base64");
	var closedHat = Buffer("UklGRsYYAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YaIYAADC/+UAHf0W/6MD0f+K/3MCDQCA/8EATQ/2/qHU6AuOGzj46vmhEasNYtHK9bclg/+lAFcLP+Gg/CcW0f/I81f75A7uAOP+dxNN6+ThkxegE4fslh+6/DTAhBsWG4f1+fwQEvL2M+VpDQEOTP2D/+P3SRqG9fPVVBVzDzD9TP1LBR0GrfI4+iQLdwLd/t8H//bxBMkAfObLBTkRPADU/L8iNNmV35AnfwUB/n8FF+1y+qQTBv7aAJADie/WBDgKpwSYDhLk+eK7Hq0GmASPEInXpvuIFyoC2vryAQ8CGfyqAaMBawKxAVv5dvwpBDwFtfvA/JYEaQKz/54R5/0f0eoLBBvX+CUENQdX62wAWQn6+BwGJQXC+sYIbv9V6xUNCAf/+fYAIwhC/G7wIAhNCOX73wA5Bcr5Hfp6BzMBzgEfAoL2bfy4DXH60g8vE7i9Cf6iLy354vVFJKfcneBrJzMFL/VpAl4Nbe9o96UQl/9o/qYavuNo2kUlQg2W9JUS4vGM5NMVLQiz8AAGIwn1+rP/uwOE/DL+LgQq/6wBIQkp76j6CBANAHsMpu2d6Ogd2AESABES99Sw/ekgXfrE+c8aAu2U2zAagwu4+p8H7wOd6bb/XA68/jkHf/rH824IJP6N/68HL/0bAnv9RwKe+k4eqvmBv4ggNh3F7mv/UCHP2cfkfynBAK72cwAUDxX9z+OnCzoPo/hiBe8GQeuW+8UPEQBF/VsHOxO+3iHslR2UAxv+agE09vEE+QQZ/LYY3OMn7EYYSgMz/kT/WAhm/9jv4QIkCs//XgNdA0T86epbBXwK0QM3+3gPkAaz00AJ+RfG+k/9phV76tTnIhbdB0z70f/rARoAmv75A03+H/2q+jES9hhjwFj+9ih0+ZX49gOLB0H3bPrTCd/9rQjm+5DrrA8eBgr7cA6s9/vgCRUADZ36Fhgv2fTx7CBu/RT7WQFFBRb60Q7G+nvj+AtVDrr8Uf94F5HkzOcDIIwAVgGvD5/dJfsxF0QAnvqCAVwChv4MACIAkAACAEMACQANAJEArgAQAzv7RP1EBEAC+PyHC+8NX9xn7hggXwTh+xkUNOAi+KQSuglmBfHjbgH7DxEAYvuABOEEaPSDACIITfzS/dQCsAHYAP4AOP45/VoBggJiAgAAw/cx+pYN2AuO7if7swcm/hgHKvtaCpMQN8/FBWQdPPkk94MRIwPm2M4R1xEY9BsD5AnZ7hT7zBAn/CABZ/7XDTr/09mdDXMTZfrw/aYJfPdi9RUPiv7XDoL4Td7sEAMPXfrgBXkED+vu/QUQMABCAnEB/flm/rr6ogNQA8sEvw1V6M32QhCXAjX+IP8qCAb7z/UCBi0GQv2CBuMMZd4G+TgaOv/vAe8BRPFnBZAI5PaG/pkGr/72/6QA1g0d/U7hwwoYEkH4VgIHE0fiK/cPFBEBGf1xBa8GMPIB9iQKCQYpADoPdujZ9dYQFwGA/w0Bgwod94j1GQVYBEb9kPy3BpkBsf0RBA8Ab/fUArQE7f/wARoDRvRRCbwFO+kfBsIJGAAi/ywAZROa6nbpjhwXA5P3RQNJFI3nTux2GhwK6PcE8tMEJQcy/x/+2AIB/zwVk+u35z0XtwTS/Pr+7AMjAp34iP8+BWwAKP5REnzz6OBsF3cP7/sS8wX6iwt/AhcAcgEJBy319fN+CwwCHgD7ADAEOQJk9n37/QcyA1cDef5e8s4F+QUn/i38NQcCDRrpoft7DOwANQDX/VYTCvHX52sT2Qfk+u7+vgVA/6f33QPNA/H/wgcJ84T5Lg2gAO0BUwf677v2nAwRCb/9O/VWAhcDlgGIAO//nAAaACYA6f89AG8AoQAdASz/Ev6JAY4BxgFa+IEBUAMP/UcDfANlDnTp6PLFFwz/N/1ZEU3mNvhzEwYCB/gHC5cJB9yrCIUTuPi2/fYKEvna8dgLoQR7/XMGQf4f8dQDlAieA/r+NvWiA4cGjftd/A0GQQK6/KsFu/we+ZcGCAJa/W4CNgHN+mMBxgJdAAMAXxTx5XLp2yGuAYb0whQs8sPq3hFLCKn3BQiACvHgTATtEYL7qvx7A5AB7fufAMsCCAKPBcr92usKB3AJ0v7X/swFYQpO56v9kw/P//j8uAL9BS32L/8jCGz7XftdBez/VAGh/rUGTwx14R7/2BGe/hL9Rgb4+sH8ZwJdDSQAouKqCrcLTf0w/s0BIQEk/ooA2wA+AE8Ck/xx/qgDFACf/1ECIP+l+0wDxwC/AfP/UApG+LLoAg/yCZb6fQAsAaUI+vit8bALdgaq+eQKAv5h6icLQweB+SMCfANQ/kcBxgC9/Bn/TQUw/EkMawNV3pwJZxCL+3T9SQS7A532V/5XB5//NwEk/0L6bgUVAf8L2fVo61MPrgYK/I4Fwf+k9EYEEQVw/FX/kwNCAAoA5wHW/kD8AAD2BEH+rQ+h8cDsRBH4BUX6PAi7ATjuNQRHB5H/WACL/qEF/AEh8W4EHwoL+U4HdgqO3z4FwhQK+MD9IwNjAED+RAHuAaMCXvzh+jMAwgV8/10N/vMg7zsQEAFv/RUCGwGNAUkA/foR/x0GQ/0LDQ/4yOoxDwEFCv94/IwKmgBp6LYLoAqL+PoA7gDpAML9TggmCO7hjANuEWv9D/vcByoJRuVPA/wPp/vO/c8IiPu78tQIsgXN/W0GpPpF9NIHigMUAEkKffJx+CsMqAJMAaf1dQFaBr4CAgbt7mX99wsUAKn+vQt/8Vr3rgytAcb97gLHA6LxpgYkBKMCPglS54YBGA3d/yv7qw0A+QHucwxoB2D5VQi5AuvoQAolCm766f8+BuH8f/p2AMcBJQOf/vQLn/Q582cNLQJu/XoAaQEx/yACtAVq+Zr2DwcxBTL9Mf+2A+kHPfLt+PsMcwBsBRP7YfQuCJ8Eqf6vCHX0OvlMCZABKP/GAg8FNfSz/ZQH8QQ0/FD6CQPyAPEBwf/JAUgDGvop+84GJgFiAugDPvKZ/0EIdgA+/+QA/Aby+uzzsgYDB/v8egTN+rj7mgUyBt8B7O+2A4YGG//Y/1oFvvx191EGFAakA4HyR/+nCXP8nf3xAy4BTP4YAjoAWPzFAaAB2P9t/8EFeQM78mv99QeqASX+1gFn/zsCQwp47r/78wsuAKr+HwEvAAb+FwFTAQQA6gG6/Iv+kwOEAYIKjvBB9WMQOf/iAp0DKPIAAXYIof9z/dUMj/KZ9VUPdgCm/KMAKgMu/b7+wwLb/97/oADR/y3/qQEs/wwDpAE6+Of/wwap/QICiQ3x6GX7SRA6/x39cwIbAYb79wHZAaX/GQDuDLXwF/S+D64BRP0dAMcEj/3U+VUENAKO/3z+dQKo/bEJ0gAm6cgIwwn4+0sAYgBPCCz7P/NMCAcDeP/Z/uEJwvm79LYHvQPv/Z0DYAWm8SwBnwa2ArQA9/dbACUHNQYN9PP7wgjbAJr+BgBTA6f9Af1PA/kATv8FAlQAYPuPAbECIAD8AK77jgOr/t0MhPjW658P4QTh/Fz+Mwtz+NnzMgrUAxj9UAP2A5j0rP+YB9v/uv+4/TACUQj99Cz8GQe9ABEABgEXAI/9GgGDAWkAdwFsAAr80QNM/jr8YQNMANMCAv0nCX/9BvHyB1wFQ/4l/4sB7f+R/5kASgCKALYA3v6W/9cAVQFPAAsC/fsQ/sUB5wj1AJrulAU+BwH+YgBn//sIwPko9M8IkgX1+pUFOwRC70UEoAhc/Wz/zgDV/ywAnwC7AOcCnvvP/MwFwP7qCf33EPNtCyAD2f0yADwCrv2L/3IC7v/2BTr8NPVoBz0EOv1I/pkB6gFCAOkErPlk+n8GVQFvAKb9LAdqAQLwXAXdBwn9LgBNAMsDZAE49XgBvAa7/kICIQFy+RYBlAOF/woCDP9W/ZABRgHl//8Ab/83/ncAXAKrBaz5A/vwBPwB5v8g/0ICBwGO+7oAzAKR/+n/lQCOAF3/3v+5AF8AtgB0/9r/8AKGAbb6J/5EAwEBUP7zBJ8CjPbfAB0Eov88Adv+LwTdA/vx2QEtCJ3+hP7+AncC7fepAJ0F1/7kAUoDA/e4/s4Glf/C/oYBNwZ1+Kv78waj/+f9uwF2AUH/LwDeACwAjf5mAd8Akv/j/msFtABX9NgDwwXw/dUASQKR/Lr/FgJqAMX9TgGgAOEDvgKA9LQB1AWz/wz/igBIARb/cP8pAUsA3/+RAC0Aqv8BABQBUv9CAbr+OgIb/eYHWgSp6OkHQwqh/Lv9xAh5+0r1nAivAkn+HwCIAGP/+AADACsBXwFK/OH/nwLyB8r2Xvn/COL/Cv86AaQArAHs/jv9qABxAoT/DgFtCE7zSfxZCff/1P53AEcBIAU/+RL62QdkAfj9eQGkBpb2U/yWBzX/2APm/ST6ewNhAy/+8ARw/hr3lAVKBVL8Tv3QAQwC7//9/04BPAT7+aL64Qb0AW8Anv4H/bEBjwKt/zUDX/sD/cYE3wMzAJ73DQPqAeIA7P7qBPoAMPW9A08Eh/8s/wQBGQBDALn/qgC0/6cATf8eArgIw/AI/vcJZf7E/1oAVQGAAF3+FP8KAogA7//zBqD39PlcCKIAX/8IAMUDOv5q+hcDnwLUAw37B/xVBNQATwDL/4YCAAEz+d8BEAMDAhsCRvepAUsDIQEl/oYEegHs9PgDAwVG/s3/iQDzBGT8VPg1BrMC1v6yAwr7av0KBH8AQP9HAcH/zwKZAT73mgJhA6b/4P4KA8gBi/kdAUUCngAnAMT/XwLw/rn8QQLOAeT+XQIUAGL9mgHC/YwAjgGBAJgAbwLt/cv73AJiAqn/rwB/AlL7wv6tA3gAdf7j/xwBcwFH/qYEEwGV9YsDQwRT/2z/BAEQAnb8xP9RApoA9v5WBfP9v/ZxBQoDYv86/4AFh/wR+lQEeAEoAMH/jwD+AB7/GP9wAWsAp/+YAm39Sv4vAwoAjP+EAPX/ogCl/6oDxQHc9VAB5AWl/rEATgR1+jD+egMzAEIAKAEFA836av7rAxoAMwFjAAj9CwGfAc//e/+Y/5oAiAF4/z0BlQQC+MP+uwRAAAAAwv8uBgv5t/tYB/f/7/47AP4AyP8jAMT/gQBNAPv/Xwhv9eH6oAnY/9H+bgD5A8H7Cf18BL8ARf+JAPr+egH2/loEwAHz9HUDkgTj/lQAawNw/Jn9mwMOAAv/MgCaARgAawKn/UX9EgJIAVj/0QKcAdL5+gC8Apj/6QCkA/v6r/09BMYAPP+HALMATgBV/iEDawHV+LMCAALnAbUAmPvCAOkBtwC//zkAqgGo/nD+LgJYAML/UwCbANMBXf0b/2EBLQUx/Zb4VQZeAZUAcAHT+j4BxwFNAMf/1gEhAz758/+aA7b/fgCA/+8ElPwX+6UELQHW/X8C3wGT+38AuwHBAMH/IAFsApP7Sf5EBPz/egEUAAL8dAHtAev/MwHB/rX+TwHIAS0C+ftj/wwCvP8tAdf/YgNh/WD71QRaAJoC3f7Z+gUDkAEzAIT/HAL0AEb6ZAKLAlIBIQCo+goCWQKO/x4ANADMAwL9JfyDA6IABwCzAu79nf1fAvr/rgCl/7cDtv64+kQD4gCYAB///wPv/nT6pQJjAgf/AALMAVz6qwDCAiQA0P9eAD0AVARA+xz88AS6AI7/LwCbAnz+7PuhBPQBqftHANwBogDZ/yoAYgAWADwA8f8xAGwAPQD7BFP6HfzRBQ4AHADK/6D/EQB9AM4AZgAXAr/94f18AqwAsAC2/yn/+v/pATsAhP5AAHMA9QArAHUApQJ1/PH9qANIANr/wf/JBET8ePudBIAAdAAR/wUDCwH4+SMBmQMN/3YBNwKU+pgAngJbAJH/WQJ3AOH6PALRAcsAdwFL/GUAdgHmAHACwPzB/m4CyQCz/40AAgJ3/oH+vQCaAK8ASgAAAfAAHf5S/8gB7P+B/+YAvQAXA3T8q/0hA78A/P/k/+sADQBA/6kAZQBjAKv/dQTg/Db6oAU+AVP/awJZ/an+agL7/5T/+QBYAHsBLgDs/GIAOwKm/28Cu/8L/FwCgQAdADoAawKK/2H7wgPBAHoATAIX+yMAywIvANz/lAI0/jf9oAKpAHMANgFa/kD/jwEiALH/2QD3/1wDmP3T/LwCtwBSAPj/mQDHAej+SP2IAZ4B6f8UAP4Avv6HAGYA9AGqAQb5cgINAz4ANwE0/AUBxQGz/5gAx//C/wgA6gAcAHQBvwCd/McAVQE1AHAAJQBQAlP+e/34ASQB8v/JAUH/Jf3dAREBngD0AZ78wv+tAWkACQCBAc4Ac/wjAS0BTQCu/0gCdwD2+3wBUAEYAFUAAgJr/h7+CQJAAPcAXwBV/pEASAC6ADwAZgD5Agv8Mv+eAn3/XgCcABQAfgC9AID+QQBLAdT/jwAfAZv+7f7HAVsAHwB+Awf8bP0ZBCsAMABEAgP9jv7mAjkAIQCaArD8xf6PAnIA4v+JAPj/4/9aAC0BzgH1++3/qAIsAAkAJP+gADoAsAGwANb8qQCNAU8A4P8cAgL/qf3gAYUArf9cALAAjgBl/+T/8gCkAGX/tgAZAa79cgBxAY//MQCfAE0CE/5k/hMC2v8TAIMAkgC9/58AmP9LAk4AbvvtAZkBAQASAPMAWgD7/k4AawBUAGwA8//a/18AZQAvADcAMwDO/xQAuADqAYb+x/5uAY8Agf93AT8AbP6MAHoAxADh/6AC7/30/R0CzADk/8EAvwH3/DQA5wGu/87/aQCRAMMAXQCb/k8ABQHo/wgAUgAMAjP/A/5aAVQB0/97/9v/DwEKAHAByQC0/DMBYgGt/yYAiwB1AIUAwv9F/6QAngA9AO//QwAbABgA4/+dAckAzP1xAKIAcACAAO7/hwBtAIb/vf9LAW//jQEpAk36IwEhA2L/6f98ACwACgBXAA8AsgO++xj+dAN5AJX/xgARAm789/9kAvL/4/8BArX+1P0sApcAPQApAYD+kv9dAbT/BwC1AFYAOQCNAEAA9v7u//4AOQAcAC4AIgAKAPT/PQA0AVwA4f0ZAc8AugAZAUL9RABkARkAWACeAUn+Kf81AWEAWABfADIAe/80AIQANgDj/+ECe/0l/nQCAAAtAGcAHgAUAbr/b/7jAC0Bav+NAQYBzvuRAd4Byv+hAQP+M/91AYwA/v/kAaf+Nf7XAUQAvAA6AcH91v9bAaoAXv/8AQoA0PyAAVMB7v/4/1YC7f2A/hICRAAnABgAbAApABQA6v+AAEICE/2+/kYDbP9gAQsAk/0dAfQALAAUAFcADABMAOP/IgL//oz9FgKvAKb/9P+uAEoAGAFf/9v+FAFyAGMARwCm/xIAjwAxACAAzf8tAJ8AaAC2/xMCMP9T/SUC2QDZ/w8AKgGv/6b+OwGKAP3/HwCZAOH/AAAjAIwBbgCZ/HsBbgHCAAoAcv56APUABgBSARoACf7dALYAQgBLAGIB1f4F/6oBOQCr/87/2ABLAC0A2gHU/TP/5AFeAL3/rQF2/zT+YAE9AD0AZAAzACkAMAAzACwANgA0ADMAJAArADgAPQBYADcADADt/5UAzP/r/1gA0AFz/+T9kwF0AXoAPP5cAMYA2v/jAKH/qQEJAGb9RQF3AWT/KgHrAEX9sgBmARcA9P+tALYAGv45AVsAGwHSAOz85QB5AQgAHACaAWr+9v5BAqb/8gDwAF39qABPATwAxf8lAdMAn/2oAOsADQBeAC8ARwAeAIEB0f7I/oUBqACY/50B/v9b/bUB1QBpAN8AIP4rAFkBBABhAQf/Iv/ZAIsAFQDHAA4B9v02AP4AXgAAAEEB0v9d/gkBrAAmABUBNv9+/9gA//9MAHMAFACRAKEAr/4fADcB4//EAJ7/oP+bABEBvADA/Z8A7gAVABUA4wDcADD+UwDdAEgAiQC2/9r/QABHAHgAFgAiAan/nP4PAYcAWwC4ABb/8P+KAEMAfQB7AMH/lP+fAF8AfwBPAD//LwCcAD0ATgDp/x0AFAAsAHUAMwApAC0ARwBPANAAWP9H/9YAVQD5/8IA1QDX/hgAmAArAD0A3AAFAC//eQBMAD4AbAA1AeL+nv/iAPT/lwD+/3UBZ/+N/jcBnAAkAAUARgGz/7H+1ACPAEMADwFW/w//TwFKAF4AJAFt/tn/IwE0ABIBWP8y/zsBNADXABAA7f6QAM8AIwDc/xwATQAsAKgAfwAU/0IAUQB3AAcAqQCuAIH+VgDIAEYA1v8TAfb/xf6rAIUALgAPADcAIgAZACUAJwAiADIAJAD8/x0ANwAfAE4ANACm/wwAYgBJAPj/yv8pAF4A+v+BAPP/if9mAAIAIgAuAA8AEwAfAAsABAAdABMADwASAA4AEQANABAADQANABAAAwAaAPD/igCq/4r/eQAdAOv/LwAKAL//IQAWAAQA/P8gAPr/4/8RAAkA/v8EAAMA/P8=","base64");

	var samples = [
		bassDrum,
		clap,
		closedHat
	];

	
	// Makes sure the machine is ready to play
	node.ready = function() {
		var samplesLoaded = [];
		
		// disconnect existing samplers just in case
		samplePlayers.forEach(function(s) {
			s.disconnect();
		});

		// dump them, and let's start again
		samplePlayers = [];
		
		samples.forEach(function(sample, index) {
			var samplePlayer = new SamplePlayer(context);
			var arrayBuffer = sample.toArrayBuffer();
		
			samplePlayers.push(samplePlayer);
			samplePlayer.connect(node);
		
			var sampleLoaded = new Promise(function(resolve, reject) {
				context.decodeAudioData(arrayBuffer, function(buffer) {
					samplePlayer.buffer = buffer;
					resolve(buffer);
				}, function(err) {
					reject(err);
				});
			});

			samplesLoaded.push(sampleLoaded);
		});

		// Kinda hacks for the time being
		nodeProperties.currentPattern = patterns[currentPatternIndex];
		nodeProperties.tracks = samplePlayers.length;
		
		return Promise.all(samplesLoaded);
	};


	node.start = function() {
		stepTime = 0.0;
		startTime = context.currentTime + 0.005;
		samplePlayers.forEach(function(sampler) {
			sampler.stop();
		});
		schedule();
	};


	node.stop = function(when) {
		clearTimeout(scheduleTimeout);
	};

	
	node.cancelScheduledEvents = function(when) {
		// TODO cancel scheduled events on the 'child' sample players
	};


	node.setStep = function(track, step, trigger) {
		var currentPattern = this.currentPattern;
		currentPattern[track][step] = trigger;
	};

	
	function schedule() {
		
		var currentPattern = patterns[currentPatternIndex];
		var numTracks = samplePlayers.length;

		var currentTime = context.currentTime;

		currentTime -= startTime;

		// TODO also why 0.2
		while(stepTime < currentTime + 0.2) {

			var contextPlayTime = stepTime + startTime;

			for(var track = 0; track < numTracks; track++) {
				var sampler = samplePlayers[track];
				var trigger = currentPattern[track][currentStep];
				if(trigger) {
					sampler.start(contextPlayTime);
				}
			}

			var oldStep = currentStep;
			advanceStep();

			// Dispatch event for drawing if step != oldStep
			if(oldStep !== currentStep) {
				var ev = new CustomEvent('step', { detail: { value: currentStep } });
				node.dispatchEvent(ev);
			}
		}

		// TODO: Chris's example has the timeout at 0 but it seems excessive?
		scheduleTimeout = setTimeout(schedule, 10);

	}

	function advanceStep() {
		
		// Advance time by a 16th note...
	    var secondsPerBeat = 60.0 / nodeProperties.bpm;
		
		currentStep++;

		if(currentStep === nodeProperties.steps) {
			currentStep = 0;
		}

		// TODO something something swing which I'm ignoring
		// TODO also why 0.25 - maybe because it's a black note so 1/4 of bar?
		stepTime += 0.25 * secondsPerBeat;

	}

	return node;

};



}).call(this,require("buffer").Buffer)
},{"buffer":1,"es6-promise":7,"openmusic-sample-player":8,"setter-getterify":10}],7:[function(require,module,exports){
(function (process,global){
/*!
 * @overview es6-promise - a tiny implementation of Promises/A+.
 * @copyright Copyright (c) 2014 Yehuda Katz, Tom Dale, Stefan Penner and contributors (Conversion to ES6 API by Jake Archibald)
 * @license   Licensed under MIT license
 *            See https://raw.githubusercontent.com/jakearchibald/es6-promise/master/LICENSE
 * @version   2.3.0
 */

(function() {
    "use strict";
    function lib$es6$promise$utils$$objectOrFunction(x) {
      return typeof x === 'function' || (typeof x === 'object' && x !== null);
    }

    function lib$es6$promise$utils$$isFunction(x) {
      return typeof x === 'function';
    }

    function lib$es6$promise$utils$$isMaybeThenable(x) {
      return typeof x === 'object' && x !== null;
    }

    var lib$es6$promise$utils$$_isArray;
    if (!Array.isArray) {
      lib$es6$promise$utils$$_isArray = function (x) {
        return Object.prototype.toString.call(x) === '[object Array]';
      };
    } else {
      lib$es6$promise$utils$$_isArray = Array.isArray;
    }

    var lib$es6$promise$utils$$isArray = lib$es6$promise$utils$$_isArray;
    var lib$es6$promise$asap$$len = 0;
    var lib$es6$promise$asap$$toString = {}.toString;
    var lib$es6$promise$asap$$vertxNext;
    var lib$es6$promise$asap$$customSchedulerFn;

    var lib$es6$promise$asap$$asap = function asap(callback, arg) {
      lib$es6$promise$asap$$queue[lib$es6$promise$asap$$len] = callback;
      lib$es6$promise$asap$$queue[lib$es6$promise$asap$$len + 1] = arg;
      lib$es6$promise$asap$$len += 2;
      if (lib$es6$promise$asap$$len === 2) {
        // If len is 2, that means that we need to schedule an async flush.
        // If additional callbacks are queued before the queue is flushed, they
        // will be processed by this flush that we are scheduling.
        if (lib$es6$promise$asap$$customSchedulerFn) {
          lib$es6$promise$asap$$customSchedulerFn(lib$es6$promise$asap$$flush);
        } else {
          lib$es6$promise$asap$$scheduleFlush();
        }
      }
    }

    function lib$es6$promise$asap$$setScheduler(scheduleFn) {
      lib$es6$promise$asap$$customSchedulerFn = scheduleFn;
    }

    function lib$es6$promise$asap$$setAsap(asapFn) {
      lib$es6$promise$asap$$asap = asapFn;
    }

    var lib$es6$promise$asap$$browserWindow = (typeof window !== 'undefined') ? window : undefined;
    var lib$es6$promise$asap$$browserGlobal = lib$es6$promise$asap$$browserWindow || {};
    var lib$es6$promise$asap$$BrowserMutationObserver = lib$es6$promise$asap$$browserGlobal.MutationObserver || lib$es6$promise$asap$$browserGlobal.WebKitMutationObserver;
    var lib$es6$promise$asap$$isNode = typeof process !== 'undefined' && {}.toString.call(process) === '[object process]';

    // test for web worker but not in IE10
    var lib$es6$promise$asap$$isWorker = typeof Uint8ClampedArray !== 'undefined' &&
      typeof importScripts !== 'undefined' &&
      typeof MessageChannel !== 'undefined';

    // node
    function lib$es6$promise$asap$$useNextTick() {
      var nextTick = process.nextTick;
      // node version 0.10.x displays a deprecation warning when nextTick is used recursively
      // setImmediate should be used instead instead
      var version = process.versions.node.match(/^(?:(\d+)\.)?(?:(\d+)\.)?(\*|\d+)$/);
      if (Array.isArray(version) && version[1] === '0' && version[2] === '10') {
        nextTick = setImmediate;
      }
      return function() {
        nextTick(lib$es6$promise$asap$$flush);
      };
    }

    // vertx
    function lib$es6$promise$asap$$useVertxTimer() {
      return function() {
        lib$es6$promise$asap$$vertxNext(lib$es6$promise$asap$$flush);
      };
    }

    function lib$es6$promise$asap$$useMutationObserver() {
      var iterations = 0;
      var observer = new lib$es6$promise$asap$$BrowserMutationObserver(lib$es6$promise$asap$$flush);
      var node = document.createTextNode('');
      observer.observe(node, { characterData: true });

      return function() {
        node.data = (iterations = ++iterations % 2);
      };
    }

    // web worker
    function lib$es6$promise$asap$$useMessageChannel() {
      var channel = new MessageChannel();
      channel.port1.onmessage = lib$es6$promise$asap$$flush;
      return function () {
        channel.port2.postMessage(0);
      };
    }

    function lib$es6$promise$asap$$useSetTimeout() {
      return function() {
        setTimeout(lib$es6$promise$asap$$flush, 1);
      };
    }

    var lib$es6$promise$asap$$queue = new Array(1000);
    function lib$es6$promise$asap$$flush() {
      for (var i = 0; i < lib$es6$promise$asap$$len; i+=2) {
        var callback = lib$es6$promise$asap$$queue[i];
        var arg = lib$es6$promise$asap$$queue[i+1];

        callback(arg);

        lib$es6$promise$asap$$queue[i] = undefined;
        lib$es6$promise$asap$$queue[i+1] = undefined;
      }

      lib$es6$promise$asap$$len = 0;
    }

    function lib$es6$promise$asap$$attemptVertex() {
      try {
        var r = require;
        var vertx = r('vertx');
        lib$es6$promise$asap$$vertxNext = vertx.runOnLoop || vertx.runOnContext;
        return lib$es6$promise$asap$$useVertxTimer();
      } catch(e) {
        return lib$es6$promise$asap$$useSetTimeout();
      }
    }

    var lib$es6$promise$asap$$scheduleFlush;
    // Decide what async method to use to triggering processing of queued callbacks:
    if (lib$es6$promise$asap$$isNode) {
      lib$es6$promise$asap$$scheduleFlush = lib$es6$promise$asap$$useNextTick();
    } else if (lib$es6$promise$asap$$BrowserMutationObserver) {
      lib$es6$promise$asap$$scheduleFlush = lib$es6$promise$asap$$useMutationObserver();
    } else if (lib$es6$promise$asap$$isWorker) {
      lib$es6$promise$asap$$scheduleFlush = lib$es6$promise$asap$$useMessageChannel();
    } else if (lib$es6$promise$asap$$browserWindow === undefined && typeof require === 'function') {
      lib$es6$promise$asap$$scheduleFlush = lib$es6$promise$asap$$attemptVertex();
    } else {
      lib$es6$promise$asap$$scheduleFlush = lib$es6$promise$asap$$useSetTimeout();
    }

    function lib$es6$promise$$internal$$noop() {}

    var lib$es6$promise$$internal$$PENDING   = void 0;
    var lib$es6$promise$$internal$$FULFILLED = 1;
    var lib$es6$promise$$internal$$REJECTED  = 2;

    var lib$es6$promise$$internal$$GET_THEN_ERROR = new lib$es6$promise$$internal$$ErrorObject();

    function lib$es6$promise$$internal$$selfFullfillment() {
      return new TypeError("You cannot resolve a promise with itself");
    }

    function lib$es6$promise$$internal$$cannotReturnOwn() {
      return new TypeError('A promises callback cannot return that same promise.');
    }

    function lib$es6$promise$$internal$$getThen(promise) {
      try {
        return promise.then;
      } catch(error) {
        lib$es6$promise$$internal$$GET_THEN_ERROR.error = error;
        return lib$es6$promise$$internal$$GET_THEN_ERROR;
      }
    }

    function lib$es6$promise$$internal$$tryThen(then, value, fulfillmentHandler, rejectionHandler) {
      try {
        then.call(value, fulfillmentHandler, rejectionHandler);
      } catch(e) {
        return e;
      }
    }

    function lib$es6$promise$$internal$$handleForeignThenable(promise, thenable, then) {
       lib$es6$promise$asap$$asap(function(promise) {
        var sealed = false;
        var error = lib$es6$promise$$internal$$tryThen(then, thenable, function(value) {
          if (sealed) { return; }
          sealed = true;
          if (thenable !== value) {
            lib$es6$promise$$internal$$resolve(promise, value);
          } else {
            lib$es6$promise$$internal$$fulfill(promise, value);
          }
        }, function(reason) {
          if (sealed) { return; }
          sealed = true;

          lib$es6$promise$$internal$$reject(promise, reason);
        }, 'Settle: ' + (promise._label || ' unknown promise'));

        if (!sealed && error) {
          sealed = true;
          lib$es6$promise$$internal$$reject(promise, error);
        }
      }, promise);
    }

    function lib$es6$promise$$internal$$handleOwnThenable(promise, thenable) {
      if (thenable._state === lib$es6$promise$$internal$$FULFILLED) {
        lib$es6$promise$$internal$$fulfill(promise, thenable._result);
      } else if (thenable._state === lib$es6$promise$$internal$$REJECTED) {
        lib$es6$promise$$internal$$reject(promise, thenable._result);
      } else {
        lib$es6$promise$$internal$$subscribe(thenable, undefined, function(value) {
          lib$es6$promise$$internal$$resolve(promise, value);
        }, function(reason) {
          lib$es6$promise$$internal$$reject(promise, reason);
        });
      }
    }

    function lib$es6$promise$$internal$$handleMaybeThenable(promise, maybeThenable) {
      if (maybeThenable.constructor === promise.constructor) {
        lib$es6$promise$$internal$$handleOwnThenable(promise, maybeThenable);
      } else {
        var then = lib$es6$promise$$internal$$getThen(maybeThenable);

        if (then === lib$es6$promise$$internal$$GET_THEN_ERROR) {
          lib$es6$promise$$internal$$reject(promise, lib$es6$promise$$internal$$GET_THEN_ERROR.error);
        } else if (then === undefined) {
          lib$es6$promise$$internal$$fulfill(promise, maybeThenable);
        } else if (lib$es6$promise$utils$$isFunction(then)) {
          lib$es6$promise$$internal$$handleForeignThenable(promise, maybeThenable, then);
        } else {
          lib$es6$promise$$internal$$fulfill(promise, maybeThenable);
        }
      }
    }

    function lib$es6$promise$$internal$$resolve(promise, value) {
      if (promise === value) {
        lib$es6$promise$$internal$$reject(promise, lib$es6$promise$$internal$$selfFullfillment());
      } else if (lib$es6$promise$utils$$objectOrFunction(value)) {
        lib$es6$promise$$internal$$handleMaybeThenable(promise, value);
      } else {
        lib$es6$promise$$internal$$fulfill(promise, value);
      }
    }

    function lib$es6$promise$$internal$$publishRejection(promise) {
      if (promise._onerror) {
        promise._onerror(promise._result);
      }

      lib$es6$promise$$internal$$publish(promise);
    }

    function lib$es6$promise$$internal$$fulfill(promise, value) {
      if (promise._state !== lib$es6$promise$$internal$$PENDING) { return; }

      promise._result = value;
      promise._state = lib$es6$promise$$internal$$FULFILLED;

      if (promise._subscribers.length !== 0) {
        lib$es6$promise$asap$$asap(lib$es6$promise$$internal$$publish, promise);
      }
    }

    function lib$es6$promise$$internal$$reject(promise, reason) {
      if (promise._state !== lib$es6$promise$$internal$$PENDING) { return; }
      promise._state = lib$es6$promise$$internal$$REJECTED;
      promise._result = reason;

      lib$es6$promise$asap$$asap(lib$es6$promise$$internal$$publishRejection, promise);
    }

    function lib$es6$promise$$internal$$subscribe(parent, child, onFulfillment, onRejection) {
      var subscribers = parent._subscribers;
      var length = subscribers.length;

      parent._onerror = null;

      subscribers[length] = child;
      subscribers[length + lib$es6$promise$$internal$$FULFILLED] = onFulfillment;
      subscribers[length + lib$es6$promise$$internal$$REJECTED]  = onRejection;

      if (length === 0 && parent._state) {
        lib$es6$promise$asap$$asap(lib$es6$promise$$internal$$publish, parent);
      }
    }

    function lib$es6$promise$$internal$$publish(promise) {
      var subscribers = promise._subscribers;
      var settled = promise._state;

      if (subscribers.length === 0) { return; }

      var child, callback, detail = promise._result;

      for (var i = 0; i < subscribers.length; i += 3) {
        child = subscribers[i];
        callback = subscribers[i + settled];

        if (child) {
          lib$es6$promise$$internal$$invokeCallback(settled, child, callback, detail);
        } else {
          callback(detail);
        }
      }

      promise._subscribers.length = 0;
    }

    function lib$es6$promise$$internal$$ErrorObject() {
      this.error = null;
    }

    var lib$es6$promise$$internal$$TRY_CATCH_ERROR = new lib$es6$promise$$internal$$ErrorObject();

    function lib$es6$promise$$internal$$tryCatch(callback, detail) {
      try {
        return callback(detail);
      } catch(e) {
        lib$es6$promise$$internal$$TRY_CATCH_ERROR.error = e;
        return lib$es6$promise$$internal$$TRY_CATCH_ERROR;
      }
    }

    function lib$es6$promise$$internal$$invokeCallback(settled, promise, callback, detail) {
      var hasCallback = lib$es6$promise$utils$$isFunction(callback),
          value, error, succeeded, failed;

      if (hasCallback) {
        value = lib$es6$promise$$internal$$tryCatch(callback, detail);

        if (value === lib$es6$promise$$internal$$TRY_CATCH_ERROR) {
          failed = true;
          error = value.error;
          value = null;
        } else {
          succeeded = true;
        }

        if (promise === value) {
          lib$es6$promise$$internal$$reject(promise, lib$es6$promise$$internal$$cannotReturnOwn());
          return;
        }

      } else {
        value = detail;
        succeeded = true;
      }

      if (promise._state !== lib$es6$promise$$internal$$PENDING) {
        // noop
      } else if (hasCallback && succeeded) {
        lib$es6$promise$$internal$$resolve(promise, value);
      } else if (failed) {
        lib$es6$promise$$internal$$reject(promise, error);
      } else if (settled === lib$es6$promise$$internal$$FULFILLED) {
        lib$es6$promise$$internal$$fulfill(promise, value);
      } else if (settled === lib$es6$promise$$internal$$REJECTED) {
        lib$es6$promise$$internal$$reject(promise, value);
      }
    }

    function lib$es6$promise$$internal$$initializePromise(promise, resolver) {
      try {
        resolver(function resolvePromise(value){
          lib$es6$promise$$internal$$resolve(promise, value);
        }, function rejectPromise(reason) {
          lib$es6$promise$$internal$$reject(promise, reason);
        });
      } catch(e) {
        lib$es6$promise$$internal$$reject(promise, e);
      }
    }

    function lib$es6$promise$enumerator$$Enumerator(Constructor, input) {
      var enumerator = this;

      enumerator._instanceConstructor = Constructor;
      enumerator.promise = new Constructor(lib$es6$promise$$internal$$noop);

      if (enumerator._validateInput(input)) {
        enumerator._input     = input;
        enumerator.length     = input.length;
        enumerator._remaining = input.length;

        enumerator._init();

        if (enumerator.length === 0) {
          lib$es6$promise$$internal$$fulfill(enumerator.promise, enumerator._result);
        } else {
          enumerator.length = enumerator.length || 0;
          enumerator._enumerate();
          if (enumerator._remaining === 0) {
            lib$es6$promise$$internal$$fulfill(enumerator.promise, enumerator._result);
          }
        }
      } else {
        lib$es6$promise$$internal$$reject(enumerator.promise, enumerator._validationError());
      }
    }

    lib$es6$promise$enumerator$$Enumerator.prototype._validateInput = function(input) {
      return lib$es6$promise$utils$$isArray(input);
    };

    lib$es6$promise$enumerator$$Enumerator.prototype._validationError = function() {
      return new Error('Array Methods must be provided an Array');
    };

    lib$es6$promise$enumerator$$Enumerator.prototype._init = function() {
      this._result = new Array(this.length);
    };

    var lib$es6$promise$enumerator$$default = lib$es6$promise$enumerator$$Enumerator;

    lib$es6$promise$enumerator$$Enumerator.prototype._enumerate = function() {
      var enumerator = this;

      var length  = enumerator.length;
      var promise = enumerator.promise;
      var input   = enumerator._input;

      for (var i = 0; promise._state === lib$es6$promise$$internal$$PENDING && i < length; i++) {
        enumerator._eachEntry(input[i], i);
      }
    };

    lib$es6$promise$enumerator$$Enumerator.prototype._eachEntry = function(entry, i) {
      var enumerator = this;
      var c = enumerator._instanceConstructor;

      if (lib$es6$promise$utils$$isMaybeThenable(entry)) {
        if (entry.constructor === c && entry._state !== lib$es6$promise$$internal$$PENDING) {
          entry._onerror = null;
          enumerator._settledAt(entry._state, i, entry._result);
        } else {
          enumerator._willSettleAt(c.resolve(entry), i);
        }
      } else {
        enumerator._remaining--;
        enumerator._result[i] = entry;
      }
    };

    lib$es6$promise$enumerator$$Enumerator.prototype._settledAt = function(state, i, value) {
      var enumerator = this;
      var promise = enumerator.promise;

      if (promise._state === lib$es6$promise$$internal$$PENDING) {
        enumerator._remaining--;

        if (state === lib$es6$promise$$internal$$REJECTED) {
          lib$es6$promise$$internal$$reject(promise, value);
        } else {
          enumerator._result[i] = value;
        }
      }

      if (enumerator._remaining === 0) {
        lib$es6$promise$$internal$$fulfill(promise, enumerator._result);
      }
    };

    lib$es6$promise$enumerator$$Enumerator.prototype._willSettleAt = function(promise, i) {
      var enumerator = this;

      lib$es6$promise$$internal$$subscribe(promise, undefined, function(value) {
        enumerator._settledAt(lib$es6$promise$$internal$$FULFILLED, i, value);
      }, function(reason) {
        enumerator._settledAt(lib$es6$promise$$internal$$REJECTED, i, reason);
      });
    };
    function lib$es6$promise$promise$all$$all(entries) {
      return new lib$es6$promise$enumerator$$default(this, entries).promise;
    }
    var lib$es6$promise$promise$all$$default = lib$es6$promise$promise$all$$all;
    function lib$es6$promise$promise$race$$race(entries) {
      /*jshint validthis:true */
      var Constructor = this;

      var promise = new Constructor(lib$es6$promise$$internal$$noop);

      if (!lib$es6$promise$utils$$isArray(entries)) {
        lib$es6$promise$$internal$$reject(promise, new TypeError('You must pass an array to race.'));
        return promise;
      }

      var length = entries.length;

      function onFulfillment(value) {
        lib$es6$promise$$internal$$resolve(promise, value);
      }

      function onRejection(reason) {
        lib$es6$promise$$internal$$reject(promise, reason);
      }

      for (var i = 0; promise._state === lib$es6$promise$$internal$$PENDING && i < length; i++) {
        lib$es6$promise$$internal$$subscribe(Constructor.resolve(entries[i]), undefined, onFulfillment, onRejection);
      }

      return promise;
    }
    var lib$es6$promise$promise$race$$default = lib$es6$promise$promise$race$$race;
    function lib$es6$promise$promise$resolve$$resolve(object) {
      /*jshint validthis:true */
      var Constructor = this;

      if (object && typeof object === 'object' && object.constructor === Constructor) {
        return object;
      }

      var promise = new Constructor(lib$es6$promise$$internal$$noop);
      lib$es6$promise$$internal$$resolve(promise, object);
      return promise;
    }
    var lib$es6$promise$promise$resolve$$default = lib$es6$promise$promise$resolve$$resolve;
    function lib$es6$promise$promise$reject$$reject(reason) {
      /*jshint validthis:true */
      var Constructor = this;
      var promise = new Constructor(lib$es6$promise$$internal$$noop);
      lib$es6$promise$$internal$$reject(promise, reason);
      return promise;
    }
    var lib$es6$promise$promise$reject$$default = lib$es6$promise$promise$reject$$reject;

    var lib$es6$promise$promise$$counter = 0;

    function lib$es6$promise$promise$$needsResolver() {
      throw new TypeError('You must pass a resolver function as the first argument to the promise constructor');
    }

    function lib$es6$promise$promise$$needsNew() {
      throw new TypeError("Failed to construct 'Promise': Please use the 'new' operator, this object constructor cannot be called as a function.");
    }

    var lib$es6$promise$promise$$default = lib$es6$promise$promise$$Promise;
    /**
      Promise objects represent the eventual result of an asynchronous operation. The
      primary way of interacting with a promise is through its `then` method, which
      registers callbacks to receive either a promise's eventual value or the reason
      why the promise cannot be fulfilled.

      Terminology
      -----------

      - `promise` is an object or function with a `then` method whose behavior conforms to this specification.
      - `thenable` is an object or function that defines a `then` method.
      - `value` is any legal JavaScript value (including undefined, a thenable, or a promise).
      - `exception` is a value that is thrown using the throw statement.
      - `reason` is a value that indicates why a promise was rejected.
      - `settled` the final resting state of a promise, fulfilled or rejected.

      A promise can be in one of three states: pending, fulfilled, or rejected.

      Promises that are fulfilled have a fulfillment value and are in the fulfilled
      state.  Promises that are rejected have a rejection reason and are in the
      rejected state.  A fulfillment value is never a thenable.

      Promises can also be said to *resolve* a value.  If this value is also a
      promise, then the original promise's settled state will match the value's
      settled state.  So a promise that *resolves* a promise that rejects will
      itself reject, and a promise that *resolves* a promise that fulfills will
      itself fulfill.


      Basic Usage:
      ------------

      ```js
      var promise = new Promise(function(resolve, reject) {
        // on success
        resolve(value);

        // on failure
        reject(reason);
      });

      promise.then(function(value) {
        // on fulfillment
      }, function(reason) {
        // on rejection
      });
      ```

      Advanced Usage:
      ---------------

      Promises shine when abstracting away asynchronous interactions such as
      `XMLHttpRequest`s.

      ```js
      function getJSON(url) {
        return new Promise(function(resolve, reject){
          var xhr = new XMLHttpRequest();

          xhr.open('GET', url);
          xhr.onreadystatechange = handler;
          xhr.responseType = 'json';
          xhr.setRequestHeader('Accept', 'application/json');
          xhr.send();

          function handler() {
            if (this.readyState === this.DONE) {
              if (this.status === 200) {
                resolve(this.response);
              } else {
                reject(new Error('getJSON: `' + url + '` failed with status: [' + this.status + ']'));
              }
            }
          };
        });
      }

      getJSON('/posts.json').then(function(json) {
        // on fulfillment
      }, function(reason) {
        // on rejection
      });
      ```

      Unlike callbacks, promises are great composable primitives.

      ```js
      Promise.all([
        getJSON('/posts'),
        getJSON('/comments')
      ]).then(function(values){
        values[0] // => postsJSON
        values[1] // => commentsJSON

        return values;
      });
      ```

      @class Promise
      @param {function} resolver
      Useful for tooling.
      @constructor
    */
    function lib$es6$promise$promise$$Promise(resolver) {
      this._id = lib$es6$promise$promise$$counter++;
      this._state = undefined;
      this._result = undefined;
      this._subscribers = [];

      if (lib$es6$promise$$internal$$noop !== resolver) {
        if (!lib$es6$promise$utils$$isFunction(resolver)) {
          lib$es6$promise$promise$$needsResolver();
        }

        if (!(this instanceof lib$es6$promise$promise$$Promise)) {
          lib$es6$promise$promise$$needsNew();
        }

        lib$es6$promise$$internal$$initializePromise(this, resolver);
      }
    }

    lib$es6$promise$promise$$Promise.all = lib$es6$promise$promise$all$$default;
    lib$es6$promise$promise$$Promise.race = lib$es6$promise$promise$race$$default;
    lib$es6$promise$promise$$Promise.resolve = lib$es6$promise$promise$resolve$$default;
    lib$es6$promise$promise$$Promise.reject = lib$es6$promise$promise$reject$$default;
    lib$es6$promise$promise$$Promise._setScheduler = lib$es6$promise$asap$$setScheduler;
    lib$es6$promise$promise$$Promise._setAsap = lib$es6$promise$asap$$setAsap;
    lib$es6$promise$promise$$Promise._asap = lib$es6$promise$asap$$asap;

    lib$es6$promise$promise$$Promise.prototype = {
      constructor: lib$es6$promise$promise$$Promise,

    /**
      The primary way of interacting with a promise is through its `then` method,
      which registers callbacks to receive either a promise's eventual value or the
      reason why the promise cannot be fulfilled.

      ```js
      findUser().then(function(user){
        // user is available
      }, function(reason){
        // user is unavailable, and you are given the reason why
      });
      ```

      Chaining
      --------

      The return value of `then` is itself a promise.  This second, 'downstream'
      promise is resolved with the return value of the first promise's fulfillment
      or rejection handler, or rejected if the handler throws an exception.

      ```js
      findUser().then(function (user) {
        return user.name;
      }, function (reason) {
        return 'default name';
      }).then(function (userName) {
        // If `findUser` fulfilled, `userName` will be the user's name, otherwise it
        // will be `'default name'`
      });

      findUser().then(function (user) {
        throw new Error('Found user, but still unhappy');
      }, function (reason) {
        throw new Error('`findUser` rejected and we're unhappy');
      }).then(function (value) {
        // never reached
      }, function (reason) {
        // if `findUser` fulfilled, `reason` will be 'Found user, but still unhappy'.
        // If `findUser` rejected, `reason` will be '`findUser` rejected and we're unhappy'.
      });
      ```
      If the downstream promise does not specify a rejection handler, rejection reasons will be propagated further downstream.

      ```js
      findUser().then(function (user) {
        throw new PedagogicalException('Upstream error');
      }).then(function (value) {
        // never reached
      }).then(function (value) {
        // never reached
      }, function (reason) {
        // The `PedgagocialException` is propagated all the way down to here
      });
      ```

      Assimilation
      ------------

      Sometimes the value you want to propagate to a downstream promise can only be
      retrieved asynchronously. This can be achieved by returning a promise in the
      fulfillment or rejection handler. The downstream promise will then be pending
      until the returned promise is settled. This is called *assimilation*.

      ```js
      findUser().then(function (user) {
        return findCommentsByAuthor(user);
      }).then(function (comments) {
        // The user's comments are now available
      });
      ```

      If the assimliated promise rejects, then the downstream promise will also reject.

      ```js
      findUser().then(function (user) {
        return findCommentsByAuthor(user);
      }).then(function (comments) {
        // If `findCommentsByAuthor` fulfills, we'll have the value here
      }, function (reason) {
        // If `findCommentsByAuthor` rejects, we'll have the reason here
      });
      ```

      Simple Example
      --------------

      Synchronous Example

      ```javascript
      var result;

      try {
        result = findResult();
        // success
      } catch(reason) {
        // failure
      }
      ```

      Errback Example

      ```js
      findResult(function(result, err){
        if (err) {
          // failure
        } else {
          // success
        }
      });
      ```

      Promise Example;

      ```javascript
      findResult().then(function(result){
        // success
      }, function(reason){
        // failure
      });
      ```

      Advanced Example
      --------------

      Synchronous Example

      ```javascript
      var author, books;

      try {
        author = findAuthor();
        books  = findBooksByAuthor(author);
        // success
      } catch(reason) {
        // failure
      }
      ```

      Errback Example

      ```js

      function foundBooks(books) {

      }

      function failure(reason) {

      }

      findAuthor(function(author, err){
        if (err) {
          failure(err);
          // failure
        } else {
          try {
            findBoooksByAuthor(author, function(books, err) {
              if (err) {
                failure(err);
              } else {
                try {
                  foundBooks(books);
                } catch(reason) {
                  failure(reason);
                }
              }
            });
          } catch(error) {
            failure(err);
          }
          // success
        }
      });
      ```

      Promise Example;

      ```javascript
      findAuthor().
        then(findBooksByAuthor).
        then(function(books){
          // found books
      }).catch(function(reason){
        // something went wrong
      });
      ```

      @method then
      @param {Function} onFulfilled
      @param {Function} onRejected
      Useful for tooling.
      @return {Promise}
    */
      then: function(onFulfillment, onRejection) {
        var parent = this;
        var state = parent._state;

        if (state === lib$es6$promise$$internal$$FULFILLED && !onFulfillment || state === lib$es6$promise$$internal$$REJECTED && !onRejection) {
          return this;
        }

        var child = new this.constructor(lib$es6$promise$$internal$$noop);
        var result = parent._result;

        if (state) {
          var callback = arguments[state - 1];
          lib$es6$promise$asap$$asap(function(){
            lib$es6$promise$$internal$$invokeCallback(state, child, callback, result);
          });
        } else {
          lib$es6$promise$$internal$$subscribe(parent, child, onFulfillment, onRejection);
        }

        return child;
      },

    /**
      `catch` is simply sugar for `then(undefined, onRejection)` which makes it the same
      as the catch block of a try/catch statement.

      ```js
      function findAuthor(){
        throw new Error('couldn't find that author');
      }

      // synchronous
      try {
        findAuthor();
      } catch(reason) {
        // something went wrong
      }

      // async with promises
      findAuthor().catch(function(reason){
        // something went wrong
      });
      ```

      @method catch
      @param {Function} onRejection
      Useful for tooling.
      @return {Promise}
    */
      'catch': function(onRejection) {
        return this.then(null, onRejection);
      }
    };
    function lib$es6$promise$polyfill$$polyfill() {
      var local;

      if (typeof global !== 'undefined') {
          local = global;
      } else if (typeof self !== 'undefined') {
          local = self;
      } else {
          try {
              local = Function('return this')();
          } catch (e) {
              throw new Error('polyfill failed because global object is unavailable in this environment');
          }
      }

      var P = local.Promise;

      if (P && Object.prototype.toString.call(P.resolve()) === '[object Promise]' && !P.cast) {
        return;
      }

      local.Promise = lib$es6$promise$promise$$default;
    }
    var lib$es6$promise$polyfill$$default = lib$es6$promise$polyfill$$polyfill;

    var lib$es6$promise$umd$$ES6Promise = {
      'Promise': lib$es6$promise$promise$$default,
      'polyfill': lib$es6$promise$polyfill$$default
    };

    /* global define:true module:true window: true */
    if (typeof define === 'function' && define['amd']) {
      define(function() { return lib$es6$promise$umd$$ES6Promise; });
    } else if (typeof module !== 'undefined' && module['exports']) {
      module['exports'] = lib$es6$promise$umd$$ES6Promise;
    } else if (typeof this !== 'undefined') {
      this['ES6Promise'] = lib$es6$promise$umd$$ES6Promise;
    }

    lib$es6$promise$polyfill$$default();
}).call(this);


}).call(this,require("oMfpAn"),typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
},{"oMfpAn":4}],8:[function(require,module,exports){
var setterGetterify = require('setter-getterify');
var DCBias = require('openmusic-dcbias');

function SamplePlayer(context) {
	var node = context.createGain();
	var nodeProperties = {
		buffer: null,
		loop: false,
		loopStart: 0,
		loopEnd: 0,
		pitchBend: null
	};

	var bufferSourcesCount = 0;
	var bufferSources = {};
	var bufferSourceProperties = {};
	var pitchBend = DCBias(context);

	nodeProperties.pitchBend = pitchBend.gain;
	pitchBend.gain.setValueAtTime(0, context.currentTime);

	setterGetterify(node, nodeProperties, {
		afterSetting: onNodePropertySet
	});

	
	// TODO: player can be mono or poly i.e. only one buffer can play at a given time or many can overlap

	node.start = function(when, offset, duration) {
		
		var buffer = nodeProperties['buffer'];
		if(!buffer) {
			console.info('OpenMusic SamplePlayer: no buffer to play, so byeee!');
			return;
		}

		when = when !== undefined ? when : 0;
		offset = offset !== undefined ? offset : 0;
		
		// TODO This is mega ugly but urgh what is going on urgh
		// if I just pass 'undefined' as duration Chrome doesn't play anything
		if(window.webkitAudioContext) {
			console.log('correcting for chrome aghh');
			var sampleLength = buffer.length;
			duration = duration !== undefined ? duration : sampleLength - offset;
		}

		// Mono: invalidate all scheduled bufferSources to make sure only one is played (retrig mode)
		// TODO implement invalidation code ...

		// Poly: it's fine, just add a new one to the list
		var bs = makeBufferSource();

		// console.log('start', 'when', when, 'offset', offset, 'duration', duration);
		bs.start(when, offset, duration);
		
	};

	node.stop = function(when) {
		// For ease of development, we'll just stop to all the sources and empty the queue
		// If you need to re-schedule them, you'll need to call start() again.
		var keys = Object.keys(bufferSources);
		keys.forEach(function(k) {
			var source = bufferSources[k];
			source.stop(when);
			removeFromQueue(source);
		});
	};

	node.cancelScheduledEvents = function(when) {
		// TODO: when/if there is automation
	};

	return node;
	
	//~~~

	function makeBufferSource() {

		var source = context.createBufferSource();
		source.addEventListener('ended', onBufferEnded);
		source.connect(node);
		source.id = bufferSourcesCount++;
		bufferSources[source.id] = source;

		pitchBend.connect(source.playbackRate);

		Object.keys(nodeProperties).forEach(function(name) {
			source[name] = nodeProperties[name];
		});

		return source;
		
	}

	function onBufferEnded(e) {
		var source = e.target;
		source.disconnect();
		pitchBend.disconnect(source.playbackRate);
		// also remove from list
		removeFromQueue(source);
	}

	function onNodePropertySet(property, value) {
		var keys = Object.keys(bufferSources);
		keys.forEach(function(k) {
			var src = bufferSources[k];
			src.loopStart = nodeProperties.loopStart;
			src.loopEnd = nodeProperties.loopEnd;
			src.loop = nodeProperties.loop;
		});
	}

	function removeFromQueue(source) {
		delete bufferSources[source.id];
	}

}

module.exports = SamplePlayer;

},{"openmusic-dcbias":9,"setter-getterify":10}],9:[function(require,module,exports){
(function() {
	
	function DCBias(context) {
		
		var output = context.createGain();
		var bufferSource = context.createBufferSource();
		var buffer = context.createBuffer(1, 1, context.sampleRate);

		buffer.getChannelData(0)[0] = 1.0;
		bufferSource.buffer = buffer;
		bufferSource.loop = true;
		
		bufferSource.connect(output);
		bufferSource.start(0);
		
		return output;
		
	}

	//
	
	if(typeof module !== 'undefined' && module.exports) {
		module.exports = DCBias;
	} else {
		this.DCBias = DCBias;
	}

}).call(this);

},{}],10:[function(require,module,exports){
module.exports = setterGetterify;


function setterGetterify(object, properties, callbacks) {
	callbacks = callbacks || {};
	var keys = Object.keys(properties);
	keys.forEach(function(key) {
		Object.defineProperty(object, key, makeGetterSetter(properties, key, callbacks));
	});
}


function makeGetterSetter(properties, property, callbacks) {
	var afterSetting = callbacks.afterSetting || function() {};
	return {
		get: function() {
			return getProperty(properties, property);
		},
		set: function(value) {
			setProperty(properties, property, value);
			afterSetting(property, value);
		},
		enumerable: true
	};
}


function getProperty(properties, name) {
	return properties[name];
}


function setProperty(properties, name, value) {
	properties[name] = value;
}



},{}],11:[function(require,module,exports){
(function() {
	require('openmusic-slider').register('openmusic-slider');
	require('openmusic-xycontroller').register('openmusic-xycontroller');

	var safeRegisterElement = require('safe-register-element');
	var MIDIUtils = require('midiutils');
	
	var proto = Object.create(HTMLElement.prototype);
	
	proto.createdCallback = function() {
		
		var that = this;

		this.values = {
			octaves: 5,
			baseNote: 24 // TODO make this configurable
		};
		
		this._lastPlayedFrequency = 0;
		this._lowerFrequency = 0;
		this._upperFrequency = 0;

		this._updateRanges();
		
		this.attachedTheremin = null;

		// making web components MVC framework proof.
		this.innerHTML = '';

		var xycontroller = document.createElement('openmusic-xycontroller');
		this.appendChild(xycontroller);

		this.appendChild(document.createElement('br'));
		
		var octavesInput = document.createElement('openmusic-slider');
		octavesInput.setAttribute('step', 1); // TODO why can't they work as properties? mmm
		octavesInput.setAttribute('min', 1);
		octavesInput.setAttribute('max', 8);
		octavesInput.setAttribute('value', this.values.octaves);

		octavesInput.addEventListener('input', function(e) {
			console.log(this.value);
			that.setValue('octaves', this.value);
		});
		this.appendChild(octavesInput);
	
		var divCurrentValues = document.createElement('div');
		this.appendChild(divCurrentValues);
	
		var spanFrequency = document.createElement('span');
		var separator = document.createElement('br');
		var spanNote = document.createElement('span');
		divCurrentValues.appendChild(spanFrequency);
		divCurrentValues.appendChild(separator); // TODO this layout is terrible, should make something better
		divCurrentValues.appendChild(spanNote);

		
		xycontroller.addEventListener('touchstart', function(ev) {
			if(!that.attachedTheremin) {
				return;
			}
			that._setFrequency(that._lastPlayedFrequency);
			that.attachedTheremin.start();
		});
	
		xycontroller.addEventListener('touchend', function(ev) {
			if(!that.attachedTheremin) {
				return;
			}
			that.attachedTheremin.stop();
		});
		
		xycontroller.addEventListener('input', function(ev) {

			// Why bother if we're not attached to any instrument?
			if(!that.attachedTheremin) {
				return;
			}

			var detail = ev.detail;
			var x = detail.x;
			var y = detail.y;
			var baseNote = that.values.baseNote;
			var octaves = that.values.octaves;
			var baseFrequency = that._lowerFrequency;
			var upperFrequency = that._upperFrequency;
			var intervalFrequency = upperFrequency - baseFrequency;
			var finalFrequency = mapValues(y, -1, 1, baseFrequency, upperFrequency);
			var finalNoteNumber = MIDIUtils.frequencyToNoteNumber(finalFrequency);
			var finalNote = MIDIUtils.noteNumberToName(finalNoteNumber);
			var finalVolume = mapValues(x, -1, 1, 0, 1);
			
			that._lastPlayedFrequency = finalFrequency;

			//console.log(baseFrequency, upperFrequency, finalFrequency);
			//
			spanFrequency.innerHTML = finalFrequency.toFixed(2) + ' (' + baseFrequency.toFixed(2) + '-' + upperFrequency.toFixed(2) + ' Hz)';
			spanNote.innerHTML = finalNote + ' (' + finalNoteNumber + ')';

			that._setFrequency(finalFrequency);
			that._setVolume(finalVolume);
			
		});
		
		// this.readAttributes();
		
	};

	// TODO make this a module
	function mapValues(value, in_min, in_max, out_min, out_max) {

		if(in_min == in_max) {
			return out_min;
		}

		return out_min + (out_max - out_min) * (value - in_min) / (in_max - in_min);
	}

	proto._updateRanges = function() {
		var baseNote = this.values.baseNote;
		var octaves = this.values.octaves;

		this._lowerFrequency = MIDIUtils.noteNumberToFrequency(baseNote);
		this._upperFrequency = MIDIUtils.noteNumberToFrequency(baseNote + octaves * 12);

	};

	proto._setFrequency = function(v) {
		if(!this.attachedTheremin) {
			return;
		}
		this.attachedTheremin.frequency.value = v;
	};

	proto._setVolume = function(v) {
		if(!this.attachedTheremin) {
			return;
		}
		this.attachedTheremin.volume.value = v;
	};

	proto.attachedCallback = function() {
		// Setup input listeners, perhaps start requestAnimationFrame here
	};


	proto.detachedCallback = function() {
	};


	proto.readAttributes = function() {
		var that = this;
		// TODO
		[].forEach(function(attr) {
			that.setValue(attr, that.getAttribute(attr));
		});
	};

	
	proto.setValue = function(name, value) {

		if(value !== undefined && value !== null) {
			this.values[name] = value;
		}

		// TODO: Potential re-draw or DOM update in reaction to these values
		this._updateRanges();
	};


	proto.getValue = function(name) {
		return this.values[name];
	};

	
	proto.attributeChangedCallback = function(attr, oldValue, newValue, namespace) {
		
		this.setValue(attr, newValue);
		
		// var e = new CustomEvent('change', { detail: this.values } });
		// this.dispatchEvent(e);
		
	};


	// Optional: for components that represent an audio node
	proto.attachTo = function(audioNode) {
		this.attachedTheremin = audioNode;
		/*audioNode.addEventListener('someevent', function(e) {
			// ...
		});*/
	};


	//


	var component = {};
	component.prototype = proto;
	component.register = function(name) {
		safeRegisterElement(name, proto);
	};

	if(typeof define === 'function' && define.amd) {
		define(function() { return component; });
	} else if(typeof module !== 'undefined' && module.exports) {
		module.exports = component;
	} else {
		component.register('openmusic-web-component-template'); // automatic registration
	}

}).call(this);


},{"midiutils":12,"openmusic-slider":13,"openmusic-xycontroller":15,"safe-register-element":16}],12:[function(require,module,exports){
(function() {

	var noteMap = {};
	var noteNumberMap = [];
	var notes = [ "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" ];


	for(var i = 0; i < 127; i++) {

		var index = i,
			key = notes[index % 12],
			octave = ((index / 12) | 0) - 1; // MIDI scale starts at octave = -1

		if(key.length === 1) {
			key = key + '-';
		}

		key += octave;

		noteMap[key] = i;
		noteNumberMap[i] = key;

	}


	function getBaseLog(value, base) {
		return Math.log(value) / Math.log(base);
	}


	var MIDIUtils = {

		noteNameToNoteNumber: function(name) {
			return noteMap[name];
		},

		noteNumberToFrequency: function(note) {
			return 440.0 * Math.pow(2, (note - 69.0) / 12.0);
		},

		noteNumberToName: function(note) {
			return noteNumberMap[note];
		},

		frequencyToNoteNumber: function(f) {
			return Math.round(12.0 * getBaseLog(f / 440.0, 2) + 69);
		}

	};


	// Make it compatible for require.js/AMD loader(s)
	if(typeof define === 'function' && define.amd) {
		define(function() { return MIDIUtils; });
	} else if(typeof module !== 'undefined' && module.exports) {
		// And for npm/node.js
		module.exports = MIDIUtils;
	} else {
		this.MIDIUtils = MIDIUtils;
	}


}).call(this);


},{}],13:[function(require,module,exports){
(function() {

	var setterGetterify = require('setter-getterify');
	var safeRegisterElement = require('safe-register-element');

	// Ideally it would be better to extend the HTMLInputElement prototype but
	// it doesn't seem to be working and I don't get any distinct element at all
	// or I get an "TypeError: 'type' setter called on an object that does not implement interface HTMLInputElement."
	// ... so using just HTMLElement for now
	var proto = Object.create(HTMLElement.prototype);

	proto.createdCallback = function() {

		var that = this;

		// Values
		var properties = {
			min: 0,
			max: 100,
			value: 50,
			step: 1
		};

		setterGetterify(this, properties, {
			afterSetting: function(property, value) {
				updateDisplay(that);
			}
		});
	
		this._properties = properties;

		// Markup
		var slider = document.createElement('input');
		slider.type = 'range';

		var valueSpan = document.createElement('span');

		this._slider = slider;
		this._valueSpan = valueSpan;

		this.appendChild(slider);
		this.appendChild(valueSpan);

		slider.addEventListener('input', function() {
			that.value = slider.value * 1.0;
		});

	};

	
	var sliderAttributes = [ 'min', 'max', 'value', 'step' ];

	proto.attachedCallback = function() {

		var attrs = this.attributes;
		var valueIsThere = false;
	
		for(var i = 0; i < attrs.length; i++) {
			var attr = attrs[i];

			if(attr.name === 'value') {
				valueIsThere = true;
			}

			// Just sending sensible attributes to the slider itself
			if(sliderAttributes.indexOf(attr.name) !== -1) {
				this._properties[attr.name] = attr.value;
			}
		}

		// If not specified, the default value has to be 
		// (min + max) / 2 as the normal slider would do as well.
		if(!valueIsThere) {
			var calculatedValue = (this._properties.min * 1.0 + this._properties.max * 1.0) / 2.0;
			this._properties.value = calculatedValue;
		}

		updateDisplay(this);

	};


	function updateDisplay(compo) {
		compo._valueSpan.innerHTML = compo._properties.value;
		compo._slider.value = compo._properties.value;
		compo._slider.min = compo._properties.min;
		compo._slider.max = compo._properties.max;
		compo._slider.step = compo._properties.step;
	}

	//
	
	var component = {};
	component.prototype = proto;
	component.register = function(name) {
		safeRegisterElement(name, proto);
	};

	if(typeof define === 'function' && define.amd) {
		define(function() { return component; });
	} else if(typeof module !== 'undefined' && module.exports) {
		module.exports = component;
	} else {
		component.register('openmusic-slider'); // automatic registration
	}

}).call(this);



},{"safe-register-element":16,"setter-getterify":14}],14:[function(require,module,exports){
module.exports=require(10)
},{}],15:[function(require,module,exports){
(function() {
	var safeRegisterElement = require('safe-register-element');

	var proto = Object.create(HTMLElement.prototype);

	var defaultWidth = 200;
	var defaultHeight = defaultWidth;
	// TODO Take into account display density!


	// x, y -> both -1, 1
	// TODO X, Y attributes
	// touch event -> x, y
	
	function render(canvas, x, y) {
		var ctx = canvas.getContext('2d');
		var canvasWidth = canvas.width;
		var canvasHeight = canvas.height;
		var canvasHalfHeight = canvasHeight * 0.5;

		// Tip: the additional + 0.5 is for getting a sharp line instead of a blurry one
		var canvasX = 0.5 * (1 + x) * canvasWidth + 0.5;
		var canvasY = canvasHeight - 0.5 * (1 + y) * canvasHeight + 0.5;

		ctx.lineWidth = 1;
		ctx.strokeStyle = 'rgb(0, 255, 0)';

		// vertical axis
		ctx.beginPath();
		ctx.moveTo(canvasX, 0);
		ctx.lineTo(canvasX, canvasHeight);
		ctx.stroke();

		// horizontal axis
		ctx.beginPath();
		ctx.moveTo(0, canvasY);
		ctx.lineTo(canvasWidth, canvasY);
		ctx.stroke();
		
	}

	
	proto.createdCallback = function() {
		
		this.values = { x: 0, y: 0, xpos: 0, ypos: 0 };

		// making web components MVC framework proof.
		this.innerHTML = '';
		
		var canvas = document.createElement('canvas');
		canvas.width = defaultWidth;
		canvas.height = defaultHeight;
		//this.x = 0;
		//this.y = 0;
		this.canvas = canvas;
		this.context = canvas.getContext('2d');
		this.appendChild(canvas);

		this._readElementPosition();	

		this.resetCanvas(this.context);

	};

	proto._readElementPosition = function() {
		this.values.xpos = this.canvas.offsetLeft;
		this.values.ypos = this.canvas.offsetTop;
	};

	
	proto.attachedCallback = function() {
		this.readAttributes();
		this.listenToInput();
		this.updateDisplay();
	};


	proto.detachedCallback = function() {
		this.stopListeningToInput();
	};


	proto.readAttributes = function() {
		var that = this;
		['x', 'y'].forEach(function(attr) {
			that.setValue(attr, that.getAttribute(attr));		
		});
	};

	
	proto.setValue = function(name, value) {
		// TODO clamp to -1, 1
		if(value !== undefined && value !== null) {
			this.values[name] = value;
		} /*
		// TODO: perhaps it doesn't make sense to delete the internal value ;-)
		 else {
			if(this.values[name]) {
				delete(this.values[name]);
			}
		}*/
		this.updateDisplay();
	};


	proto.getValue = function(name) {
		return this.values[name];
	};

	
	proto.attributeChangedCallback = function(attr, oldValue, newValue, namespace) {
		
		this.setValue(attr, newValue);
		// TODO: this is not exactly the right type of event I guess
		var e = new CustomEvent('input', { detail: { x: this.values.x, y: this.values.y } });
		this.dispatchEvent(e);
		
	};


	proto.listenToInput = function() {

		var onTouchStart = this.onTouchStart.bind(this);
		var onTouchEnd = this.onTouchEnd.bind(this);
		var onTouchMove = this.onTouchMove.bind(this);

		this.canvas.addEventListener('mousedown', onTouchStart);
		this.canvas.addEventListener('mouseup', onTouchEnd);
		this.canvas.addEventListener('touchmove', onTouchMove);

		this.boundOnTouchStart = onTouchStart;
		this.boundOnTouchEnd = onTouchEnd;
		this.boundOnTouchMove = onTouchMove;

	};


	proto.stopListeningToInput = function() {
		this.canvas.removeEventListener('mousedown', this.boundOnTouchStart);
		this.canvas.removeEventListener('mouseup', this.boundOnTouchEnd);
		document.body.removeEventListener('mouseup', this.boundOnTouchEnd);
		this.canvas.removeEventListener('touchmove', this.boundOnTouchMove);
	};


	proto.onTouchStart = function(ev) {
		var onTouchMove = this.boundOnTouchMove;
		this.canvas.addEventListener('mousemove', onTouchMove);
		document.body.addEventListener('mouseup', this.boundOnTouchEnd);

		var e = new CustomEvent('touchstart');
		this.dispatchEvent(e);

		// TODO is this a good idea? but it seems to get the job done?
		// AKA: process the position of the touch when user interaction starts
		this.onTouchMove(ev);
	};


	proto.onTouchMove = function(ev) {
		var canvasWidth = this.canvas.width;
		var canvasHeight = this.canvas.height;
		
		// Using cached element positions, if you haved moved it since it
		// was attached to the DOM you will need to call the _readElementPosition
		// method again
		var elPosX = this.values.xpos;
		var elPosY = this.values.ypos;
		var eventX;
		var eventY;

		if(ev.touches) {
			var touches = ev.touches;
			var touch = touches[0];
			eventX = touch.clientX - elPosX;
			eventY = touch.clientY - elPosY;
		} else {
			eventX = ev.layerX - elPosX;
			eventY = ev.layerY - elPosY;
		}
		
		var relX;
		var relY;

		if(eventX < 0) {
			eventX = 0;
		} else if(eventX > canvasWidth) {
			eventX = canvasWidth;
		}

		if(eventY < 0) {
			eventY = 0;
		} else if(eventY > canvasHeight) {
			eventY = canvasHeight;
		}

		relX = (eventX / canvasWidth - 0.5) * 2;
		relY = - (eventY / canvasHeight - 0.5) * 2;

		this.setValue('x', relX);
		this.setValue('y', relY);

		// emit event and...
		var e = new CustomEvent('input', { detail: { x: relX, y: relY }});
		this.dispatchEvent(e);

		// Update with the new values!
		this.updateDisplay();
		
	};


	proto.onTouchEnd = function(ev) {
		this.canvas.removeEventListener('touchmove', this.boundOnTouchMove);
		this.canvas.removeEventListener('mousemove', this.boundOnTouchMove);

		var e = new CustomEvent('touchend');
		this.dispatchEvent(e);
	};

	
	proto.updateDisplay = function() {
		this.resetCanvas();
		render(this.canvas, this.getValue('x') * 1, this.getValue('y') * 1);
	};


	proto.resetCanvas = function() {
		var ctx = this.context;
		var canvas = this.canvas;

		ctx.fillStyle = 'rgba(0, 50, 0, 1)';
		ctx.fillRect(0, 0, canvas.width, canvas.height);
	};

	//

	var component = {};
	component.prototype = proto;
	component.register = function(name) {
		safeRegisterElement(name, proto);
	};

	if(typeof define === 'function' && define.amd) {
		define(function() { return component; });
	} else if(typeof module !== 'undefined' && module.exports) {
		module.exports = component;
	} else {
		component.register('openmusic-xycontroller'); // automatic registration
	}

}).call(this);

},{"safe-register-element":16}],16:[function(require,module,exports){
module.exports = function safeRegistration(name, prototype) {
	try {
		document.registerElement(name, {
			prototype: prototype
		});
	} catch(e) {
		console.log('Exception when registering ' + name + '; perhaps it has been registered already?');
	}
};

},{}],17:[function(require,module,exports){
var setterGetterify = require('setter-getterify');
var Oscillator = require('openmusic-oscillator');
var DCBias = require('openmusic-dcbias');

module.exports = function(context) {
	
	var node = context.createGain();
	var oscillator = Oscillator(context);
	oscillator.connect(node);

	var frequency = DCBias(context);
	frequency.connect(oscillator.frequency);



	/*var nodeProperties = {
		frequency: 440.0
	};

	setterGetterify(node, nodeProperties, {
		afterSetting: function(property, value) {
			console.log(property, 'was set', value);
		}
	});*/

	// Aliasing because it's weird to write theremin.frequency.gain.value
	// instead of theremin.frequency.value, or theremin.frequency.setValueAtTime... etc
	node.frequency = frequency.gain;
	node.volume = node.gain;

	node.start = function(when, offset, duration) {
		
		console.log('start', 'when', when, 'offset', offset, 'duration', duration);

		when = when !== undefined ? when : 0;
		offset = offset !== undefined ? offset : 0;

		oscillator.start(when);
		
	};

	node.stop = function(when) {
		oscillator.stop(when);
	};

	node.cancelScheduledEvents = function(when) {
	};

	return node;

};


},{"openmusic-dcbias":18,"openmusic-oscillator":19,"setter-getterify":20}],18:[function(require,module,exports){
module.exports=require(9)
},{}],19:[function(require,module,exports){
(function() {

	var DCBias = require('openmusic-dcbias');

	function Oscillator(context) {
		
		var node = context.createGain();
		var oscillator;
		var frequencySignal;
		var properties = {};

		frequencySignal = DCBias(context);
		node.frequency = frequencySignal.gain;
		node.frequency.setValueAtTime(440, context.currentTime);

		['type'].forEach(function(name) {
			Object.defineProperty(node, name, makePropertyGetterSetter(name));
		});

		node.start = function(when) {

			deinitialiseOscillator();

			initialiseOscillator();

			when = when !== undefined ? when : context.currentTime;

			oscillator.start(when);
		};

		node.stop = function(when) {
			oscillator.stop(when);
		};

		node.cancelScheduledEvents = function(when) {
			// automated params:
			node.frequency.cancelScheduledEvents(when);
		};

		return node;

		// ~~~

		function initialiseOscillator() {
			oscillator = context.createOscillator();
			oscillator.addEventListener('ended', onEnded);
			oscillator.connect(node);

			Object.keys(properties).forEach(function(name) {
				oscillator[name] = properties[name];
			});

			oscillator.frequency.setValueAtTime(0, context.currentTime);
			frequencySignal.connect(oscillator.frequency);
		}

		function deinitialiseOscillator() {
			if(oscillator) {
				oscillator.removeEventListener('ended', onEnded);
				oscillator.disconnect(node);
				frequencySignal.disconnect(oscillator.frequency);
				oscillator = null;
			}
		}

		function onEnded(e) {
			deinitialiseOscillator();
		}

		function makePropertyGetterSetter(property) {
			return {
				get: function() {
					return getProperty(property);
				},
				set: function(v) {
					setProperty(property, v);
				},
				enumerable: true
			};
		}

		function getProperty(name) {
			return properties[name];
		}

		function setProperty(name, value) {
			properties[name] = value;
			if(oscillator) {
				oscillator[name] = value;
			}
		}

	}

	//
	
	if(typeof module !== 'undefined' && module.exports) {
		module.exports = Oscillator;
	} else {
		this.Oscillator = Oscillator;
	}

}).call(this);


},{"openmusic-dcbias":18}],20:[function(require,module,exports){
module.exports=require(10)
},{}],21:[function(require,module,exports){
(function() {
	var proto = Object.create(HTMLElement.prototype);

	var OpenMusicSlider = require('openmusic-slider');

	try {
		OpenMusicSlider.register('openmusic-slider');
	} catch(e) {
		// The slider might have been registered already, but if we register again
		// it will throw. So let's catch it and silently shut up.
	}
	
	proto.createdCallback = function() {
		
		var that = this;
		this.values = {};

		// making web components MWC framework proof.
		this.innerHTML = '';

		var templateContents = 
			'<button class="play">Play</button>' +
			'<button class="stop" disabled>Stop</button>' +
			'<label>BPM <openmusic-slider min="1" max="300" value="125"></openmusic-slider></label>';
		var template = document.createElement('template');
		template.innerHTML = templateContents;

		var liveHTML = document.importNode(template.content, true);
		var div = document.createElement('div');
		div.appendChild(liveHTML);
		
		var playButton = div.querySelector('[class=play]');
		var stopButton = div.querySelector('[class=stop]');

		playButton.addEventListener('click', function() {
			setEnabled(playButton, false);
			setEnabled(stopButton, true);
			dispatchEvent('play', that);
		});

		stopButton.addEventListener('click', function() {
			setEnabled(playButton, true);
			setEnabled(stopButton, false);
			dispatchEvent('stop', that);
		});

		var slider = div.querySelector('openmusic-slider');
		slider.addEventListener('input', function() {
			dispatchEvent('bpm', that, { value: slider.value * 1.0 });
		});

		this.appendChild(div);
		this.readAttributes();
		
	};

	
	function dispatchEvent(type, element, detail) {
		detail = detail || {};
		
		var ev = new CustomEvent(type, { detail: detail });
		element.dispatchEvent(ev);
	}

	function setEnabled(button, enabled) {
		if(!enabled) {
			button.setAttribute('disabled', 'disabled');
		} else {
			button.removeAttribute('disabled');
		}
	}

	
	proto.attachedCallback = function() {
	};


	proto.detachedCallback = function() {
	};


	proto.readAttributes = function() {
		var that = this;
		[].forEach(function(attr) {
			that.setValue(attr, that.getAttribute(attr));		
		});
	};

	
	proto.setValue = function(name, value) {

		if(value !== undefined && value !== null) {
			this.values[name] = value;
		}

		// TODO: Potential re-draw or DOM update in reaction to these values
	};


	proto.getValue = function(name) {
		return this.values[name];
	};

	
	proto.attributeChangedCallback = function(attr, oldValue, newValue, namespace) {
		
		this.setValue(attr, newValue);
		
		// var e = new CustomEvent('change', { detail: this.values } });
		// this.dispatchEvent(e);
		
	};


	// Optional: for components that represent an audio node
	proto.attachTo = function(audioNode) {
		audioNode.addEventListener('someevent', function(e) {
			// ...
		});
	};


	//


	var component = {};
	component.prototype = proto;
	component.register = function(name) {
		document.registerElement(name, {
			prototype: proto
		});
	};

	if(typeof define === 'function' && define.amd) {
		define(function() { return component; });
	} else if(typeof module !== 'undefined' && module.exports) {
		module.exports = component;
	} else {
		component.register('openmusic-web-component-template'); // automatic registration
	}

}).call(this);


},{"openmusic-slider":22}],22:[function(require,module,exports){
module.exports=require(13)
},{"safe-register-element":23,"setter-getterify":24}],23:[function(require,module,exports){
module.exports=require(16)
},{}],24:[function(require,module,exports){
module.exports=require(10)
},{}],25:[function(require,module,exports){
/**
 * @license
 * Copyright (c) 2014 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
 */
// @version 0.6.0-58c8709
window.WebComponents = window.WebComponents || {};

(function(scope) {
  var flags = scope.flags || {};
  var file = "webcomponents.js";
  var script = document.querySelector('script[src*="' + file + '"]');
  if (!flags.noOpts) {
    location.search.slice(1).split("&").forEach(function(o) {
      o = o.split("=");
      o[0] && (flags[o[0]] = o[1] || true);
    });
    if (script) {
      for (var i = 0, a; a = script.attributes[i]; i++) {
        if (a.name !== "src") {
          flags[a.name] = a.value || true;
        }
      }
    }
    if (flags.log) {
      var parts = flags.log.split(",");
      flags.log = {};
      parts.forEach(function(f) {
        flags.log[f] = true;
      });
    } else {
      flags.log = {};
    }
  }
  flags.shadow = flags.shadow || flags.shadowdom || flags.polyfill;
  if (flags.shadow === "native") {
    flags.shadow = false;
  } else {
    flags.shadow = flags.shadow || !HTMLElement.prototype.createShadowRoot;
  }
  if (flags.register) {
    window.CustomElements = window.CustomElements || {
      flags: {}
    };
    window.CustomElements.flags.register = flags.register;
  }
  scope.flags = flags;
})(WebComponents);

(function(scope) {
  "use strict";
  var hasWorkingUrl = false;
  if (!scope.forceJURL) {
    try {
      var u = new URL("b", "http://a");
      u.pathname = "c%20d";
      hasWorkingUrl = u.href === "http://a/c%20d";
    } catch (e) {}
  }
  if (hasWorkingUrl) return;
  var relative = Object.create(null);
  relative["ftp"] = 21;
  relative["file"] = 0;
  relative["gopher"] = 70;
  relative["http"] = 80;
  relative["https"] = 443;
  relative["ws"] = 80;
  relative["wss"] = 443;
  var relativePathDotMapping = Object.create(null);
  relativePathDotMapping["%2e"] = ".";
  relativePathDotMapping[".%2e"] = "..";
  relativePathDotMapping["%2e."] = "..";
  relativePathDotMapping["%2e%2e"] = "..";
  function isRelativeScheme(scheme) {
    return relative[scheme] !== undefined;
  }
  function invalid() {
    clear.call(this);
    this._isInvalid = true;
  }
  function IDNAToASCII(h) {
    if ("" == h) {
      invalid.call(this);
    }
    return h.toLowerCase();
  }
  function percentEscape(c) {
    var unicode = c.charCodeAt(0);
    if (unicode > 32 && unicode < 127 && [ 34, 35, 60, 62, 63, 96 ].indexOf(unicode) == -1) {
      return c;
    }
    return encodeURIComponent(c);
  }
  function percentEscapeQuery(c) {
    var unicode = c.charCodeAt(0);
    if (unicode > 32 && unicode < 127 && [ 34, 35, 60, 62, 96 ].indexOf(unicode) == -1) {
      return c;
    }
    return encodeURIComponent(c);
  }
  var EOF = undefined, ALPHA = /[a-zA-Z]/, ALPHANUMERIC = /[a-zA-Z0-9\+\-\.]/;
  function parse(input, stateOverride, base) {
    function err(message) {
      errors.push(message);
    }
    var state = stateOverride || "scheme start", cursor = 0, buffer = "", seenAt = false, seenBracket = false, errors = [];
    loop: while ((input[cursor - 1] != EOF || cursor == 0) && !this._isInvalid) {
      var c = input[cursor];
      switch (state) {
       case "scheme start":
        if (c && ALPHA.test(c)) {
          buffer += c.toLowerCase();
          state = "scheme";
        } else if (!stateOverride) {
          buffer = "";
          state = "no scheme";
          continue;
        } else {
          err("Invalid scheme.");
          break loop;
        }
        break;

       case "scheme":
        if (c && ALPHANUMERIC.test(c)) {
          buffer += c.toLowerCase();
        } else if (":" == c) {
          this._scheme = buffer;
          buffer = "";
          if (stateOverride) {
            break loop;
          }
          if (isRelativeScheme(this._scheme)) {
            this._isRelative = true;
          }
          if ("file" == this._scheme) {
            state = "relative";
          } else if (this._isRelative && base && base._scheme == this._scheme) {
            state = "relative or authority";
          } else if (this._isRelative) {
            state = "authority first slash";
          } else {
            state = "scheme data";
          }
        } else if (!stateOverride) {
          buffer = "";
          cursor = 0;
          state = "no scheme";
          continue;
        } else if (EOF == c) {
          break loop;
        } else {
          err("Code point not allowed in scheme: " + c);
          break loop;
        }
        break;

       case "scheme data":
        if ("?" == c) {
          query = "?";
          state = "query";
        } else if ("#" == c) {
          this._fragment = "#";
          state = "fragment";
        } else {
          if (EOF != c && "	" != c && "\n" != c && "\r" != c) {
            this._schemeData += percentEscape(c);
          }
        }
        break;

       case "no scheme":
        if (!base || !isRelativeScheme(base._scheme)) {
          err("Missing scheme.");
          invalid.call(this);
        } else {
          state = "relative";
          continue;
        }
        break;

       case "relative or authority":
        if ("/" == c && "/" == input[cursor + 1]) {
          state = "authority ignore slashes";
        } else {
          err("Expected /, got: " + c);
          state = "relative";
          continue;
        }
        break;

       case "relative":
        this._isRelative = true;
        if ("file" != this._scheme) this._scheme = base._scheme;
        if (EOF == c) {
          this._host = base._host;
          this._port = base._port;
          this._path = base._path.slice();
          this._query = base._query;
          break loop;
        } else if ("/" == c || "\\" == c) {
          if ("\\" == c) err("\\ is an invalid code point.");
          state = "relative slash";
        } else if ("?" == c) {
          this._host = base._host;
          this._port = base._port;
          this._path = base._path.slice();
          this._query = "?";
          state = "query";
        } else if ("#" == c) {
          this._host = base._host;
          this._port = base._port;
          this._path = base._path.slice();
          this._query = base._query;
          this._fragment = "#";
          state = "fragment";
        } else {
          var nextC = input[cursor + 1];
          var nextNextC = input[cursor + 2];
          if ("file" != this._scheme || !ALPHA.test(c) || nextC != ":" && nextC != "|" || EOF != nextNextC && "/" != nextNextC && "\\" != nextNextC && "?" != nextNextC && "#" != nextNextC) {
            this._host = base._host;
            this._port = base._port;
            this._path = base._path.slice();
            this._path.pop();
          }
          state = "relative path";
          continue;
        }
        break;

       case "relative slash":
        if ("/" == c || "\\" == c) {
          if ("\\" == c) {
            err("\\ is an invalid code point.");
          }
          if ("file" == this._scheme) {
            state = "file host";
          } else {
            state = "authority ignore slashes";
          }
        } else {
          if ("file" != this._scheme) {
            this._host = base._host;
            this._port = base._port;
          }
          state = "relative path";
          continue;
        }
        break;

       case "authority first slash":
        if ("/" == c) {
          state = "authority second slash";
        } else {
          err("Expected '/', got: " + c);
          state = "authority ignore slashes";
          continue;
        }
        break;

       case "authority second slash":
        state = "authority ignore slashes";
        if ("/" != c) {
          err("Expected '/', got: " + c);
          continue;
        }
        break;

       case "authority ignore slashes":
        if ("/" != c && "\\" != c) {
          state = "authority";
          continue;
        } else {
          err("Expected authority, got: " + c);
        }
        break;

       case "authority":
        if ("@" == c) {
          if (seenAt) {
            err("@ already seen.");
            buffer += "%40";
          }
          seenAt = true;
          for (var i = 0; i < buffer.length; i++) {
            var cp = buffer[i];
            if ("	" == cp || "\n" == cp || "\r" == cp) {
              err("Invalid whitespace in authority.");
              continue;
            }
            if (":" == cp && null === this._password) {
              this._password = "";
              continue;
            }
            var tempC = percentEscape(cp);
            null !== this._password ? this._password += tempC : this._username += tempC;
          }
          buffer = "";
        } else if (EOF == c || "/" == c || "\\" == c || "?" == c || "#" == c) {
          cursor -= buffer.length;
          buffer = "";
          state = "host";
          continue;
        } else {
          buffer += c;
        }
        break;

       case "file host":
        if (EOF == c || "/" == c || "\\" == c || "?" == c || "#" == c) {
          if (buffer.length == 2 && ALPHA.test(buffer[0]) && (buffer[1] == ":" || buffer[1] == "|")) {
            state = "relative path";
          } else if (buffer.length == 0) {
            state = "relative path start";
          } else {
            this._host = IDNAToASCII.call(this, buffer);
            buffer = "";
            state = "relative path start";
          }
          continue;
        } else if ("	" == c || "\n" == c || "\r" == c) {
          err("Invalid whitespace in file host.");
        } else {
          buffer += c;
        }
        break;

       case "host":
       case "hostname":
        if (":" == c && !seenBracket) {
          this._host = IDNAToASCII.call(this, buffer);
          buffer = "";
          state = "port";
          if ("hostname" == stateOverride) {
            break loop;
          }
        } else if (EOF == c || "/" == c || "\\" == c || "?" == c || "#" == c) {
          this._host = IDNAToASCII.call(this, buffer);
          buffer = "";
          state = "relative path start";
          if (stateOverride) {
            break loop;
          }
          continue;
        } else if ("	" != c && "\n" != c && "\r" != c) {
          if ("[" == c) {
            seenBracket = true;
          } else if ("]" == c) {
            seenBracket = false;
          }
          buffer += c;
        } else {
          err("Invalid code point in host/hostname: " + c);
        }
        break;

       case "port":
        if (/[0-9]/.test(c)) {
          buffer += c;
        } else if (EOF == c || "/" == c || "\\" == c || "?" == c || "#" == c || stateOverride) {
          if ("" != buffer) {
            var temp = parseInt(buffer, 10);
            if (temp != relative[this._scheme]) {
              this._port = temp + "";
            }
            buffer = "";
          }
          if (stateOverride) {
            break loop;
          }
          state = "relative path start";
          continue;
        } else if ("	" == c || "\n" == c || "\r" == c) {
          err("Invalid code point in port: " + c);
        } else {
          invalid.call(this);
        }
        break;

       case "relative path start":
        if ("\\" == c) err("'\\' not allowed in path.");
        state = "relative path";
        if ("/" != c && "\\" != c) {
          continue;
        }
        break;

       case "relative path":
        if (EOF == c || "/" == c || "\\" == c || !stateOverride && ("?" == c || "#" == c)) {
          if ("\\" == c) {
            err("\\ not allowed in relative path.");
          }
          var tmp;
          if (tmp = relativePathDotMapping[buffer.toLowerCase()]) {
            buffer = tmp;
          }
          if (".." == buffer) {
            this._path.pop();
            if ("/" != c && "\\" != c) {
              this._path.push("");
            }
          } else if ("." == buffer && "/" != c && "\\" != c) {
            this._path.push("");
          } else if ("." != buffer) {
            if ("file" == this._scheme && this._path.length == 0 && buffer.length == 2 && ALPHA.test(buffer[0]) && buffer[1] == "|") {
              buffer = buffer[0] + ":";
            }
            this._path.push(buffer);
          }
          buffer = "";
          if ("?" == c) {
            this._query = "?";
            state = "query";
          } else if ("#" == c) {
            this._fragment = "#";
            state = "fragment";
          }
        } else if ("	" != c && "\n" != c && "\r" != c) {
          buffer += percentEscape(c);
        }
        break;

       case "query":
        if (!stateOverride && "#" == c) {
          this._fragment = "#";
          state = "fragment";
        } else if (EOF != c && "	" != c && "\n" != c && "\r" != c) {
          this._query += percentEscapeQuery(c);
        }
        break;

       case "fragment":
        if (EOF != c && "	" != c && "\n" != c && "\r" != c) {
          this._fragment += c;
        }
        break;
      }
      cursor++;
    }
  }
  function clear() {
    this._scheme = "";
    this._schemeData = "";
    this._username = "";
    this._password = null;
    this._host = "";
    this._port = "";
    this._path = [];
    this._query = "";
    this._fragment = "";
    this._isInvalid = false;
    this._isRelative = false;
  }
  function jURL(url, base) {
    if (base !== undefined && !(base instanceof jURL)) base = new jURL(String(base));
    this._url = url;
    clear.call(this);
    var input = url.replace(/^[ \t\r\n\f]+|[ \t\r\n\f]+$/g, "");
    parse.call(this, input, null, base);
  }
  jURL.prototype = {
    toString: function() {
      return this.href;
    },
    get href() {
      if (this._isInvalid) return this._url;
      var authority = "";
      if ("" != this._username || null != this._password) {
        authority = this._username + (null != this._password ? ":" + this._password : "") + "@";
      }
      return this.protocol + (this._isRelative ? "//" + authority + this.host : "") + this.pathname + this._query + this._fragment;
    },
    set href(href) {
      clear.call(this);
      parse.call(this, href);
    },
    get protocol() {
      return this._scheme + ":";
    },
    set protocol(protocol) {
      if (this._isInvalid) return;
      parse.call(this, protocol + ":", "scheme start");
    },
    get host() {
      return this._isInvalid ? "" : this._port ? this._host + ":" + this._port : this._host;
    },
    set host(host) {
      if (this._isInvalid || !this._isRelative) return;
      parse.call(this, host, "host");
    },
    get hostname() {
      return this._host;
    },
    set hostname(hostname) {
      if (this._isInvalid || !this._isRelative) return;
      parse.call(this, hostname, "hostname");
    },
    get port() {
      return this._port;
    },
    set port(port) {
      if (this._isInvalid || !this._isRelative) return;
      parse.call(this, port, "port");
    },
    get pathname() {
      return this._isInvalid ? "" : this._isRelative ? "/" + this._path.join("/") : this._schemeData;
    },
    set pathname(pathname) {
      if (this._isInvalid || !this._isRelative) return;
      this._path = [];
      parse.call(this, pathname, "relative path start");
    },
    get search() {
      return this._isInvalid || !this._query || "?" == this._query ? "" : this._query;
    },
    set search(search) {
      if (this._isInvalid || !this._isRelative) return;
      this._query = "?";
      if ("?" == search[0]) search = search.slice(1);
      parse.call(this, search, "query");
    },
    get hash() {
      return this._isInvalid || !this._fragment || "#" == this._fragment ? "" : this._fragment;
    },
    set hash(hash) {
      if (this._isInvalid) return;
      this._fragment = "#";
      if ("#" == hash[0]) hash = hash.slice(1);
      parse.call(this, hash, "fragment");
    },
    get origin() {
      var host;
      if (this._isInvalid || !this._scheme) {
        return "";
      }
      switch (this._scheme) {
       case "data":
       case "file":
       case "javascript":
       case "mailto":
        return "null";
      }
      host = this.host;
      if (!host) {
        return "";
      }
      return this._scheme + "://" + host;
    }
  };
  var OriginalURL = scope.URL;
  if (OriginalURL) {
    jURL.createObjectURL = function(blob) {
      return OriginalURL.createObjectURL.apply(OriginalURL, arguments);
    };
    jURL.revokeObjectURL = function(url) {
      OriginalURL.revokeObjectURL(url);
    };
  }
  scope.URL = jURL;
})(this);

if (typeof WeakMap === "undefined") {
  (function() {
    var defineProperty = Object.defineProperty;
    var counter = Date.now() % 1e9;
    var WeakMap = function() {
      this.name = "__st" + (Math.random() * 1e9 >>> 0) + (counter++ + "__");
    };
    WeakMap.prototype = {
      set: function(key, value) {
        var entry = key[this.name];
        if (entry && entry[0] === key) entry[1] = value; else defineProperty(key, this.name, {
          value: [ key, value ],
          writable: true
        });
        return this;
      },
      get: function(key) {
        var entry;
        return (entry = key[this.name]) && entry[0] === key ? entry[1] : undefined;
      },
      "delete": function(key) {
        var entry = key[this.name];
        if (!entry || entry[0] !== key) return false;
        entry[0] = entry[1] = undefined;
        return true;
      },
      has: function(key) {
        var entry = key[this.name];
        if (!entry) return false;
        return entry[0] === key;
      }
    };
    window.WeakMap = WeakMap;
  })();
}

(function(global) {
  var registrationsTable = new WeakMap();
  var setImmediate;
  if (/Trident|Edge/.test(navigator.userAgent)) {
    setImmediate = setTimeout;
  } else if (window.setImmediate) {
    setImmediate = window.setImmediate;
  } else {
    var setImmediateQueue = [];
    var sentinel = String(Math.random());
    window.addEventListener("message", function(e) {
      if (e.data === sentinel) {
        var queue = setImmediateQueue;
        setImmediateQueue = [];
        queue.forEach(function(func) {
          func();
        });
      }
    });
    setImmediate = function(func) {
      setImmediateQueue.push(func);
      window.postMessage(sentinel, "*");
    };
  }
  var isScheduled = false;
  var scheduledObservers = [];
  function scheduleCallback(observer) {
    scheduledObservers.push(observer);
    if (!isScheduled) {
      isScheduled = true;
      setImmediate(dispatchCallbacks);
    }
  }
  function wrapIfNeeded(node) {
    return window.ShadowDOMPolyfill && window.ShadowDOMPolyfill.wrapIfNeeded(node) || node;
  }
  function dispatchCallbacks() {
    isScheduled = false;
    var observers = scheduledObservers;
    scheduledObservers = [];
    observers.sort(function(o1, o2) {
      return o1.uid_ - o2.uid_;
    });
    var anyNonEmpty = false;
    observers.forEach(function(observer) {
      var queue = observer.takeRecords();
      removeTransientObserversFor(observer);
      if (queue.length) {
        observer.callback_(queue, observer);
        anyNonEmpty = true;
      }
    });
    if (anyNonEmpty) dispatchCallbacks();
  }
  function removeTransientObserversFor(observer) {
    observer.nodes_.forEach(function(node) {
      var registrations = registrationsTable.get(node);
      if (!registrations) return;
      registrations.forEach(function(registration) {
        if (registration.observer === observer) registration.removeTransientObservers();
      });
    });
  }
  function forEachAncestorAndObserverEnqueueRecord(target, callback) {
    for (var node = target; node; node = node.parentNode) {
      var registrations = registrationsTable.get(node);
      if (registrations) {
        for (var j = 0; j < registrations.length; j++) {
          var registration = registrations[j];
          var options = registration.options;
          if (node !== target && !options.subtree) continue;
          var record = callback(options);
          if (record) registration.enqueue(record);
        }
      }
    }
  }
  var uidCounter = 0;
  function JsMutationObserver(callback) {
    this.callback_ = callback;
    this.nodes_ = [];
    this.records_ = [];
    this.uid_ = ++uidCounter;
  }
  JsMutationObserver.prototype = {
    observe: function(target, options) {
      target = wrapIfNeeded(target);
      if (!options.childList && !options.attributes && !options.characterData || options.attributeOldValue && !options.attributes || options.attributeFilter && options.attributeFilter.length && !options.attributes || options.characterDataOldValue && !options.characterData) {
        throw new SyntaxError();
      }
      var registrations = registrationsTable.get(target);
      if (!registrations) registrationsTable.set(target, registrations = []);
      var registration;
      for (var i = 0; i < registrations.length; i++) {
        if (registrations[i].observer === this) {
          registration = registrations[i];
          registration.removeListeners();
          registration.options = options;
          break;
        }
      }
      if (!registration) {
        registration = new Registration(this, target, options);
        registrations.push(registration);
        this.nodes_.push(target);
      }
      registration.addListeners();
    },
    disconnect: function() {
      this.nodes_.forEach(function(node) {
        var registrations = registrationsTable.get(node);
        for (var i = 0; i < registrations.length; i++) {
          var registration = registrations[i];
          if (registration.observer === this) {
            registration.removeListeners();
            registrations.splice(i, 1);
            break;
          }
        }
      }, this);
      this.records_ = [];
    },
    takeRecords: function() {
      var copyOfRecords = this.records_;
      this.records_ = [];
      return copyOfRecords;
    }
  };
  function MutationRecord(type, target) {
    this.type = type;
    this.target = target;
    this.addedNodes = [];
    this.removedNodes = [];
    this.previousSibling = null;
    this.nextSibling = null;
    this.attributeName = null;
    this.attributeNamespace = null;
    this.oldValue = null;
  }
  function copyMutationRecord(original) {
    var record = new MutationRecord(original.type, original.target);
    record.addedNodes = original.addedNodes.slice();
    record.removedNodes = original.removedNodes.slice();
    record.previousSibling = original.previousSibling;
    record.nextSibling = original.nextSibling;
    record.attributeName = original.attributeName;
    record.attributeNamespace = original.attributeNamespace;
    record.oldValue = original.oldValue;
    return record;
  }
  var currentRecord, recordWithOldValue;
  function getRecord(type, target) {
    return currentRecord = new MutationRecord(type, target);
  }
  function getRecordWithOldValue(oldValue) {
    if (recordWithOldValue) return recordWithOldValue;
    recordWithOldValue = copyMutationRecord(currentRecord);
    recordWithOldValue.oldValue = oldValue;
    return recordWithOldValue;
  }
  function clearRecords() {
    currentRecord = recordWithOldValue = undefined;
  }
  function recordRepresentsCurrentMutation(record) {
    return record === recordWithOldValue || record === currentRecord;
  }
  function selectRecord(lastRecord, newRecord) {
    if (lastRecord === newRecord) return lastRecord;
    if (recordWithOldValue && recordRepresentsCurrentMutation(lastRecord)) return recordWithOldValue;
    return null;
  }
  function Registration(observer, target, options) {
    this.observer = observer;
    this.target = target;
    this.options = options;
    this.transientObservedNodes = [];
  }
  Registration.prototype = {
    enqueue: function(record) {
      var records = this.observer.records_;
      var length = records.length;
      if (records.length > 0) {
        var lastRecord = records[length - 1];
        var recordToReplaceLast = selectRecord(lastRecord, record);
        if (recordToReplaceLast) {
          records[length - 1] = recordToReplaceLast;
          return;
        }
      } else {
        scheduleCallback(this.observer);
      }
      records[length] = record;
    },
    addListeners: function() {
      this.addListeners_(this.target);
    },
    addListeners_: function(node) {
      var options = this.options;
      if (options.attributes) node.addEventListener("DOMAttrModified", this, true);
      if (options.characterData) node.addEventListener("DOMCharacterDataModified", this, true);
      if (options.childList) node.addEventListener("DOMNodeInserted", this, true);
      if (options.childList || options.subtree) node.addEventListener("DOMNodeRemoved", this, true);
    },
    removeListeners: function() {
      this.removeListeners_(this.target);
    },
    removeListeners_: function(node) {
      var options = this.options;
      if (options.attributes) node.removeEventListener("DOMAttrModified", this, true);
      if (options.characterData) node.removeEventListener("DOMCharacterDataModified", this, true);
      if (options.childList) node.removeEventListener("DOMNodeInserted", this, true);
      if (options.childList || options.subtree) node.removeEventListener("DOMNodeRemoved", this, true);
    },
    addTransientObserver: function(node) {
      if (node === this.target) return;
      this.addListeners_(node);
      this.transientObservedNodes.push(node);
      var registrations = registrationsTable.get(node);
      if (!registrations) registrationsTable.set(node, registrations = []);
      registrations.push(this);
    },
    removeTransientObservers: function() {
      var transientObservedNodes = this.transientObservedNodes;
      this.transientObservedNodes = [];
      transientObservedNodes.forEach(function(node) {
        this.removeListeners_(node);
        var registrations = registrationsTable.get(node);
        for (var i = 0; i < registrations.length; i++) {
          if (registrations[i] === this) {
            registrations.splice(i, 1);
            break;
          }
        }
      }, this);
    },
    handleEvent: function(e) {
      e.stopImmediatePropagation();
      switch (e.type) {
       case "DOMAttrModified":
        var name = e.attrName;
        var namespace = e.relatedNode.namespaceURI;
        var target = e.target;
        var record = new getRecord("attributes", target);
        record.attributeName = name;
        record.attributeNamespace = namespace;
        var oldValue = e.attrChange === MutationEvent.ADDITION ? null : e.prevValue;
        forEachAncestorAndObserverEnqueueRecord(target, function(options) {
          if (!options.attributes) return;
          if (options.attributeFilter && options.attributeFilter.length && options.attributeFilter.indexOf(name) === -1 && options.attributeFilter.indexOf(namespace) === -1) {
            return;
          }
          if (options.attributeOldValue) return getRecordWithOldValue(oldValue);
          return record;
        });
        break;

       case "DOMCharacterDataModified":
        var target = e.target;
        var record = getRecord("characterData", target);
        var oldValue = e.prevValue;
        forEachAncestorAndObserverEnqueueRecord(target, function(options) {
          if (!options.characterData) return;
          if (options.characterDataOldValue) return getRecordWithOldValue(oldValue);
          return record;
        });
        break;

       case "DOMNodeRemoved":
        this.addTransientObserver(e.target);

       case "DOMNodeInserted":
        var changedNode = e.target;
        var addedNodes, removedNodes;
        if (e.type === "DOMNodeInserted") {
          addedNodes = [ changedNode ];
          removedNodes = [];
        } else {
          addedNodes = [];
          removedNodes = [ changedNode ];
        }
        var previousSibling = changedNode.previousSibling;
        var nextSibling = changedNode.nextSibling;
        var record = getRecord("childList", e.target.parentNode);
        record.addedNodes = addedNodes;
        record.removedNodes = removedNodes;
        record.previousSibling = previousSibling;
        record.nextSibling = nextSibling;
        forEachAncestorAndObserverEnqueueRecord(e.relatedNode, function(options) {
          if (!options.childList) return;
          return record;
        });
      }
      clearRecords();
    }
  };
  global.JsMutationObserver = JsMutationObserver;
  if (!global.MutationObserver) global.MutationObserver = JsMutationObserver;
})(this);

window.HTMLImports = window.HTMLImports || {
  flags: {}
};

(function(scope) {
  var IMPORT_LINK_TYPE = "import";
  var useNative = Boolean(IMPORT_LINK_TYPE in document.createElement("link"));
  var hasShadowDOMPolyfill = Boolean(window.ShadowDOMPolyfill);
  var wrap = function(node) {
    return hasShadowDOMPolyfill ? ShadowDOMPolyfill.wrapIfNeeded(node) : node;
  };
  var rootDocument = wrap(document);
  var currentScriptDescriptor = {
    get: function() {
      var script = HTMLImports.currentScript || document.currentScript || (document.readyState !== "complete" ? document.scripts[document.scripts.length - 1] : null);
      return wrap(script);
    },
    configurable: true
  };
  Object.defineProperty(document, "_currentScript", currentScriptDescriptor);
  Object.defineProperty(rootDocument, "_currentScript", currentScriptDescriptor);
  var isIE = /Trident|Edge/.test(navigator.userAgent);
  function whenReady(callback, doc) {
    doc = doc || rootDocument;
    whenDocumentReady(function() {
      watchImportsLoad(callback, doc);
    }, doc);
  }
  var requiredReadyState = isIE ? "complete" : "interactive";
  var READY_EVENT = "readystatechange";
  function isDocumentReady(doc) {
    return doc.readyState === "complete" || doc.readyState === requiredReadyState;
  }
  function whenDocumentReady(callback, doc) {
    if (!isDocumentReady(doc)) {
      var checkReady = function() {
        if (doc.readyState === "complete" || doc.readyState === requiredReadyState) {
          doc.removeEventListener(READY_EVENT, checkReady);
          whenDocumentReady(callback, doc);
        }
      };
      doc.addEventListener(READY_EVENT, checkReady);
    } else if (callback) {
      callback();
    }
  }
  function markTargetLoaded(event) {
    event.target.__loaded = true;
  }
  function watchImportsLoad(callback, doc) {
    var imports = doc.querySelectorAll("link[rel=import]");
    var parsedCount = 0, importCount = imports.length, newImports = [], errorImports = [];
    function checkDone() {
      if (parsedCount == importCount && callback) {
        callback({
          allImports: imports,
          loadedImports: newImports,
          errorImports: errorImports
        });
      }
    }
    function loadedImport(e) {
      markTargetLoaded(e);
      newImports.push(this);
      parsedCount++;
      checkDone();
    }
    function errorLoadingImport(e) {
      errorImports.push(this);
      parsedCount++;
      checkDone();
    }
    if (importCount) {
      for (var i = 0, imp; i < importCount && (imp = imports[i]); i++) {
        if (isImportLoaded(imp)) {
          parsedCount++;
          checkDone();
        } else {
          imp.addEventListener("load", loadedImport);
          imp.addEventListener("error", errorLoadingImport);
        }
      }
    } else {
      checkDone();
    }
  }
  function isImportLoaded(link) {
    return useNative ? link.__loaded || link.import && link.import.readyState !== "loading" : link.__importParsed;
  }
  if (useNative) {
    new MutationObserver(function(mxns) {
      for (var i = 0, l = mxns.length, m; i < l && (m = mxns[i]); i++) {
        if (m.addedNodes) {
          handleImports(m.addedNodes);
        }
      }
    }).observe(document.head, {
      childList: true
    });
    function handleImports(nodes) {
      for (var i = 0, l = nodes.length, n; i < l && (n = nodes[i]); i++) {
        if (isImport(n)) {
          handleImport(n);
        }
      }
    }
    function isImport(element) {
      return element.localName === "link" && element.rel === "import";
    }
    function handleImport(element) {
      var loaded = element.import;
      if (loaded) {
        markTargetLoaded({
          target: element
        });
      } else {
        element.addEventListener("load", markTargetLoaded);
        element.addEventListener("error", markTargetLoaded);
      }
    }
    (function() {
      if (document.readyState === "loading") {
        var imports = document.querySelectorAll("link[rel=import]");
        for (var i = 0, l = imports.length, imp; i < l && (imp = imports[i]); i++) {
          handleImport(imp);
        }
      }
    })();
  }
  whenReady(function(detail) {
    HTMLImports.ready = true;
    HTMLImports.readyTime = new Date().getTime();
    var evt = rootDocument.createEvent("CustomEvent");
    evt.initCustomEvent("HTMLImportsLoaded", true, true, detail);
    rootDocument.dispatchEvent(evt);
  });
  scope.IMPORT_LINK_TYPE = IMPORT_LINK_TYPE;
  scope.useNative = useNative;
  scope.rootDocument = rootDocument;
  scope.whenReady = whenReady;
  scope.isIE = isIE;
})(HTMLImports);

(function(scope) {
  var modules = [];
  var addModule = function(module) {
    modules.push(module);
  };
  var initializeModules = function() {
    modules.forEach(function(module) {
      module(scope);
    });
  };
  scope.addModule = addModule;
  scope.initializeModules = initializeModules;
})(HTMLImports);

HTMLImports.addModule(function(scope) {
  var CSS_URL_REGEXP = /(url\()([^)]*)(\))/g;
  var CSS_IMPORT_REGEXP = /(@import[\s]+(?!url\())([^;]*)(;)/g;
  var path = {
    resolveUrlsInStyle: function(style, linkUrl) {
      var doc = style.ownerDocument;
      var resolver = doc.createElement("a");
      style.textContent = this.resolveUrlsInCssText(style.textContent, linkUrl, resolver);
      return style;
    },
    resolveUrlsInCssText: function(cssText, linkUrl, urlObj) {
      var r = this.replaceUrls(cssText, urlObj, linkUrl, CSS_URL_REGEXP);
      r = this.replaceUrls(r, urlObj, linkUrl, CSS_IMPORT_REGEXP);
      return r;
    },
    replaceUrls: function(text, urlObj, linkUrl, regexp) {
      return text.replace(regexp, function(m, pre, url, post) {
        var urlPath = url.replace(/["']/g, "");
        if (linkUrl) {
          urlPath = new URL(urlPath, linkUrl).href;
        }
        urlObj.href = urlPath;
        urlPath = urlObj.href;
        return pre + "'" + urlPath + "'" + post;
      });
    }
  };
  scope.path = path;
});

HTMLImports.addModule(function(scope) {
  var xhr = {
    async: true,
    ok: function(request) {
      return request.status >= 200 && request.status < 300 || request.status === 304 || request.status === 0;
    },
    load: function(url, next, nextContext) {
      var request = new XMLHttpRequest();
      if (scope.flags.debug || scope.flags.bust) {
        url += "?" + Math.random();
      }
      request.open("GET", url, xhr.async);
      request.addEventListener("readystatechange", function(e) {
        if (request.readyState === 4) {
          var locationHeader = request.getResponseHeader("Location");
          var redirectedUrl = null;
          if (locationHeader) {
            var redirectedUrl = locationHeader.substr(0, 1) === "/" ? location.origin + locationHeader : locationHeader;
          }
          next.call(nextContext, !xhr.ok(request) && request, request.response || request.responseText, redirectedUrl);
        }
      });
      request.send();
      return request;
    },
    loadDocument: function(url, next, nextContext) {
      this.load(url, next, nextContext).responseType = "document";
    }
  };
  scope.xhr = xhr;
});

HTMLImports.addModule(function(scope) {
  var xhr = scope.xhr;
  var flags = scope.flags;
  var Loader = function(onLoad, onComplete) {
    this.cache = {};
    this.onload = onLoad;
    this.oncomplete = onComplete;
    this.inflight = 0;
    this.pending = {};
  };
  Loader.prototype = {
    addNodes: function(nodes) {
      this.inflight += nodes.length;
      for (var i = 0, l = nodes.length, n; i < l && (n = nodes[i]); i++) {
        this.require(n);
      }
      this.checkDone();
    },
    addNode: function(node) {
      this.inflight++;
      this.require(node);
      this.checkDone();
    },
    require: function(elt) {
      var url = elt.src || elt.href;
      elt.__nodeUrl = url;
      if (!this.dedupe(url, elt)) {
        this.fetch(url, elt);
      }
    },
    dedupe: function(url, elt) {
      if (this.pending[url]) {
        this.pending[url].push(elt);
        return true;
      }
      var resource;
      if (this.cache[url]) {
        this.onload(url, elt, this.cache[url]);
        this.tail();
        return true;
      }
      this.pending[url] = [ elt ];
      return false;
    },
    fetch: function(url, elt) {
      flags.load && console.log("fetch", url, elt);
      if (!url) {
        setTimeout(function() {
          this.receive(url, elt, {
            error: "href must be specified"
          }, null);
        }.bind(this), 0);
      } else if (url.match(/^data:/)) {
        var pieces = url.split(",");
        var header = pieces[0];
        var body = pieces[1];
        if (header.indexOf(";base64") > -1) {
          body = atob(body);
        } else {
          body = decodeURIComponent(body);
        }
        setTimeout(function() {
          this.receive(url, elt, null, body);
        }.bind(this), 0);
      } else {
        var receiveXhr = function(err, resource, redirectedUrl) {
          this.receive(url, elt, err, resource, redirectedUrl);
        }.bind(this);
        xhr.load(url, receiveXhr);
      }
    },
    receive: function(url, elt, err, resource, redirectedUrl) {
      this.cache[url] = resource;
      var $p = this.pending[url];
      for (var i = 0, l = $p.length, p; i < l && (p = $p[i]); i++) {
        this.onload(url, p, resource, err, redirectedUrl);
        this.tail();
      }
      this.pending[url] = null;
    },
    tail: function() {
      --this.inflight;
      this.checkDone();
    },
    checkDone: function() {
      if (!this.inflight) {
        this.oncomplete();
      }
    }
  };
  scope.Loader = Loader;
});

HTMLImports.addModule(function(scope) {
  var Observer = function(addCallback) {
    this.addCallback = addCallback;
    this.mo = new MutationObserver(this.handler.bind(this));
  };
  Observer.prototype = {
    handler: function(mutations) {
      for (var i = 0, l = mutations.length, m; i < l && (m = mutations[i]); i++) {
        if (m.type === "childList" && m.addedNodes.length) {
          this.addedNodes(m.addedNodes);
        }
      }
    },
    addedNodes: function(nodes) {
      if (this.addCallback) {
        this.addCallback(nodes);
      }
      for (var i = 0, l = nodes.length, n, loading; i < l && (n = nodes[i]); i++) {
        if (n.children && n.children.length) {
          this.addedNodes(n.children);
        }
      }
    },
    observe: function(root) {
      this.mo.observe(root, {
        childList: true,
        subtree: true
      });
    }
  };
  scope.Observer = Observer;
});

HTMLImports.addModule(function(scope) {
  var path = scope.path;
  var rootDocument = scope.rootDocument;
  var flags = scope.flags;
  var isIE = scope.isIE;
  var IMPORT_LINK_TYPE = scope.IMPORT_LINK_TYPE;
  var IMPORT_SELECTOR = "link[rel=" + IMPORT_LINK_TYPE + "]";
  var importParser = {
    documentSelectors: IMPORT_SELECTOR,
    importsSelectors: [ IMPORT_SELECTOR, "link[rel=stylesheet]", "style", "script:not([type])", 'script[type="text/javascript"]' ].join(","),
    map: {
      link: "parseLink",
      script: "parseScript",
      style: "parseStyle"
    },
    dynamicElements: [],
    parseNext: function() {
      var next = this.nextToParse();
      if (next) {
        this.parse(next);
      }
    },
    parse: function(elt) {
      if (this.isParsed(elt)) {
        flags.parse && console.log("[%s] is already parsed", elt.localName);
        return;
      }
      var fn = this[this.map[elt.localName]];
      if (fn) {
        this.markParsing(elt);
        fn.call(this, elt);
      }
    },
    parseDynamic: function(elt, quiet) {
      this.dynamicElements.push(elt);
      if (!quiet) {
        this.parseNext();
      }
    },
    markParsing: function(elt) {
      flags.parse && console.log("parsing", elt);
      this.parsingElement = elt;
    },
    markParsingComplete: function(elt) {
      elt.__importParsed = true;
      this.markDynamicParsingComplete(elt);
      if (elt.__importElement) {
        elt.__importElement.__importParsed = true;
        this.markDynamicParsingComplete(elt.__importElement);
      }
      this.parsingElement = null;
      flags.parse && console.log("completed", elt);
    },
    markDynamicParsingComplete: function(elt) {
      var i = this.dynamicElements.indexOf(elt);
      if (i >= 0) {
        this.dynamicElements.splice(i, 1);
      }
    },
    parseImport: function(elt) {
      if (HTMLImports.__importsParsingHook) {
        HTMLImports.__importsParsingHook(elt);
      }
      if (elt.import) {
        elt.import.__importParsed = true;
      }
      this.markParsingComplete(elt);
      if (elt.__resource && !elt.__error) {
        elt.dispatchEvent(new CustomEvent("load", {
          bubbles: false
        }));
      } else {
        elt.dispatchEvent(new CustomEvent("error", {
          bubbles: false
        }));
      }
      if (elt.__pending) {
        var fn;
        while (elt.__pending.length) {
          fn = elt.__pending.shift();
          if (fn) {
            fn({
              target: elt
            });
          }
        }
      }
      this.parseNext();
    },
    parseLink: function(linkElt) {
      if (nodeIsImport(linkElt)) {
        this.parseImport(linkElt);
      } else {
        linkElt.href = linkElt.href;
        this.parseGeneric(linkElt);
      }
    },
    parseStyle: function(elt) {
      var src = elt;
      elt = cloneStyle(elt);
      src.__appliedElement = elt;
      elt.__importElement = src;
      this.parseGeneric(elt);
    },
    parseGeneric: function(elt) {
      this.trackElement(elt);
      this.addElementToDocument(elt);
    },
    rootImportForElement: function(elt) {
      var n = elt;
      while (n.ownerDocument.__importLink) {
        n = n.ownerDocument.__importLink;
      }
      return n;
    },
    addElementToDocument: function(elt) {
      var port = this.rootImportForElement(elt.__importElement || elt);
      port.parentNode.insertBefore(elt, port);
    },
    trackElement: function(elt, callback) {
      var self = this;
      var done = function(e) {
        if (callback) {
          callback(e);
        }
        self.markParsingComplete(elt);
        self.parseNext();
      };
      elt.addEventListener("load", done);
      elt.addEventListener("error", done);
      if (isIE && elt.localName === "style") {
        var fakeLoad = false;
        if (elt.textContent.indexOf("@import") == -1) {
          fakeLoad = true;
        } else if (elt.sheet) {
          fakeLoad = true;
          var csr = elt.sheet.cssRules;
          var len = csr ? csr.length : 0;
          for (var i = 0, r; i < len && (r = csr[i]); i++) {
            if (r.type === CSSRule.IMPORT_RULE) {
              fakeLoad = fakeLoad && Boolean(r.styleSheet);
            }
          }
        }
        if (fakeLoad) {
          elt.dispatchEvent(new CustomEvent("load", {
            bubbles: false
          }));
        }
      }
    },
    parseScript: function(scriptElt) {
      var script = document.createElement("script");
      script.__importElement = scriptElt;
      script.src = scriptElt.src ? scriptElt.src : generateScriptDataUrl(scriptElt);
      scope.currentScript = scriptElt;
      this.trackElement(script, function(e) {
        script.parentNode.removeChild(script);
        scope.currentScript = null;
      });
      this.addElementToDocument(script);
    },
    nextToParse: function() {
      this._mayParse = [];
      return !this.parsingElement && (this.nextToParseInDoc(rootDocument) || this.nextToParseDynamic());
    },
    nextToParseInDoc: function(doc, link) {
      if (doc && this._mayParse.indexOf(doc) < 0) {
        this._mayParse.push(doc);
        var nodes = doc.querySelectorAll(this.parseSelectorsForNode(doc));
        for (var i = 0, l = nodes.length, p = 0, n; i < l && (n = nodes[i]); i++) {
          if (!this.isParsed(n)) {
            if (this.hasResource(n)) {
              return nodeIsImport(n) ? this.nextToParseInDoc(n.import, n) : n;
            } else {
              return;
            }
          }
        }
      }
      return link;
    },
    nextToParseDynamic: function() {
      return this.dynamicElements[0];
    },
    parseSelectorsForNode: function(node) {
      var doc = node.ownerDocument || node;
      return doc === rootDocument ? this.documentSelectors : this.importsSelectors;
    },
    isParsed: function(node) {
      return node.__importParsed;
    },
    needsDynamicParsing: function(elt) {
      return this.dynamicElements.indexOf(elt) >= 0;
    },
    hasResource: function(node) {
      if (nodeIsImport(node) && node.import === undefined) {
        return false;
      }
      return true;
    }
  };
  function nodeIsImport(elt) {
    return elt.localName === "link" && elt.rel === IMPORT_LINK_TYPE;
  }
  function generateScriptDataUrl(script) {
    var scriptContent = generateScriptContent(script);
    return "data:text/javascript;charset=utf-8," + encodeURIComponent(scriptContent);
  }
  function generateScriptContent(script) {
    return script.textContent + generateSourceMapHint(script);
  }
  function generateSourceMapHint(script) {
    var owner = script.ownerDocument;
    owner.__importedScripts = owner.__importedScripts || 0;
    var moniker = script.ownerDocument.baseURI;
    var num = owner.__importedScripts ? "-" + owner.__importedScripts : "";
    owner.__importedScripts++;
    return "\n//# sourceURL=" + moniker + num + ".js\n";
  }
  function cloneStyle(style) {
    var clone = style.ownerDocument.createElement("style");
    clone.textContent = style.textContent;
    path.resolveUrlsInStyle(clone);
    return clone;
  }
  scope.parser = importParser;
  scope.IMPORT_SELECTOR = IMPORT_SELECTOR;
});

HTMLImports.addModule(function(scope) {
  var flags = scope.flags;
  var IMPORT_LINK_TYPE = scope.IMPORT_LINK_TYPE;
  var IMPORT_SELECTOR = scope.IMPORT_SELECTOR;
  var rootDocument = scope.rootDocument;
  var Loader = scope.Loader;
  var Observer = scope.Observer;
  var parser = scope.parser;
  var importer = {
    documents: {},
    documentPreloadSelectors: IMPORT_SELECTOR,
    importsPreloadSelectors: [ IMPORT_SELECTOR ].join(","),
    loadNode: function(node) {
      importLoader.addNode(node);
    },
    loadSubtree: function(parent) {
      var nodes = this.marshalNodes(parent);
      importLoader.addNodes(nodes);
    },
    marshalNodes: function(parent) {
      return parent.querySelectorAll(this.loadSelectorsForNode(parent));
    },
    loadSelectorsForNode: function(node) {
      var doc = node.ownerDocument || node;
      return doc === rootDocument ? this.documentPreloadSelectors : this.importsPreloadSelectors;
    },
    loaded: function(url, elt, resource, err, redirectedUrl) {
      flags.load && console.log("loaded", url, elt);
      elt.__resource = resource;
      elt.__error = err;
      if (isImportLink(elt)) {
        var doc = this.documents[url];
        if (doc === undefined) {
          doc = err ? null : makeDocument(resource, redirectedUrl || url);
          if (doc) {
            doc.__importLink = elt;
            this.bootDocument(doc);
          }
          this.documents[url] = doc;
        }
        elt.import = doc;
      }
      parser.parseNext();
    },
    bootDocument: function(doc) {
      this.loadSubtree(doc);
      this.observer.observe(doc);
      parser.parseNext();
    },
    loadedAll: function() {
      parser.parseNext();
    }
  };
  var importLoader = new Loader(importer.loaded.bind(importer), importer.loadedAll.bind(importer));
  importer.observer = new Observer();
  function isImportLink(elt) {
    return isLinkRel(elt, IMPORT_LINK_TYPE);
  }
  function isLinkRel(elt, rel) {
    return elt.localName === "link" && elt.getAttribute("rel") === rel;
  }
  function hasBaseURIAccessor(doc) {
    return !!Object.getOwnPropertyDescriptor(doc, "baseURI");
  }
  function makeDocument(resource, url) {
    var doc = document.implementation.createHTMLDocument(IMPORT_LINK_TYPE);
    doc._URL = url;
    var base = doc.createElement("base");
    base.setAttribute("href", url);
    if (!doc.baseURI && !hasBaseURIAccessor(doc)) {
      Object.defineProperty(doc, "baseURI", {
        value: url
      });
    }
    var meta = doc.createElement("meta");
    meta.setAttribute("charset", "utf-8");
    doc.head.appendChild(meta);
    doc.head.appendChild(base);
    doc.body.innerHTML = resource;
    if (window.HTMLTemplateElement && HTMLTemplateElement.bootstrap) {
      HTMLTemplateElement.bootstrap(doc);
    }
    return doc;
  }
  if (!document.baseURI) {
    var baseURIDescriptor = {
      get: function() {
        var base = document.querySelector("base");
        return base ? base.href : window.location.href;
      },
      configurable: true
    };
    Object.defineProperty(document, "baseURI", baseURIDescriptor);
    Object.defineProperty(rootDocument, "baseURI", baseURIDescriptor);
  }
  scope.importer = importer;
  scope.importLoader = importLoader;
});

HTMLImports.addModule(function(scope) {
  var parser = scope.parser;
  var importer = scope.importer;
  var dynamic = {
    added: function(nodes) {
      var owner, parsed, loading;
      for (var i = 0, l = nodes.length, n; i < l && (n = nodes[i]); i++) {
        if (!owner) {
          owner = n.ownerDocument;
          parsed = parser.isParsed(owner);
        }
        loading = this.shouldLoadNode(n);
        if (loading) {
          importer.loadNode(n);
        }
        if (this.shouldParseNode(n) && parsed) {
          parser.parseDynamic(n, loading);
        }
      }
    },
    shouldLoadNode: function(node) {
      return node.nodeType === 1 && matches.call(node, importer.loadSelectorsForNode(node));
    },
    shouldParseNode: function(node) {
      return node.nodeType === 1 && matches.call(node, parser.parseSelectorsForNode(node));
    }
  };
  importer.observer.addCallback = dynamic.added.bind(dynamic);
  var matches = HTMLElement.prototype.matches || HTMLElement.prototype.matchesSelector || HTMLElement.prototype.webkitMatchesSelector || HTMLElement.prototype.mozMatchesSelector || HTMLElement.prototype.msMatchesSelector;
});

(function(scope) {
  var initializeModules = scope.initializeModules;
  var isIE = scope.isIE;
  if (scope.useNative) {
    return;
  }
  if (isIE && typeof window.CustomEvent !== "function") {
    window.CustomEvent = function(inType, params) {
      params = params || {};
      var e = document.createEvent("CustomEvent");
      e.initCustomEvent(inType, Boolean(params.bubbles), Boolean(params.cancelable), params.detail);
      return e;
    };
    window.CustomEvent.prototype = window.Event.prototype;
  }
  initializeModules();
  var rootDocument = scope.rootDocument;
  function bootstrap() {
    HTMLImports.importer.bootDocument(rootDocument);
  }
  if (document.readyState === "complete" || document.readyState === "interactive" && !window.attachEvent) {
    bootstrap();
  } else {
    document.addEventListener("DOMContentLoaded", bootstrap);
  }
})(HTMLImports);

window.CustomElements = window.CustomElements || {
  flags: {}
};

(function(scope) {
  var flags = scope.flags;
  var modules = [];
  var addModule = function(module) {
    modules.push(module);
  };
  var initializeModules = function() {
    modules.forEach(function(module) {
      module(scope);
    });
  };
  scope.addModule = addModule;
  scope.initializeModules = initializeModules;
  scope.hasNative = Boolean(document.registerElement);
  scope.useNative = !flags.register && scope.hasNative && !window.ShadowDOMPolyfill && (!window.HTMLImports || HTMLImports.useNative);
})(CustomElements);

CustomElements.addModule(function(scope) {
  var IMPORT_LINK_TYPE = window.HTMLImports ? HTMLImports.IMPORT_LINK_TYPE : "none";
  function forSubtree(node, cb) {
    findAllElements(node, function(e) {
      if (cb(e)) {
        return true;
      }
      forRoots(e, cb);
    });
    forRoots(node, cb);
  }
  function findAllElements(node, find, data) {
    var e = node.firstElementChild;
    if (!e) {
      e = node.firstChild;
      while (e && e.nodeType !== Node.ELEMENT_NODE) {
        e = e.nextSibling;
      }
    }
    while (e) {
      if (find(e, data) !== true) {
        findAllElements(e, find, data);
      }
      e = e.nextElementSibling;
    }
    return null;
  }
  function forRoots(node, cb) {
    var root = node.shadowRoot;
    while (root) {
      forSubtree(root, cb);
      root = root.olderShadowRoot;
    }
  }
  var processingDocuments;
  function forDocumentTree(doc, cb) {
    processingDocuments = [];
    _forDocumentTree(doc, cb);
    processingDocuments = null;
  }
  function _forDocumentTree(doc, cb) {
    doc = wrap(doc);
    if (processingDocuments.indexOf(doc) >= 0) {
      return;
    }
    processingDocuments.push(doc);
    var imports = doc.querySelectorAll("link[rel=" + IMPORT_LINK_TYPE + "]");
    for (var i = 0, l = imports.length, n; i < l && (n = imports[i]); i++) {
      if (n.import) {
        _forDocumentTree(n.import, cb);
      }
    }
    cb(doc);
  }
  scope.forDocumentTree = forDocumentTree;
  scope.forSubtree = forSubtree;
});

CustomElements.addModule(function(scope) {
  var flags = scope.flags;
  var forSubtree = scope.forSubtree;
  var forDocumentTree = scope.forDocumentTree;
  function addedNode(node) {
    return added(node) || addedSubtree(node);
  }
  function added(node) {
    if (scope.upgrade(node)) {
      return true;
    }
    attached(node);
  }
  function addedSubtree(node) {
    forSubtree(node, function(e) {
      if (added(e)) {
        return true;
      }
    });
  }
  function attachedNode(node) {
    attached(node);
    if (inDocument(node)) {
      forSubtree(node, function(e) {
        attached(e);
      });
    }
  }
  var hasPolyfillMutations = !window.MutationObserver || window.MutationObserver === window.JsMutationObserver;
  scope.hasPolyfillMutations = hasPolyfillMutations;
  var isPendingMutations = false;
  var pendingMutations = [];
  function deferMutation(fn) {
    pendingMutations.push(fn);
    if (!isPendingMutations) {
      isPendingMutations = true;
      setTimeout(takeMutations);
    }
  }
  function takeMutations() {
    isPendingMutations = false;
    var $p = pendingMutations;
    for (var i = 0, l = $p.length, p; i < l && (p = $p[i]); i++) {
      p();
    }
    pendingMutations = [];
  }
  function attached(element) {
    if (hasPolyfillMutations) {
      deferMutation(function() {
        _attached(element);
      });
    } else {
      _attached(element);
    }
  }
  function _attached(element) {
    if (element.__upgraded__ && (element.attachedCallback || element.detachedCallback)) {
      if (!element.__attached && inDocument(element)) {
        element.__attached = true;
        if (element.attachedCallback) {
          element.attachedCallback();
        }
      }
    }
  }
  function detachedNode(node) {
    detached(node);
    forSubtree(node, function(e) {
      detached(e);
    });
  }
  function detached(element) {
    if (hasPolyfillMutations) {
      deferMutation(function() {
        _detached(element);
      });
    } else {
      _detached(element);
    }
  }
  function _detached(element) {
    if (element.__upgraded__ && (element.attachedCallback || element.detachedCallback)) {
      if (element.__attached && !inDocument(element)) {
        element.__attached = false;
        if (element.detachedCallback) {
          element.detachedCallback();
        }
      }
    }
  }
  function inDocument(element) {
    var p = element;
    var doc = wrap(document);
    while (p) {
      if (p == doc) {
        return true;
      }
      p = p.parentNode || p.nodeType === Node.DOCUMENT_FRAGMENT_NODE && p.host;
    }
  }
  function watchShadow(node) {
    if (node.shadowRoot && !node.shadowRoot.__watched) {
      flags.dom && console.log("watching shadow-root for: ", node.localName);
      var root = node.shadowRoot;
      while (root) {
        observe(root);
        root = root.olderShadowRoot;
      }
    }
  }
  function handler(mutations) {
    if (flags.dom) {
      var mx = mutations[0];
      if (mx && mx.type === "childList" && mx.addedNodes) {
        if (mx.addedNodes) {
          var d = mx.addedNodes[0];
          while (d && d !== document && !d.host) {
            d = d.parentNode;
          }
          var u = d && (d.URL || d._URL || d.host && d.host.localName) || "";
          u = u.split("/?").shift().split("/").pop();
        }
      }
      console.group("mutations (%d) [%s]", mutations.length, u || "");
    }
    mutations.forEach(function(mx) {
      if (mx.type === "childList") {
        forEach(mx.addedNodes, function(n) {
          if (!n.localName) {
            return;
          }
          addedNode(n);
        });
        forEach(mx.removedNodes, function(n) {
          if (!n.localName) {
            return;
          }
          detachedNode(n);
        });
      }
    });
    flags.dom && console.groupEnd();
  }
  function takeRecords(node) {
    node = wrap(node);
    if (!node) {
      node = wrap(document);
    }
    while (node.parentNode) {
      node = node.parentNode;
    }
    var observer = node.__observer;
    if (observer) {
      handler(observer.takeRecords());
      takeMutations();
    }
  }
  var forEach = Array.prototype.forEach.call.bind(Array.prototype.forEach);
  function observe(inRoot) {
    if (inRoot.__observer) {
      return;
    }
    var observer = new MutationObserver(handler);
    observer.observe(inRoot, {
      childList: true,
      subtree: true
    });
    inRoot.__observer = observer;
  }
  function upgradeDocument(doc) {
    doc = wrap(doc);
    flags.dom && console.group("upgradeDocument: ", doc.baseURI.split("/").pop());
    addedNode(doc);
    observe(doc);
    flags.dom && console.groupEnd();
  }
  function upgradeDocumentTree(doc) {
    forDocumentTree(doc, upgradeDocument);
  }
  var originalCreateShadowRoot = Element.prototype.createShadowRoot;
  if (originalCreateShadowRoot) {
    Element.prototype.createShadowRoot = function() {
      var root = originalCreateShadowRoot.call(this);
      CustomElements.watchShadow(this);
      return root;
    };
  }
  scope.watchShadow = watchShadow;
  scope.upgradeDocumentTree = upgradeDocumentTree;
  scope.upgradeSubtree = addedSubtree;
  scope.upgradeAll = addedNode;
  scope.attachedNode = attachedNode;
  scope.takeRecords = takeRecords;
});

CustomElements.addModule(function(scope) {
  var flags = scope.flags;
  function upgrade(node) {
    if (!node.__upgraded__ && node.nodeType === Node.ELEMENT_NODE) {
      var is = node.getAttribute("is");
      var definition = scope.getRegisteredDefinition(is || node.localName);
      if (definition) {
        if (is && definition.tag == node.localName) {
          return upgradeWithDefinition(node, definition);
        } else if (!is && !definition.extends) {
          return upgradeWithDefinition(node, definition);
        }
      }
    }
  }
  function upgradeWithDefinition(element, definition) {
    flags.upgrade && console.group("upgrade:", element.localName);
    if (definition.is) {
      element.setAttribute("is", definition.is);
    }
    implementPrototype(element, definition);
    element.__upgraded__ = true;
    created(element);
    scope.attachedNode(element);
    scope.upgradeSubtree(element);
    flags.upgrade && console.groupEnd();
    return element;
  }
  function implementPrototype(element, definition) {
    if (Object.__proto__) {
      element.__proto__ = definition.prototype;
    } else {
      customMixin(element, definition.prototype, definition.native);
      element.__proto__ = definition.prototype;
    }
  }
  function customMixin(inTarget, inSrc, inNative) {
    var used = {};
    var p = inSrc;
    while (p !== inNative && p !== HTMLElement.prototype) {
      var keys = Object.getOwnPropertyNames(p);
      for (var i = 0, k; k = keys[i]; i++) {
        if (!used[k]) {
          Object.defineProperty(inTarget, k, Object.getOwnPropertyDescriptor(p, k));
          used[k] = 1;
        }
      }
      p = Object.getPrototypeOf(p);
    }
  }
  function created(element) {
    if (element.createdCallback) {
      element.createdCallback();
    }
  }
  scope.upgrade = upgrade;
  scope.upgradeWithDefinition = upgradeWithDefinition;
  scope.implementPrototype = implementPrototype;
});

CustomElements.addModule(function(scope) {
  var upgradeDocumentTree = scope.upgradeDocumentTree;
  var upgrade = scope.upgrade;
  var upgradeWithDefinition = scope.upgradeWithDefinition;
  var implementPrototype = scope.implementPrototype;
  var useNative = scope.useNative;
  function register(name, options) {
    var definition = options || {};
    if (!name) {
      throw new Error("document.registerElement: first argument `name` must not be empty");
    }
    if (name.indexOf("-") < 0) {
      throw new Error("document.registerElement: first argument ('name') must contain a dash ('-'). Argument provided was '" + String(name) + "'.");
    }
    if (isReservedTag(name)) {
      throw new Error("Failed to execute 'registerElement' on 'Document': Registration failed for type '" + String(name) + "'. The type name is invalid.");
    }
    if (getRegisteredDefinition(name)) {
      throw new Error("DuplicateDefinitionError: a type with name '" + String(name) + "' is already registered");
    }
    if (!definition.prototype) {
      definition.prototype = Object.create(HTMLElement.prototype);
    }
    definition.__name = name.toLowerCase();
    definition.lifecycle = definition.lifecycle || {};
    definition.ancestry = ancestry(definition.extends);
    resolveTagName(definition);
    resolvePrototypeChain(definition);
    overrideAttributeApi(definition.prototype);
    registerDefinition(definition.__name, definition);
    definition.ctor = generateConstructor(definition);
    definition.ctor.prototype = definition.prototype;
    definition.prototype.constructor = definition.ctor;
    if (scope.ready) {
      upgradeDocumentTree(document);
    }
    return definition.ctor;
  }
  function overrideAttributeApi(prototype) {
    if (prototype.setAttribute._polyfilled) {
      return;
    }
    var setAttribute = prototype.setAttribute;
    prototype.setAttribute = function(name, value) {
      changeAttribute.call(this, name, value, setAttribute);
    };
    var removeAttribute = prototype.removeAttribute;
    prototype.removeAttribute = function(name) {
      changeAttribute.call(this, name, null, removeAttribute);
    };
    prototype.setAttribute._polyfilled = true;
  }
  function changeAttribute(name, value, operation) {
    name = name.toLowerCase();
    var oldValue = this.getAttribute(name);
    operation.apply(this, arguments);
    var newValue = this.getAttribute(name);
    if (this.attributeChangedCallback && newValue !== oldValue) {
      this.attributeChangedCallback(name, oldValue, newValue);
    }
  }
  function isReservedTag(name) {
    for (var i = 0; i < reservedTagList.length; i++) {
      if (name === reservedTagList[i]) {
        return true;
      }
    }
  }
  var reservedTagList = [ "annotation-xml", "color-profile", "font-face", "font-face-src", "font-face-uri", "font-face-format", "font-face-name", "missing-glyph" ];
  function ancestry(extnds) {
    var extendee = getRegisteredDefinition(extnds);
    if (extendee) {
      return ancestry(extendee.extends).concat([ extendee ]);
    }
    return [];
  }
  function resolveTagName(definition) {
    var baseTag = definition.extends;
    for (var i = 0, a; a = definition.ancestry[i]; i++) {
      baseTag = a.is && a.tag;
    }
    definition.tag = baseTag || definition.__name;
    if (baseTag) {
      definition.is = definition.__name;
    }
  }
  function resolvePrototypeChain(definition) {
    if (!Object.__proto__) {
      var nativePrototype = HTMLElement.prototype;
      if (definition.is) {
        var inst = document.createElement(definition.tag);
        var expectedPrototype = Object.getPrototypeOf(inst);
        if (expectedPrototype === definition.prototype) {
          nativePrototype = expectedPrototype;
        }
      }
      var proto = definition.prototype, ancestor;
      while (proto && proto !== nativePrototype) {
        ancestor = Object.getPrototypeOf(proto);
        proto.__proto__ = ancestor;
        proto = ancestor;
      }
      definition.native = nativePrototype;
    }
  }
  function instantiate(definition) {
    return upgradeWithDefinition(domCreateElement(definition.tag), definition);
  }
  var registry = {};
  function getRegisteredDefinition(name) {
    if (name) {
      return registry[name.toLowerCase()];
    }
  }
  function registerDefinition(name, definition) {
    registry[name] = definition;
  }
  function generateConstructor(definition) {
    return function() {
      return instantiate(definition);
    };
  }
  var HTML_NAMESPACE = "http://www.w3.org/1999/xhtml";
  function createElementNS(namespace, tag, typeExtension) {
    if (namespace === HTML_NAMESPACE) {
      return createElement(tag, typeExtension);
    } else {
      return domCreateElementNS(namespace, tag);
    }
  }
  function createElement(tag, typeExtension) {
    var definition = getRegisteredDefinition(typeExtension || tag);
    if (definition) {
      if (tag == definition.tag && typeExtension == definition.is) {
        return new definition.ctor();
      }
      if (!typeExtension && !definition.is) {
        return new definition.ctor();
      }
    }
    var element;
    if (typeExtension) {
      element = createElement(tag);
      element.setAttribute("is", typeExtension);
      return element;
    }
    element = domCreateElement(tag);
    if (tag.indexOf("-") >= 0) {
      implementPrototype(element, HTMLElement);
    }
    return element;
  }
  function cloneNode(deep) {
    var n = domCloneNode.call(this, deep);
    upgrade(n);
    return n;
  }
  var domCreateElement = document.createElement.bind(document);
  var domCreateElementNS = document.createElementNS.bind(document);
  var domCloneNode = Node.prototype.cloneNode;
  var isInstance;
  if (!Object.__proto__ && !useNative) {
    isInstance = function(obj, ctor) {
      var p = obj;
      while (p) {
        if (p === ctor.prototype) {
          return true;
        }
        p = p.__proto__;
      }
      return false;
    };
  } else {
    isInstance = function(obj, base) {
      return obj instanceof base;
    };
  }
  document.registerElement = register;
  document.createElement = createElement;
  document.createElementNS = createElementNS;
  Node.prototype.cloneNode = cloneNode;
  scope.registry = registry;
  scope.instanceof = isInstance;
  scope.reservedTagList = reservedTagList;
  scope.getRegisteredDefinition = getRegisteredDefinition;
  document.register = document.registerElement;
});

(function(scope) {
  var useNative = scope.useNative;
  var initializeModules = scope.initializeModules;
  var isIE11OrOlder = /Trident/.test(navigator.userAgent);
  if (isIE11OrOlder) {
    (function() {
      var importNode = document.importNode;
      document.importNode = function() {
        var n = importNode.apply(document, arguments);
        if (n.nodeType == n.DOCUMENT_FRAGMENT_NODE) {
          var f = document.createDocumentFragment();
          f.appendChild(n);
          return f;
        } else {
          return n;
        }
      };
    })();
  }
  if (useNative) {
    var nop = function() {};
    scope.watchShadow = nop;
    scope.upgrade = nop;
    scope.upgradeAll = nop;
    scope.upgradeDocumentTree = nop;
    scope.upgradeSubtree = nop;
    scope.takeRecords = nop;
    scope.instanceof = function(obj, base) {
      return obj instanceof base;
    };
  } else {
    initializeModules();
  }
  var upgradeDocumentTree = scope.upgradeDocumentTree;
  if (!window.wrap) {
    if (window.ShadowDOMPolyfill) {
      window.wrap = ShadowDOMPolyfill.wrapIfNeeded;
      window.unwrap = ShadowDOMPolyfill.unwrapIfNeeded;
    } else {
      window.wrap = window.unwrap = function(node) {
        return node;
      };
    }
  }
  function bootstrap() {
    upgradeDocumentTree(wrap(document));
    if (window.HTMLImports) {
      HTMLImports.__importsParsingHook = function(elt) {
        upgradeDocumentTree(wrap(elt.import));
      };
    }
    CustomElements.ready = true;
    setTimeout(function() {
      CustomElements.readyTime = Date.now();
      if (window.HTMLImports) {
        CustomElements.elapsed = CustomElements.readyTime - HTMLImports.readyTime;
      }
      document.dispatchEvent(new CustomEvent("WebComponentsReady", {
        bubbles: true
      }));
    });
  }
  if (isIE11OrOlder && typeof window.CustomEvent !== "function") {
    window.CustomEvent = function(inType, params) {
      params = params || {};
      var e = document.createEvent("CustomEvent");
      e.initCustomEvent(inType, Boolean(params.bubbles), Boolean(params.cancelable), params.detail);
      return e;
    };
    window.CustomEvent.prototype = window.Event.prototype;
  }
  if (document.readyState === "complete" || scope.flags.eager) {
    bootstrap();
  } else if (document.readyState === "interactive" && !window.attachEvent && (!window.HTMLImports || window.HTMLImports.ready)) {
    bootstrap();
  } else {
    var loadEvent = window.HTMLImports && !HTMLImports.ready ? "HTMLImportsLoaded" : "DOMContentLoaded";
    window.addEventListener(loadEvent, bootstrap);
  }
})(window.CustomElements);

if (typeof HTMLTemplateElement === "undefined") {
  (function() {
    var TEMPLATE_TAG = "template";
    HTMLTemplateElement = function() {};
    HTMLTemplateElement.prototype = Object.create(HTMLElement.prototype);
    HTMLTemplateElement.decorate = function(template) {
      if (!template.content) {
        template.content = template.ownerDocument.createDocumentFragment();
        var child;
        while (child = template.firstChild) {
          template.content.appendChild(child);
        }
      }
    };
    HTMLTemplateElement.bootstrap = function(doc) {
      var templates = doc.querySelectorAll(TEMPLATE_TAG);
      for (var i = 0, l = templates.length, t; i < l && (t = templates[i]); i++) {
        HTMLTemplateElement.decorate(t);
      }
    };
    addEventListener("DOMContentLoaded", function() {
      HTMLTemplateElement.bootstrap(document);
    });
  })();
}

(function(scope) {
  var style = document.createElement("style");
  style.textContent = "" + "body {" + "transition: opacity ease-in 0.2s;" + " } \n" + "body[unresolved] {" + "opacity: 0; display: block; overflow: hidden; position: relative;" + " } \n";
  var head = document.querySelector("head");
  head.insertBefore(style, head.firstChild);
})(window.WebComponents);
},{}],26:[function(require,module,exports){
// FRONT-END APP //

// polyfilling just in case
require('webcomponents-lite');
require('openmusic-transport').register('openmusic-transport');

var mainElement;

var toys = [
	{
		audioConstructor: require('openmusic-theremin'),
		webComponent: require('openmusic-theremin-ui'),
		tag: 'openmusic-theremin-ui',
		name: 'Theremin'
	},
	{
		audioConstructor: require('openmusic-drum-machine'),
		webComponent: require('openmusic-drum-machine-ui'),
		tag: 'openmusic-drum-machine-ui',
		name: 'Drum Machine',
		transport: true
	}
];


window.addEventListener('load', init);

// this is mega teeeeemporaryyy

function init() {
	
	mainElement = document.querySelector('main');

	toys.forEach(function(toy) {
		var button = document.createElement('button');
		button.innerHTML = toy.name;
		button.addEventListener('click', function() {
			useToy(toy.name, toy.audioConstructor, toy.tag, toy.transport);
		});
		toy.webComponent.register(toy.tag);
		mainElement.appendChild(button);
	});

}

function useToy(name, audioConstructor, tagName, withTransport) {

	var ac = new AudioContext();
	var toy = audioConstructor(ac);
	var limiter = ac.createDynamicsCompressor();

	limiter.connect(ac.destination);
	toy.connect(limiter);

	mainElement.innerHTML = '<h1>' + name + '</h1>';
	var toyUI = document.createElement(tagName);

	// TODO perhaps change it so all instruments have a ready() method instead
	if(toy.ready !== undefined) {
		toy.ready().then(function() {
			toyUI.attachTo(toy);
		});
	} else {
		toyUI.attachTo(toy);
	}

	if(withTransport) {
		var transport = document.createElement('openmusic-transport');
		mainElement.appendChild(transport);

		transport.addEventListener('play', function() {
			toy.start();
		});

		transport.addEventListener('stop', function() {
			toy.stop();
		});

		transport.addEventListener('bpm', function(ev) {
			toy.bpm = ev.detail.value;
		});
	}
	
	mainElement.appendChild(toyUI);

}

},{"openmusic-drum-machine":6,"openmusic-drum-machine-ui":5,"openmusic-theremin":17,"openmusic-theremin-ui":11,"openmusic-transport":21,"webcomponents-lite":25}]},{},[26])