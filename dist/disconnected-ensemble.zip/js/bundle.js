(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
/*jshint esnext:true*/
/*exported BinaryUtils*/
'use strict';

module.exports = window.BinaryUtils = (function() {

var BinaryUtils = {
  stringToArrayBuffer: function(string) {
    var length = (string || '').length;
    var arrayBuffer = new ArrayBuffer(length);
    var uint8Array = new Uint8Array(arrayBuffer);
    for (var i = 0; i < length; i++) {
      uint8Array[i] = string.charCodeAt(i);
    }

    return arrayBuffer;
  },

  arrayBufferToString: function(arrayBuffer) {
    var results = [];
    var uint8Array = new Uint8Array(arrayBuffer);

    for (var i = 0, length = uint8Array.length; i < length; i += 200000) {
      results.push(String.fromCharCode.apply(null, uint8Array.subarray(i, i + 200000)));
    }

    return results.join('');
  },

  blobToArrayBuffer: function(blob, callback) {
    var fileReader = new FileReader();
    fileReader.onload = function() {
      if (typeof callback === 'function') {
        callback(fileReader.result);
      }
    };
    fileReader.readAsArrayBuffer(blob);

    return fileReader.result;
  },

  mergeArrayBuffers: function(arrayBuffers, callback) {
    return BinaryUtils.blobToArrayBuffer(new Blob(arrayBuffers), callback);
  }
};

return BinaryUtils;

})();

},{}],2:[function(require,module,exports){
/*jshint esnext:true*/
/*exported EventTarget*/
'use strict';

module.exports = window.EventTarget = (function() {

function EventTarget(object) {
  if (typeof object !== 'object') {
    return;
  }

  for (var property in object) {
    this[property] = object[property];
  }
}

EventTarget.prototype.constructor = EventTarget;

EventTarget.prototype.dispatchEvent = function(name, data) {
  var events    = this._events || {};
  var listeners = events[name] || [];
  listeners.forEach((listener) => {
    listener.call(this, data);
  });
};

EventTarget.prototype.addEventListener = function(name, listener) {
  var events    = this._events = this._events || {};
  var listeners = events[name] = events[name] || [];
  if (listeners.find(fn => fn === listener)) {
    return;
  }

  listeners.push(listener);
};

EventTarget.prototype.removeEventListener = function(name, listener) {
  var events    = this._events || {};
  var listeners = events[name] || [];
  for (var i = listeners.length - 1; i >= 0; i--) {
    if (listeners[i] === listener) {
      listeners.splice(i, 1);
      return;
    }
  }
};

return EventTarget;

})();

},{}],3:[function(require,module,exports){
/*jshint esnext:true*/
/*exported HTTPRequest*/
'use strict';

module.exports = window.HTTPRequest = (function() {

var EventTarget = require('./event-target');
var BinaryUtils = require('./binary-utils');

const CRLF = '\r\n';

function HTTPRequest(socket) {
  var parts = [];
  var receivedLength = 0;

  var checkRequestComplete = () => {
    var contentLength = parseInt(this.headers['Content-Length'], 10);
    if (isNaN(contentLength)) {
      this.complete = true;
      this.dispatchEvent('complete', this);
      return;
    }

    if (receivedLength < contentLength) {
      return;
    }

    BinaryUtils.mergeArrayBuffers(parts, (data) => {
      this.body = parseBody(this.headers['Content-Type'], data);
      this.complete = true;
      this.dispatchEvent('complete', this);
    });

    socket.ondata = null;
  };

  socket.ondata = (event) => {
    var data = event.data;

    if (parts.length > 0) {
      parts.push(data);
      receivedLength += data.byteLength;
      checkRequestComplete();
      return;
    }

    var firstPart = parseHeader(this, data);
    if (this.invalid) {
      this.dispatchEvent('error', this);

      socket.close();
      socket.ondata = null;
      return;
    }

    if (firstPart) {
      parts.push(firstPart);
      receivedLength += firstPart.byteLength;
    }

    checkRequestComplete();
  };
}

HTTPRequest.prototype = new EventTarget();

HTTPRequest.prototype.constructor = HTTPRequest;

function parseHeader(request, data) {
  if (!data) {
    request.invalid = true;
    return null;
  }

  data = BinaryUtils.arrayBufferToString(data);

  var requestParts = data.split(CRLF + CRLF);

  var header = requestParts.shift();
  var body   = requestParts.join(CRLF + CRLF);

  var headerLines = header.split(CRLF);
  var requestLine = headerLines.shift().split(' ');
  
  var method  = requestLine[0];
  var uri     = requestLine[1];
  var version = requestLine[2];

  if (version !== HTTPServer.HTTP_VERSION) {
    request.invalid = true;
    return null;
  }

  var uriParts = uri.split('?');
  
  var path   = uriParts.shift();
  var params = parseURLEncodedString(uriParts.join('?'));

  var headers = {};
  headerLines.forEach((headerLine) => {
    var parts = headerLine.split(': ');
    if (parts.length !== 2) {
      return;
    }

    var name  = parts[0];
    var value = parts[1];

    headers[name] = value;
  });

  request.method  = method;
  request.path    = path;
  request.params  = params;
  request.headers = headers;

  if (headers['Content-Length']) {
    // request.body = parseBody(headers['Content-Type'], body);
    return BinaryUtils.stringToArrayBuffer(body);
  }

  return null;
}

function setOrAppendValue(object, name, value) {
  var existingValue = object[name];
  if (existingValue === undefined) {
    object[name] = value;
  } else {
    if (Array.isArray(existingValue)) {
      existingValue.push(value);
    } else {
      object[name] = [existingValue, value];
    }
  }
}

function parseURLEncodedString(string) {
  var values = {};

  string.split('&').forEach((pair) => {
    if (!pair) {
      return;
    }

    var parts = decodeURIComponent(pair).split('=');

    var name  = parts.shift();
    var value = parts.join('=');

    setOrAppendValue(values, name, value);
  });

  return values;
}

function parseMultipartFormDataString(string, boundary) {
  var values = {};

  string.split('--' + boundary).forEach((data) => {
    data = data.replace(/^\r\n/, '').replace(/\r\n$/, '');

    if (!data || data === '--') {
      return;
    }

    var parts = data.split(CRLF + CRLF);
    
    var header = parts.shift();
    var value  = {
      headers: {},
      metadata: {},
      value: parts.join(CRLF + CRLF)
    };

    var name;

    var headers = header.split(CRLF);
    headers.forEach((header) => {
      var headerParams = header.split(';');
      var headerParts = headerParams.shift().split(': ');

      var headerName  = headerParts[0];
      var headerValue = headerParts[1];

      if (headerName  !== 'Content-Disposition' ||
          headerValue !== 'form-data') {
        value.headers[headerName] = headerValue;
        return;
      }

      headerParams.forEach((param) => {
        var paramParts = param.trim().split('=');

        var paramName  = paramParts[0];
        var paramValue = paramParts[1];

        paramValue = paramValue.replace(/\"(.*?)\"/, '$1') || paramValue;

        if (paramName === 'name') {
          name = paramValue;
        }

        else {
          value.metadata[paramName] = paramValue;
        }
      });
    });

    if (name) {
      setOrAppendValue(values, name, value);
    }
  });

  return values;
}

function parseBody(contentType, data) {
  contentType = contentType || 'text/plain';

  var contentTypeParams = contentType.replace(/\s/g, '').split(';');
  var mimeType = contentTypeParams.shift();

  var body = BinaryUtils.arrayBufferToString(data);

  var result;

  try {
    switch (mimeType) {
      case 'application/x-www-form-urlencoded':
        result = parseURLEncodedString(body);
        break;
      case 'multipart/form-data':
        contentTypeParams.forEach((contentTypeParam) => {
          var parts = contentTypeParam.split('=');

          var name  = parts[0];
          var value = parts[1];

          if (name === 'boundary') {
            result = parseMultipartFormDataString(body, value);
          }
        });
        break;
      case 'application/json':
        result = JSON.parse(body);
        break;
      case 'application/xml':
        result = new DOMParser().parseFromString(body, 'text/xml');
        break;
      default:
        break;
    }
  } catch (exception) {
    console.log('Unable to parse HTTP request body with Content-Type: ' + contentType);
  }

  return result || body;
}

return HTTPRequest;

})();

},{"./binary-utils":1,"./event-target":2}],4:[function(require,module,exports){
/*jshint esnext:true*/
/*exported HTTPResponse*/
'use strict';

module.exports = window.HTTPResponse = (function() {

var EventTarget = require('./event-target');
var BinaryUtils = require('./binary-utils');
var HTTPStatus  = require('./http-status');

const CRLF = '\r\n';
const BUFFER_SIZE = 64 * 1024;

function HTTPResponse(socket, timeout) {
  this.socket  = socket;
  this.timeout = timeout;

  this.headers = {};
  this.headers['Content-Type'] = 'text/html';
  this.headers['Connection']   = 'close';

  if (this.timeout) {
    this.timeoutHandler = setTimeout(() => {
      this.send(null, 500);
    }, this.timeout);
  }
}

HTTPResponse.prototype = new EventTarget();

HTTPResponse.prototype.constructor = HTTPResponse;

HTTPResponse.prototype.send = function(body, status) {
  return createResponse(body, status, this.headers, (response) => {
    var offset = 0;
    var remaining = response.byteLength;

    var sendNextPart = () => {
      var length = Math.min(remaining, BUFFER_SIZE);

      var bufferFull = this.socket.send(response, offset, length);

      offset += length;
      remaining -= length;

      if (remaining > 0) {
        if (!bufferFull) {
          sendNextPart();
        }
      }
      
      else {
        clearTimeout(this.timeoutHandler);

        this.socket.close();
        this.dispatchEvent('complete');
      }
    };

    this.socket.ondrain = sendNextPart;

    sendNextPart();
  });
};

HTTPResponse.prototype.sendFile = function(fileOrPath, status) {
  if (fileOrPath instanceof File) {
    BinaryUtils.blobToArrayBuffer(fileOrPath, (arrayBuffer) => {
      this.send(arrayBuffer, status);
    });

    return;
  }

  var xhr = new XMLHttpRequest();
  xhr.open('GET', fileOrPath, true);
  xhr.responseType = 'arraybuffer';
  xhr.onload = () => {
    this.send(xhr.response, status);
  };

  xhr.send(null);
};

function createResponseHeader(status, headers) {
  var header = HTTPStatus.getStatusLine(status);

  for (var name in headers) {
    header += name + ': ' + headers[name] + CRLF;
  }

  return header;
}

function createResponse(body, status, headers, callback) {
  body    = body    || '';
  status  = status  || 200;
  headers = headers || {};

  headers['Content-Length'] = body.length || body.byteLength;

  var response = new Blob([
    createResponseHeader(status, headers),
    CRLF,
    body
  ]);

  return BinaryUtils.blobToArrayBuffer(response, callback);
}

return HTTPResponse;

})();

},{"./binary-utils":1,"./event-target":2,"./http-status":6}],5:[function(require,module,exports){
/*jshint esnext:true*/
/*exported HTTPServer*/
'use strict';

module.exports = window.HTTPServer = (function() {

var EventTarget  = require('./event-target');
var HTTPRequest  = require('./http-request');
var HTTPResponse = require('./http-response');
var IPUtils      = require('./ip-utils');

const DEFAULT_PORT = 8080;
const DEFAULT_TIMEOUT = 20000;

const CRLF = '\r\n';

function HTTPServer(port, options) {
  this.port = port || DEFAULT_PORT;

  options = options || {};
  for (var option in options) {
    this[option] = options[option];
  }

  this.running = false;
}

HTTPServer.HTTP_VERSION = 'HTTP/1.1';

HTTPServer.prototype = new EventTarget();

HTTPServer.prototype.constructor = HTTPServer;

HTTPServer.prototype.timeout = DEFAULT_TIMEOUT;

HTTPServer.prototype.start = function() {
  if (this.running) {
    return;
  }

  console.log('Starting HTTP server on port ' + this.port);

  var socket = navigator.mozTCPSocket.listen(this.port, {
    binaryType: 'arraybuffer'
  });

  socket.onconnect = (connectEvent) => {
    var request = new HTTPRequest(connectEvent);
    
    request.addEventListener('complete', () => {
      var response = new HTTPResponse(connectEvent, this.timeout);

      this.dispatchEvent('request', {
        request: request,
        response: response
      });
    });

    request.addEventListener('error', () => {
      console.warn('Invalid request received');
    });
  };

  this.socket = socket;
  this.running = true;
};

HTTPServer.prototype.stop = function() {
  if (!this.running) {
    return;
  }

  console.log('Shutting down HTTP server on port ' + this.port);

  this.socket.close();

  this.running = false;
};

return HTTPServer;

})();

},{"./event-target":2,"./http-request":3,"./http-response":4,"./ip-utils":7}],6:[function(require,module,exports){
/*jshint esnext:true*/
/*exported HTTPStatus*/
'use strict';

module.exports = window.HTTPStatus = (function() {

const CRLF = '\r\n';

var HTTPStatus = {};

HTTPStatus.STATUS_CODES = {
  100: 'Continue',
  101: 'Switching Protocols',
  102: 'Processing',
  200: 'OK',
  201: 'Created',
  202: 'Accepted',
  203: 'Non Authoritative Information',
  204: 'No Content',
  205: 'Reset Content',
  206: 'Partial Content',
  207: 'Multi-Status',
  300: 'Mutliple Choices',
  301: 'Moved Permanently',
  302: 'Moved Temporarily',
  303: 'See Other',
  304: 'Not Modified',
  305: 'Use Proxy',
  307: 'Temporary Redirect',
  400: 'Bad Request',
  401: 'Unauthorized',
  402: 'Payment Required',
  403: 'Forbidden',
  404: 'Not Found',
  405: 'Method Not Allowed',
  406: 'Not Acceptable',
  407: 'Proxy Authentication Required',
  408: 'Request Timeout',
  409: 'Conflict',
  410: 'Gone',
  411: 'Length Required',
  412: 'Precondition Failed',
  413: 'Request Entity Too Large',
  414: 'Request-URI Too Long',
  415: 'Unsupported Media Type',
  416: 'Requested Range Not Satisfiable',
  417: 'Expectation Failed',
  419: 'Insufficient Space on Resource',
  420: 'Method Failure',
  422: 'Unprocessable Entity',
  423: 'Locked',
  424: 'Failed Dependency',
  500: 'Server Error',
  501: 'Not Implemented',
  502: 'Bad Gateway',
  503: 'Service Unavailable',
  504: 'Gateway Timeout',
  505: 'HTTP Version Not Supported',
  507: 'Insufficient Storage'
};

HTTPStatus.getStatusLine = function(status) {
  var reason = HTTPStatus.STATUS_CODES[status] || 'Unknown';

  return [HTTPServer.HTTP_VERSION, status, reason].join(' ') + CRLF;
};

return HTTPStatus;

})();

},{}],7:[function(require,module,exports){
/*jshint esnext:true*/
/*exported IPUtils*/
'use strict';

module.exports = window.IPUtils = (function() {

const CRLF = '\r\n';

var IPUtils = {
  getAddresses: function(callback) {
    if (typeof callback !== 'function') {
      console.warn('No callback provided');
      return;
    }

    var addresses = {
      '0.0.0.0': true
    };

    var rtc = new mozRTCPeerConnection({ iceServers: [] });
    rtc.createDataChannel('', { reliable: false });

    rtc.onicecandidate = function(evt) {
      if (evt.candidate) {
        parseSDP('a=' + evt.candidate.candidate);
      }
    };

    rtc.createOffer((description) => {
      parseSDP(description.sdp);
      rtc.setLocalDescription(description, noop, noop);
    }, (error) => {
      console.warn('Unable to create offer', error);
    });

    function addAddress(address) {
      if (addresses[address]) {
        return;
      }

      addresses[address] = true;
      callback(address);
    }

    function parseSDP(sdp) {
      sdp.split(CRLF).forEach((line) => {
        var parts = line.split(' ');

        if (line.indexOf('a=candidate') !== -1) {
          if (parts[7] === 'host') {
            addAddress(parts[4]);
          }
        }

        else if (line.indexOf('c=') !== -1) {
          addAddress(parts[2]);
        }
      });
    }
  }
};

function noop() {}

return IPUtils;

})();

},{}],8:[function(require,module,exports){
(function(define){'use strict';define(function(require,exports,module){

/**
 * Pointer event abstraction to make
 * it work for touch and mouse.
 *
 * @type {Object}
 */
var pointer = [
  { down: 'touchstart', up: 'touchend', move: 'touchmove' },
  { down: 'mousedown', up: 'mouseup', move: 'mousemove' }
]['ontouchstart' in window ? 0 : 1];

/**
 * Simple logger
 *
 * @type {Function}
 */
var debug = 0 ? console.log.bind(console) : function() {};

/**
 * Exports
 */

module.exports = Drag;

/**
 * Drag creates a draggable 'handle' element,
 * constrained within a 'container' element.
 *
 * Drag instances dispatch useful events and provides
 * methods to support common draggable UI use-cases,
 * like snapping.
 *
 * In Gaia we use `Drag` for our switch components.
 *
 * Example:
 *
 *   var container = document.getElementById(#my-container);
 *   var handle = document.getElementById(#my-handle);
 *
 *   new Drag({
 *     container: {
 *       el: container,
 *       width: container.clientWidth,
 *       height: container.clientHeight
 *     },
 *     handle: {
 *       el: handle,
 *       width: handle.clientWidth,
 *       height: handle.clientHeight,
 *       x: 0,
 *       y: 0
 *     }
 *   });
 *
 * @param {Object} config
 */
function Drag(config) {
  debug('init', config);
  this.config(config);
  this.dragging = false;
  this.setupEvents();
}

/**
 * Update the configuration.
 *
 * @param  {Object} config
 */
Drag.prototype.config = function(config) {
  this.slideDuration = config.slideDuration || 140;
  this.container = config.container;
  this.handle = config.handle;
  this.max = {
    x: this.container.width - this.handle.width,
    y: this.container.height - this.handle.height
  };
};

/**
 * Preserve context and bind initial
 * 'down' event listener.
 *
 * @private
 */
Drag.prototype.setupEvents = function() {
  debug('setup events', pointer);
  this.onPointerStart = this.onPointerStart.bind(this);
  this.onPointerMove = this.onPointerMove.bind(this);
  this.onPointerEnd = this.onPointerEnd.bind(this);
  this.handle.el.addEventListener(pointer.down, this.onPointerStart);
};

/**
 * Adds events listeners and updates
 * the `dragging` flag.
 *
 * @param  {Event} e
 * @private
 */
Drag.prototype.onPointerStart = function(e) {
  debug('pointer start', e);
  this.point = getPoint(e);
  addEventListener(pointer.move, this.onPointerMove);
  addEventListener(pointer.up, this.onPointerEnd);
  clearTimeout(this.timeout);
  this.timeout = setTimeout(() => this.dragging = true, 200);
};

/**
 * Removes events listeners and updates
 * the `dragging` flag.
 *
 * @param  {Event} e
 * @private
 */
Drag.prototype.onPointerEnd = function(e) {
  debug('pointer end', e);
  clearTimeout(this.timeout);
  this.timeout = setTimeout(() => this.dragging = false);
  removeEventListener(pointer.move, this.onPointerMove);
  removeEventListener(pointer.up, this.onPointerEnd);
  this.dispatch('ended', e);
};

/**
 * Moves the handle when the pointer moves.
 *
 * @param  {Event} e
 * @private
 */
Drag.prototype.onPointerMove = function(e) {
  debug('pointer move', e);
  e.preventDefault();
  var previous = this.point;
  this.point = getPoint(e);
  this.setDuration(0);
  this.translateDelta(
    this.point.pageX - previous.pageX,
    this.point.pageY - previous.pageY
  );
};

/**
 * Translate the handle by given delta.
 *
 * @param  {Number} deltaX
 * @param  {Number} deltaY
 * @public
 */
Drag.prototype.translateDelta = function(deltaX, deltaY) {
  debug('translate by', deltaX, deltaY);
  this.translate(
    this.handle.x + deltaX,
    this.handle.y + deltaY
  );
};

/**
 * Translate the handle to given coordinates.
 *
 * Numbers are interpreted as pixels and
 * Strings as ratio/percentage.
 *
 * Example:
 *
 *   drag.translate(50, 0); // translate(50px, 0px);
 *   drag.translate('0.5', 0); // translate(<halfway>, 0px);
 *
 * @param  {Number|String} x
 * @param  {Number|String} y
 * @public
 */
Drag.prototype.translate = function(x, y) {
  debug('translate', x, y);
  var position = this.clamp(this.normalize(x, y));
  var translate = 'translate(' + position.x + 'px,' + position.y + 'px)';
  var ratio = {
    x: (position.x / this.max.x) || 0,
    y: (position.y / this.max.y) || 0
  };

  // Set the transform to move the handle
  this.handle.el.style.transform = translate;

  // Update the handle position reference
  this.handle.x = position.x;
  this.handle.y = position.y;

  // dispatch event with useful data
  this.dispatch('translate', this.handle);
};

/**
 * Transition the handle to given coordinates.
 *
 * Example:
 *
 *   drag.transition(50, 0); // 50px, 0px;
 *   drag.transition('0.5', 0); // <halfway>, 0px
 *
 * @param  {Number|String} x
 * @param  {Number|String} y
 * @public
 */
Drag.prototype.transition = function(x, y) {
  debug('transition', x, y);
  var pos = this.clamp(this.normalize(x, y));
  var duration = this.getDuration(this.handle, pos);
  this.setDuration(duration);
  this.translate(pos.x, pos.y);
};

/**
 * Normalize x/y parametes to pixel values.
 *
 * Strings are interpreted as a ratio of
 * max x/y position.
 *
 * @param  {Number|String} x
 * @param  {Number|String} y
 * @return {Object} {x,y}
 * @private
 */
Drag.prototype.normalize = function(x, y) {
  return {
    x: typeof x == 'string' ? (Number(x) * this.max.x) : x,
    y: typeof y == 'string' ? (Number(y) * this.max.y) : y
  }
};

/**
 * Snap the handle to nearest edge(s).
 *
 * @public
 */
Drag.prototype.snap = function() {
  debug('snap');
  var edges = this.getClosestEdges();
  this.transition(edges.x, edges.y)
  this.dispatch('snapped', edges);
};

/**
 * Clamp coordinates between the
 * allowed min/max values.
 *
 * @param  {Object} pos {x,y}
 * @return {Object} {x,y}
 */
Drag.prototype.clamp = function(pos) {
  return {
    x: Math.max(0, Math.min(this.max.x, pos.x)),
    y: Math.max(0, Math.min(this.max.y, pos.y)),
  };
};

/**
 * Get the ideal transition duration based
 * on how much distance has to be tranvelled.
 *
 * When snapping, we don't want to use the same
 * duration for short distances as long.
 *
 * @param  {Object} from {x,y}
 * @param  {Object} to   {x,y}
 * @return {Number}
 */
Drag.prototype.getDuration = function(from, to) {
  var distanceX = Math.abs(from.x - to.x);
  var distanceY = Math.abs(from.y - to.y);
  var distance = Math.max(distanceX, distanceY);
  var axis = distanceY > distanceX ? 'y' : 'x';
  var ratio = distance / this.max[axis];
  return this.slideDuration * ratio;
};

/**
 * Set the handle's transition duration.
 *
 * @param {Number} ms
 */
Drag.prototype.setDuration = function(ms) {
  this.handle.el.style.transitionDuration = ms + 'ms';
}

/**
 * Get the closest x and y edges.
 *
 * The strings returns represent
 * ratio/percentage of axis' overall range.
 *
 * @return {Object} {x,y}
 */
Drag.prototype.getClosestEdges = function() {
  return {
    x: this.handle.x <= (this.max.x / 2) ?  '0' : '1',
    y: this.handle.y <= (this.max.y / 2) ?  '0' : '1'
  };
};

/**
 * Dispatch a DOM event on the container
 * element. All events are namespaced ('drag').
 *
 * @param  {String} name
 * @param  {*} detail
 */
Drag.prototype.dispatch = function(name, detail) {
  var e = new CustomEvent('drag' + name, { bubble: false, detail: detail })
  this.container.el.dispatchEvent(e);
  debug('dispatched', e);
};

/**
 * Add an event listener.
 *
 * @param  {String}   name
 * @param  {Function} fn
 */
Drag.prototype.on = function(name, fn) {
  this.container.el.addEventListener('drag' + name, fn);
}

/**
 * Remove and event listener.
 *
 * @param  {String}   name
 * @param  {Function} fn
 */
Drag.prototype.off = function(name, fn) {
  this.container.el.removeEventListener('drag' + name, fn);
}

/**
 * Utils
 */

function getPoint(e) {
  return ~e.type.indexOf('mouse') ? e : e.touches[0];
}

});})((function(n,w){'use strict';return typeof define=='function'&&define.amd?
define:typeof module=='object'?function(c){c(require,exports,module);}:
function(c){var m={exports:{}},r=function(n){return w[n];};
w[n]=c(r,m.exports,m)||m.exports;};})('drag',this));
},{}],9:[function(require,module,exports){
/* globals define */
;(function(define){'use strict';define(function(require,exports,module){
/**
 * Locals
 */
var textContent = Object.getOwnPropertyDescriptor(Node.prototype,
    'textContent');
var innerHTML = Object.getOwnPropertyDescriptor(Element.prototype, 'innerHTML');
var removeAttribute = Element.prototype.removeAttribute;
var setAttribute = Element.prototype.setAttribute;
var noop  = function() {};

/**
 * Register a new component.
 *
 * @param  {String} name
 * @param  {Object} props
 * @return {constructor}
 * @public
 */
exports.register = function(name, props) {
  var baseProto = getBaseProto(props.extends);
  var template = props.template || baseProto.templateString;

  // Components are extensible by default but can be declared
  // as non extensible as an optimization to avoid
  // storing the template strings
  var extensible = props.extensible = props.hasOwnProperty('extensible')?
    props.extensible : true;

  // Clean up
  delete props.extends;

  // Pull out CSS that needs to be in the light-dom
  if (template) {
    // Stores the string to be reprocessed when
    // a new component extends this one
    if (extensible && props.template) {
      props.templateString = props.template;
    }

    var output = processCss(template, name);

    props.template = document.createElement('template');
    props.template.innerHTML = output.template;
    props.lightCss = output.lightCss;

    props.globalCss = props.globalCss || '';
    props.globalCss += output.globalCss;
  }

  // Inject global CSS into the document,
  // and delete as no longer needed
  injectGlobalCss(props.globalCss);
  delete props.globalCss;

  // Merge base getter/setter attributes with the user's,
  // then define the property descriptors on the prototype.
  var descriptors = mixin(props.attrs || {}, base.descriptors);

  // Store the orginal descriptors somewhere
  // a little more private and delete the original
  props._attrs = props.attrs;
  delete props.attrs;

  // Create the prototype, extended from base and
  // define the descriptors directly on the prototype
  var proto = createProto(baseProto, props);
  Object.defineProperties(proto, descriptors);

  // Register the custom-element and return the constructor
  try {
    return document.registerElement(name, { prototype: proto });
  } catch (e) {
    if (e.name !== 'NotSupportedError') {
      throw e;
    }
  }
};

var base = {
  properties: {
    GaiaComponent: true,
    attributeChanged: noop,
    attached: noop,
    detached: noop,
    created: noop,

    createdCallback: function() {
      if (this.rtl) { addDirObserver(); }
      injectLightCss(this);
      this.created();
    },

    /**
     * It is very common to want to keep object
     * properties in-sync with attributes,
     * for example:
     *
     *   el.value = 'foo';
     *   el.setAttribute('value', 'foo');
     *
     * So we support an object on the prototype
     * named 'attrs' to provide a consistent
     * way for component authors to define
     * these properties. When an attribute
     * changes we keep the attr[name]
     * up-to-date.
     *
     * @param  {String} name
     * @param  {String||null} from
     * @param  {String||null} to
     */
    attributeChangedCallback: function(name, from, to) {
      var prop = toCamelCase(name);
      if (this._attrs && this._attrs[prop]) { this[prop] = to; }
      this.attributeChanged(name, from, to);
    },

    attachedCallback: function() { this.attached(); },
    detachedCallback: function() { this.detached(); },

    /**
     * A convenient method for setting up
     * a shadow-root using the defined template.
     *
     * @return {ShadowRoot}
     */
    setupShadowRoot: function() {
      if (!this.template) { return; }
      var node = document.importNode(this.template.content, true);
      this.createShadowRoot().appendChild(node);
      return this.shadowRoot;
    },

    /**
     * Sets an attribute internally
     * and externally. This is so that
     * we can style internal shadow-dom
     * content.
     *
     * @param {String} name
     * @param {String} value
     */
    setAttr: function(name, value) {
      var internal = this.shadowRoot.firstElementChild;
      setAttribute.call(internal, name, value);
      setAttribute.call(this, name, value);
    },

    /**
     * Removes an attribute internally
     * and externally. This is so that
     * we can style internal shadow-dom
     * content.
     *
     * @param {String} name
     * @param {String} value
     */
    removeAttr: function(name) {
      var internal = this.shadowRoot.firstElementChild;
      removeAttribute.call(internal, name);
      removeAttribute.call(this, name);
    }
  },

  descriptors: {
    textContent: {
      set: function(value) {
        textContent.set.call(this, value);
        if (this.lightStyle) { this.appendChild(this.lightStyle); }
      },

      get: function() {
        return textContent.get();
      }
    },

    innerHTML: {
      set: function(value) {
        innerHTML.set.call(this, value);
        if (this.lightStyle) { this.appendChild(this.lightStyle); }
      },

      get: innerHTML.get
    }
  }
};

/**
 * The default base prototype to use
 * when `extends` is undefined.
 *
 * @type {Object}
 */
var defaultPrototype = createProto(HTMLElement.prototype, base.properties);

/**
 * Returns a suitable prototype based
 * on the object passed.
 *
 * @private
 * @param  {HTMLElementPrototype|undefined} proto
 * @return {HTMLElementPrototype}
 */
function getBaseProto(proto) {
  if (!proto) { return defaultPrototype; }
  proto = proto.prototype || proto;
  return !proto.GaiaComponent ?
    createProto(proto, base.properties) : proto;
}

/**
 * Extends the given proto and mixes
 * in the given properties.
 *
 * @private
 * @param  {Object} proto
 * @param  {Object} props
 * @return {Object}
 */
function createProto(proto, props) {
  return mixin(Object.create(proto), props);
}

/**
 * Detects presence of shadow-dom
 * CSS selectors.
 *
 * @private
 * @return {Boolean}
 */
var hasShadowCSS = (function() {
  var div = document.createElement('div');
  try { div.querySelector(':host'); return true; }
  catch (e) { return false; }
})();

/**
 * Regexs used to extract shadow-css
 *
 * @type {Object}
 */
var regex = {
  shadowCss: /(?:\:host|\:\:content)[^{]*\{[^}]*\}/g,
  ':host': /(?:\:host)/g,
  ':host()': /\:host\((.+)\)(?: \:\:content)?/g,
  ':host-context': /\:host-context\((.+)\)([^{,]+)?/g,
  '::content': /(?:\:\:content)/g
};

/**
 * Extracts the :host and ::content rules
 * from the shadow-dom CSS and rewrites
 * them to work from the <style scoped>
 * injected at the root of the component.
 *
 * @private
 * @return {String}
 */
function processCss(template, name) {
  var globalCss = '';
  var lightCss = '';

  if (!hasShadowCSS) {
    template = template.replace(regex.shadowCss, function(match) {
      var hostContext = regex[':host-context'].exec(match);

      if (hostContext) {
        globalCss += match
          .replace(regex['::content'], '')
          .replace(regex[':host-context'], '$1 ' + name + '$2')
          .replace(/ +/g, ' '); // excess whitespace
      } else {
        lightCss += match
          .replace(regex[':host()'], name + '$1')
          .replace(regex[':host'], name)
          .replace(regex['::content'], name);
      }

      return '';
    });
  }

  return {
    template: template,
    lightCss: lightCss,
    globalCss: globalCss
  };
}

/**
 * Some CSS rules, such as @keyframes
 * and @font-face don't work inside
 * scoped or shadow <style>. So we
 * have to put them into 'global'
 * <style> in the head of the
 * document.
 *
 * @private
 * @param  {String} css
 */
function injectGlobalCss(css) {
  if (!css) {return;}
  var style = document.createElement('style');
  style.innerHTML = css.trim();
  headReady().then(function() {
    document.head.appendChild(style);
  });
}


/**
 * Resolves a promise once document.head is ready.
 *
 * @private
 */
function headReady() {
  return new Promise(function(resolve) {
    if (document.head) { return resolve(); }
    window.addEventListener('load', function fn() {
      window.removeEventListener('load', fn);
      resolve();
    });
  });
}


/**
 * The Gecko platform doesn't yet have
 * `::content` or `:host`, selectors,
 * without these we are unable to style
 * user-content in the light-dom from
 * within our shadow-dom style-sheet.
 *
 * To workaround this, we clone the <style>
 * node into the root of the component,
 * so our selectors are able to target
 * light-dom content.
 *
 * @private
 */
function injectLightCss(el) {
  if (hasShadowCSS) { return; }
  el.lightStyle = document.createElement('style');
  el.lightStyle.setAttribute('scoped', '');
  el.lightStyle.innerHTML = el.lightCss;
  el.appendChild(el.lightStyle);
}

/**
 * Convert hyphen separated
 * string to camel-case.
 *
 * Example:
 *
 *   toCamelCase('foo-bar'); //=> 'fooBar'
 *
 * @private
 * @param  {Sring} string
 * @return {String}
 */
function toCamelCase(string) {
  return string.replace(/-(.)/g, function replacer(string, p1) {
    return p1.toUpperCase();
  });
}

/**
 * Observer (singleton)
 *
 * @type {MutationObserver|undefined}
 */
var dirObserver;

/**
 * Observes the document `dir` (direction)
 * attribute and dispatches a global event
 * when it changes.
 *
 * Components can listen to this event and
 * make internal changes if need be.
 *
 * @private
 */
function addDirObserver() {
  if (dirObserver) { return; }

  dirObserver = new MutationObserver(onChanged);
  dirObserver.observe(document.documentElement, {
    attributeFilter: ['dir'],
    attributes: true
  });

  function onChanged(mutations) {
    document.dispatchEvent(new Event('dirchanged'));
  }
}

/**
 * Copy the values of all properties from
 * source object `target` to a target object `source`.
 * It will return the target object.
 *
 * @private
 * @param   {Object} target
 * @param   {Object} source
 * @returns {Object}
 */
function mixin(target, source) {
  for (var key in source) {
    target[key] = source[key];
  }
  return target;
}

});})(typeof define=='function'&&define.amd?define
:(function(n,w){'use strict';return typeof module=='object'?function(c){
c(require,exports,module);}:function(c){var m={exports:{}};c(function(n){
return w[n];},m.exports,m);w[n]=m.exports;};})('gaia-component',this));

},{}],10:[function(require,module,exports){
/* globals define */
(function(define){'use strict';define(function(require,exports,module){

/**
 * Dependencies
 */

var component = require('gaia-component');
var Drag = require('drag');

/**
 * Simple logger
 * @type {Function}
 */
var debug = 0 ? console.log.bind(console) : function() {};

/**
 * Exports
 */

module.exports = component.register('gaia-switch', {
  extends: HTMLInputElement.prototype,

  rtl: true,

  created: function() {
    this.setupShadowRoot();

    this.els = {
      inner: this.shadowRoot.querySelector('.inner'),
      track: this.shadowRoot.querySelector('.track'),
      handle: this.shadowRoot.querySelector('.handle')
    };

    // Bind context
    this.updateDir = this.updateDir.bind(this);
    this.toggle = this.toggle.bind(this);

    // Events
    on(this, 'click', e => this.onClick(e));

    // Configure
    this.setupDrag();
    this.disabled = this.getAttribute('disabled');
    this.checked = this.getAttribute('checked');

    // process everything that doesn't affect user interaction
    // after the component is created
    setTimeout(() => {
      // enable transitions after creation
      this.activateTransitions();
      this.makeAccessible();
    });
  },

  /**
   * Accessibility enhancements.
   * Read gaia-switch as switch.
   * make it tabable
   * read its checked and disabled state
   */
  makeAccessible: function() {
    this.setAttribute('role', 'switch');

    // Make tabable
    this.tabIndex = 0;

    this.setAttribute('aria-checked', this.checked);
    if (this.disabled) {
      this.setAttr('aria-disabled', true);
    }
  },

  attached: function() {
    debug('attached');
    on(document, 'dirchanged', this.updateDir);
  },

  detached: function() {
    debug('detached');
    off(document, 'dirchanged', this.updateDir);
  },

  setupDrag: function() {
    debug('setup drag');

    this.drag = new Drag({
      container: {
        el: this.els.track,
        width: 50,
        height: 32
      },

      handle: {
        el: this.els.handle,
        width: 32,
        height: 32,
        x: 0,
        y: 0
      },
    });

    this.drag.on('ended', () => this.drag.snap());
    this.drag.on('snapped', (e) => this.onSnapped(e));
  },

  activateTransitions: function() {
    debug('activate transitions');
    this.els.inner.classList.add('transitions-on');
  },

  onClick: function(e) {
    debug('click', e);
    e.stopPropagation();
    if (this.drag.dragging) { return; }
    if (this.disabled) { return; }
    this.toggle();
  },

  updateDir: function() {
    debug('update dir', dir());
    this.updatePosition();
  },

  onSnapped: function(e) {
    debug('snapped', e, convert.toChecked(e.detail.x));
    this.checked = convert.toChecked(e.detail.x);
  },

  toggle: function(value) {
    debug('toggle', value);
    this.checked = !this.checked;
  },

  updatePosition: function() {
    var edge = convert.toEdge(this.checked);
    this.drag.transition(edge, 0);
    debug('updated position', edge);
  },

  attrs: {
    checked: {
      get: function() { return this._checked; },
      set: function(value) {
        debug('set checked', value);
        value = !!(value || value === '');

        if (this._checked === value) { return; }

        var changed = this._checked !== undefined;
        this._checked = value;

        this.els.handle.style.transform = '';
        this.els.handle.style.transition = '';

        if (value) {
          this.setAttr('checked', '');
          this.setAttribute('aria-checked', true);
        } else {
          this.removeAttr('checked');
          this.setAttribute('aria-checked', false);
        }

        this.updatePosition();

        if (changed) { this.dispatchEvent(new CustomEvent('change')); }
      }
    },

    disabled: {
      get: function() { return this._disabled; },
      set: function(value) {
        value = !!(value || value === '');
        if (this._disabled === value) { return; }
        debug('set disabled', value);
        this._disabled = value;
        if (value) {
          this.setAttr('disabled', '');
          this.setAttr('aria-disabled', true);
        } else {
          this.removeAttr('disabled');
          this.removeAttr('aria-disabled');
        }
      }
    }
  },

  template: `
    <div class="inner">
      <div class="track">
        <div class="handle">
          <div class="handle-head"></div>
        </div>
      </div>
    </div>
    <style>

    :host {
      display: inline-block;
      position: relative;
      border-radius: 18px;
      outline: 0;
    }

    :host([disabled]) {
      pointer-events: none;
      opacity: 0.5;
    }

    /** Inner
     ---------------------------------------------------------*/

    .inner {
      display: block;
      width: 50px;
      height: 32px;
      direction: ltr;
    }

    /** Track
     ---------------------------------------------------------*/

    .track {
      position: relative;
      width: 100%;
      height: 100%;
      border-radius: 18px;

      /* Themeable */

      background:
        var(--switch-background,
        var(--background-minus,
        var(--background-plus,
        rgba(0,0,0,0.2))));
    }

    /** Track Background
     ---------------------------------------------------------*/

    .track:after {
      content: " ";
      display: block;
      position: absolute;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      border-radius: 25px;
      transform: scale(0);
      transition-property: transform;
      transition-duration: 200ms;
      transition-delay: 300ms;

      /* Theamable */

      background-color:
        var(--highlight-color, #000)
    }

    /**
     * [checked]
     */

    [checked] .track:after {
      transform: scale(1);
    }

    /** Handle
     ---------------------------------------------------------*/

    .handle {
      position: relative;
      z-index: 1;
      width: 32px;
      height: 32px;
    }

    /**
     * transitions-on
     */

    .inner:not(.transitions-on) .handle {
      transition: none !important;
    }

    /** Handle Head
     ---------------------------------------------------------*/

    .handle-head {
      display: flex;
      box-sizing: border-box;
      width: 36px;
      height: 36px;
      position: relative;
      top: -2px;
      left: -2px;
      border-radius: 50%;
      border: 1px solid;
      cursor: pointer;
      align-items: center;
      justify-content: center;

      /* Themable */

      background:
        var(--switch-head-background,
        var(--input-background,
        var(--button-background,
        var(--background-plus,
        #fff))));

      border-color:
        var(--switch-head-border-color,
        var(--switch-background,
        var(--border-color,
        var(--background-minus,
        rgba(0,0,0,0.2)))));
    }

    /** Handle Head Circle
     ---------------------------------------------------------*/

    .handle-head:after {
      content: "";
      display: block;
      width: 15px;
      height: 15px;
      border-radius: 50%;
      transform: scale(0);
      transition-property: transform;
      transition-duration: 300ms;
      transition-delay: 600ms;

      /* Themeable */

      background:
        var(--highlight-color, #000)
    }

    /**
     * [checked]
     */

    [checked] .handle-head:after {
      transform: scale(1);
    }

  </style>`
});

// Toggle switches when the component is
// focused and the spacebar is pressed.
addEventListener('keypress', function(e) {
  var isSpaceKey = e.which === 32;
  var el = document.activeElement;
  var isGaiaSwitch = el.tagName === 'GAIA-SWITCH';
  if (isSpaceKey && isGaiaSwitch) { el.click(); }
});

/**
 * TODO: Replace this <label> stuff
 * with smarter <gaia-label>
 */

// Bind a 'click' delegate to the
// window to listen for all clicks
// and toggle checkboxes when required.
addEventListener('click', function(e) {
  var label = getLabel(e.target);
  var gaiaSwitch = getLinkedSwitch(label);
  if (gaiaSwitch) { gaiaSwitch.toggle(); }
}, true);

/**
 * Find a gaiaSwitch when given a <label>.
 *
 * @param  {Element} label
 * @return {GaiaCheckbox|null}
 */
function getLinkedSwitch(label) {
  if (!label) { return; }
  var id = label.getAttribute('for');
  var el = id && document.getElementById(id);
  return el && el.tagName === 'GAIA-SWITCH' ? el : null;
}

/**
 * Walk up the DOM tree from a given
 * element until a <label> is found.
 *
 * @param  {Element} el
 * @return {HTMLLabelElement|undefined}
 */
function getLabel(el) {
  return el && (el.tagName == 'LABEL' ? el : getLabel(el.parentNode));
}

/**
 * Utils
 */

/**
 * Get the document direction.
 *
 * @return {String} ('ltr'|'rtl')
 */
function dir() {
  return document.dir || 'ltr';
}

/**
 * Handles convertion of edges values
 * to checked Booleans and checked
 * Booleans to edge values.
 *
 * This is because in LTR mode when the
 * handle is against the left edge the
 * switch is checked, in RTL mode it's
 * the opposite.
 *
 * @type {Object}
 */
var convert = {
  ltr: {
    edges: { '0': false, '1': true },
    checked: { 'true': '1', 'false': '0' }
  },

  rtl: {
    edges: { '0': true, '1': false },
    checked: { 'true': '0', 'false': '1' }
  },

  toChecked: function(edge) {
    return this[dir()].edges[edge];
  },

  toEdge: function(checked) {
    return this[dir()].checked[checked];
  }
};

function on(el, name, fn) { el.addEventListener(name, fn); }
function off(el, name, fn) { el.removeEventListener(name, fn); }

});})(typeof define=='function'&&define.amd?define
:(function(n,w){'use strict';return typeof module=='object'?function(c){
c(require,exports,module);}:function(c){var m={exports:{}};c(function(n){
return w[n];},m.exports,m);w[n]=m.exports;};})('gaia-switch',this));

},{"drag":8,"gaia-component":9}],11:[function(require,module,exports){
'use strict';

module.exports = function getNetworkInfo() {
	
	var info = {};
	var wifiManager = navigator.mozWifiManager;

	if(!wifiManager) {
	  return false;
	}
	
	var connInfo = wifiManager.connectionInformation;
	var status = wifiManager.connection.status;

	info.status = status;
	info.mac = wifiManager.macAddress;

	if(status === 'associated' || status === 'connected') {
		var network = wifiManager.connection.network;
		info.networkName = network.ssid;
		info.networkSecurity = network.security;
	}

	if(connInfo) {
		info.ip = connInfo.ipAddress;
	}

	return info;

};

},{}],12:[function(require,module,exports){
// SERVER CODE //
// Runs on the master device

'use strict';

/* global window, require, document */

// Web components
require('gaia-switch');

var HTTPServer = require('fxos-web-server');
var getNetworkInfo = require('get-network-info');
var webServer;

// TODO: URGH this is registering things in window but I have no time to
// change it now.
require('./lib/NDEFHelper.js');

const WWW = 'www';
const DEFAULT_WEB_PORT = 8080;
var myIP = '0.0.0.0';
var myPort;
var switchActive = document.getElementById('switchActive');
var networkInfo = document.getElementById('networkInfo');
var networkName = document.getElementById('networkName');
var networkAddress = document.getElementById('networkAddress');
var divMessages = document.getElementById('messages');
var webServerPort = document.getElementById('webServerPort');

window.addEventListener('load', init);

function init() {
	setupUI();
	var netInfo = getNetworkInfo();

	if(netInfo && netInfo.status === 'connected') {
		myIP = netInfo.ip;
		displayNetworkInfo(netInfo);
		startServers();
	} else {
		// TODO maybe use alert component 8-)
		log('This device is not connected to any network.<br />Make sure it is, so we can actually serve some content! ;-)');
	}
}

function setupUI() {
	
	switchActive.addEventListener('change', function(e) {

		var checked = switchActive.checked;
		
		if(!webServer) {
			return;
		}

		// don't really do anything if there's no change
		if(webServer.running === checked) {
			return;
		}

		if(checked) {
			startServers();
		} else {
			stopServers();
		}

	});

	webServerPort.value = DEFAULT_WEB_PORT;
}

function displayNetworkInfo(info) {
	networkInfo.removeAttribute('hidden');
	networkName.textContent = info.networkName;
	networkAddress.textContent = info.ip;
}


function startServers() {
	startWebServer();
	startNFCServer();
	window.addEventListener('beforeunload', stopServers);
}


function stopServers() {
	stopWebServer();
	stopNFCServer();
	window.removeEventListener('beforeunload', stopServers);
}


function setupWebServer() {

	var port = webServerPort.value;

	if(!port) {
		port = DEFAULT_WEB_PORT;
	} else {
		port = port * 1;
	}

	myPort = port;

	webServer = new HTTPServer(port);

	webServer.addEventListener('request', function(evt) {
		var request = evt.request;
		var response = evt.response;

		log('requested? ' + request.path);

		if (request.path.substr(-1) === '/') {
			request.path = request.path.substring(0, request.path.length - 1);
		}

		var path = decodeURIComponent(request.path) || '/';
		var wwwPath = WWW + path;
		var fileToSend = wwwPath;

		log('p... ' + path);

		// It's a dir
		if(path.substr(-1) === '/') {
			// TODO: actually implement this logic-need a way to catch fails in response (or do it without sendFile)
			// is there an index.html in that directory?
			//    yes? serve it
			//    no? return 403

			fileToSend = wwwPath + 'index.html';

		} 

		var t0;
		log('will send ' + fileToSend);
		response.addEventListener('complete', function(e) {
			var now = Date.now();
			var elapsedTime = ((now - t0) * 0.001).toFixed(2);
			log(fileToSend + ': response complete ' + elapsedTime + ' seconds');
		});

		response.headers['Content-Type'] = getContentType(fileToSend);
		t0 = Date.now();
		response.sendFile(fileToSend); // TODO how to detect if the file doesn't exist & return 404?
		
	});
}


function startWebServer() {
	if(webServer) {
		webServer.stop();
	}
	setupWebServer();
	webServer.start();
	switchActive.checked = true;
	// Using setAttribute instead of just the .disabled property so we can use [disabled] on the stylesheet
	webServerPort.setAttribute('disabled', 'disabled');
	log('server url at ' + getMyURL());
}


function stopWebServer() {
	webServer.stop();
	switchActive.checked = false;
	webServerPort.removeAttribute('disabled');
	log('server stopped');
}


function getMyURL() {
	return 'http://' + myIP + ':' + myPort;
}


function startNFCServer() {

	var mozNfc = window.navigator.mozNfc;// TODO change var name

	if(!mozNfc) {
		console.error('NFC API not available');
	} else {
		log('NFC available');
	}

	if(!mozNfc.enabled) {
		log('NFC is available, but not enabled');
	}

	mozNfc.onpeerfound = onNFCPeerFound;

}

function stopNFCServer() {
	window.navigator.mozNfc.onpeerfound = null;
}


// TODO note that peers can't be found if the screen is locked
// (I presume for security)
function onNFCPeerFound(e) {
	console.log('NFC PEER!!!', e.peer);

	var peer = e.peer;
	var url = getMyURL(); 
	var ndefHelper = new NDEFHelper();
	var record = ndefHelper.createURI(url);

	log('sending ' + url);
	peer.sendNDEF([record]).then(() => {
		log('SENT URL ' + url);
	}).catch((err) => {
		log('NFC ERROR: ' + err);
	});
}

function log(message) {
	divMessages.innerHTML += message + '<br />';
	console.log(message);
}

function getContentType(filePath) {

	var extension = getExtension(filePath);
	var extToType = {
		'gif': 'image/gif',
		'jpg': 'image/jpg',
		'css': 'text/css',
		'js': 'text/javascript',
		'html': 'text/html'
	};

	log(filePath + ' -- ' + extension);

	if(extension.length > 0) {
		var type = extToType[extension];
		log('Content type of ' + filePath + ' is ' + type);
		if(type !== undefined) {
			return type;
		}
	}

	// falling back to text/html
	return 'text/html';

}

function getExtension(filePath) {
	var parts = filePath.split('.');
	if(parts.length < 2) {
		return '';
	} else {
		return parts.pop();
	}
}



},{"./lib/NDEFHelper.js":13,"fxos-web-server":5,"gaia-switch":10,"get-network-info":11}],13:[function(require,module,exports){
'use strict';

// This file copied from https://github.com/mozilla-b2g/gaia/blob/master/dev_apps/nfc-api-test/js/ndef_helper.js
(function(exports) {
  var URI = ['', 'http://www.', 'https://www.', 'http://', 'https://', 'tel:',
    'mailto:', 'ftp://anonymous:anonymous@', 'ftp://ftp.', 'ftps://', 'sftp://',
    'smb://', 'nfs://', 'ftp://', 'dav://', 'news:', 'telnet://', 'imap:',
    'rtsp://', 'urn:', 'pop:', 'sip:', 'sips:', 'tftp:', 'btspp://',
    'btl2cap://', 'btgoep://', 'tcpobex://', 'irdaobex://', 'file://',
    'urn:epc:id:', 'urn:epc:tag:', 'urn:epc:pat:', 'urn:epc:raw:', 'urn:epc:',
    'urn:nfc:'];

  function NDEFHelper() { }

  NDEFHelper.prototype = {
    /**
     * Create MozNDEFRecord whose content is the uri.
     */
    createURI: function nh_createURI(uri) {

      var id = 0;
      // start with 1 since index 0 is ''.
      for (var i = 1; i < URI.length; i++) {
        if (uri.startsWith(URI[i])) {
          id = i;
        }
      }

      uri = String.fromCharCode(id) + uri.substring(URI[id].length);

      var enc = new TextEncoder('utf-8');

      return new MozNDEFRecord({tnf: 'well-known',
                                type: enc.encode('U'),
                                payload: enc.encode(uri)});
    },

    parseURI: function nh_parseURI(ndef) {
      if (!ndef || ndef.tnf != 'well-known' || ndef.type[0] != 0x55) {
        return null;
      }

      var payload = ndef.payload;
      var prefix = URI[payload[0]];
      if (!prefix) {
        return null;
      }

      var dec = new TextDecoder('utf-8');
      return prefix + dec.decode(payload.subarray(1));
    },

    /**
     * Utils to dump Uint8Array.
     */
    dumpUint8Array: function nh_dumpUint8Array(array) {
      if (!array) {
        return 'null';
      }

      var str = '[';
      var i;
      var arrayLen = array ? array.length : 0;
      for (i = 0; i < arrayLen; i++) {
        str += '0x' + array[i].toString(16);
        if (i != array.length - 1) {
          str += ', ';
        }
      }

      return str + ']';
    }
  };

  exports.NDEFHelper = NDEFHelper;
})(window);


},{}]},{},[12])